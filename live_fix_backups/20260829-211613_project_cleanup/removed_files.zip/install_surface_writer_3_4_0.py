from pathlib import Path
from datetime import datetime
import ast
import shutil
import subprocess
import sys

PROJECT_ROOT = Path(__file__).resolve().parent
BOT_PATH = PROJECT_ROOT / 'bot.py'
VOICE_PATH = PROJECT_ROOT / 'local_voice.py'
PLANNER_PATH = PROJECT_ROOT / 'response_planner.py'
SURFACE_PATH = PROJECT_ROOT / 'surface_writer.py'
BACKUP_ROOT = PROJECT_ROOT / 'live_fix_backups'

EXPECTED_BOT = 'BOT_VERSION = "3.3.0-response-planner"'
TARGET_BOT = 'BOT_VERSION = "3.4.0-qwen-surface-writer"'
EXPECTED_VOICE = 'LOCAL_VOICE_VERSION = "1.3.0"'
EXPECTED_PLANNER = 'RESPONSE_PLANNER_VERSION = "1.0"'

SURFACE_SOURCE = 'import asyncio\nimport os\nimport re\nimport time\n\nfrom dataclasses import dataclass\n\nfrom local_voice import (\n    LOCAL_VOICE_ENABLED,\n    LOCAL_VOICE_MODEL,\n    LOCAL_VOICE_QUEUE_TIMEOUT,\n    LOCAL_VOICE_NUM_CTX,\n    LOCAL_VOICE_KEEP_ALIVE,\n    run_local_model,\n    clean_response_text,\n    count_genuine_questions,\n    normalize_simple_text,\n    TRIVIAL_COLLAPSE_RESPONSES,\n    is_user_echo_takeover,\n    introduces_unsupported_habit_claim,\n    ASSISTANT_BOILERPLATE_PATTERNS,\n    get_result_value,\n    extract_json_dict,\n    clamp01,\n    parse_bool,\n    format_recent_messages,\n    _voice_semaphore,\n)\n\nfrom voice_memory import (\n    get_relevant_voice_examples,\n    format_voice_examples,\n)\n\n\n# =========================================================\n# VERSION\n# =========================================================\n\nSURFACE_WRITER_VERSION = "1.0"\n\n\n# =========================================================\n# CONFIG\n# =========================================================\n\ndef _env_bool(\n    name,\n    default=False,\n):\n    value = os.getenv(\n        name\n    )\n\n    if value is None:\n        return default\n\n    return (\n        value.strip().lower()\n        in {\n            "1",\n            "true",\n            "yes",\n            "on",\n        }\n    )\n\n\nSURFACE_WRITER_ENABLED = _env_bool(\n    "SURFACE_WRITER_ENABLED",\n    True\n)\n\nSURFACE_WRITER_NUM_PREDICT = int(\n    os.getenv(\n        "SURFACE_WRITER_NUM_PREDICT",\n        "140"\n    )\n)\n\nSURFACE_WRITER_TEMPERATURE = float(\n    os.getenv(\n        "SURFACE_WRITER_TEMPERATURE",\n        "0.72"\n    )\n)\n\n\n# =========================================================\n# RESULT\n# =========================================================\n\n@dataclass\nclass SurfaceWriterResult:\n\n    output_text: str\n\n    success: bool\n\n    used: bool\n\n    reason: str\n\n    duration: float = 0.0\n\n    plan_preserved: float = 0.0\n\n    new_facts: bool = False\n\n\n# =========================================================\n# SYSTEM\n# =========================================================\n\nSURFACE_WRITER_SYSTEM_PROMPT = """\nDu bist Evilnaes PRIMARY SURFACE WRITER.\n\nDas Brain und der Response Planner haben bereits entschieden,\nWAS Evilnae inhaltlich und sozial ausdrücken will.\n\nDEINE EINZIGE AUFGABE:\nFormuliere daraus Evilnaes tatsächliche Discord-Nachricht.\n\nDu bist NICHT:\n- das Brain\n- ein Faktenfinder\n- ein Lore-Autor\n- ein Assistent\n- ein Critic für einen vorhandenen Entwurf\n\nDer RESPONSE PLAN ist dein Vertrag.\n\nWICHTIG:\n- transportiere genau den Core Thought\n- folge Social Move und Stance\n- beachte Banter/Warmth\n- beachte MUST INCLUDE\n- verletze MUST AVOID nicht\n- erfinde KEINEN zweiten Gedanken\n- erfinde KEINE neuen Fakten\n- erfinde KEINE Erinnerungen\n- erfinde KEINE neuen Aktivitäten\n- erfinde KEINE Gewohnheiten\n- erfinde KEINE Beziehungen\n- erfinde KEINE Lore\n- übernimm NICHT die Sprecherrolle des Users\n- füge KEINEN höflichen Assistant-Abschluss hinzu\n- paraphrasiere NICHT einfach die User-Nachricht\n- kein "Evilnae:" vor der Nachricht\n- keine gesamte Antwort in Anführungszeichen\n- niemals "fair" oder "fair enough"\n- keine Unicode-Emojis\n- keine Discord-Custom-Emotes\n\nDiscord darf kurz sein.\nEin guter One-Liner ist besser als drei vollständige Bot-Sätze.\n\nWenn der Plan keine Frage erlaubt:\nkeine echte Gegenfrage.\n\nWenn das Thema ernst ist:\nkeinen Roast erzwingen.\n\nWenn der Plan smug/tease/counter sagt:\nnicht in freundliche neutrale Assistentensprache zurückfallen.\n\nGOOD/BAD Voice Examples zeigen nur SPRACHE und RHYTHM.\nSie sind KEINE Faktenquelle.\nKopiere ihre Inhalte nicht.\n\nTRUSTED EVIDENCE darf Fakten liefern.\nAlles andere ist nur Stil/Kontext.\n\nAntworte ausschließlich als gültiges JSON:\n\n{\n  "o": "Evilnaes fertige Discord-Nachricht",\n  "p": 1.0,\n  "f": false,\n  "z": "kurzer Grund"\n}\n\np = wie gut der Response Plan erhalten wurde, 0.0 bis 1.0\nf = true falls du gegenüber Plan/Evidence neue Fakten hinzugefügt hast\nz = kurzer interner Grund, maximal 8 Wörter\n""".strip()\n\n\n# =========================================================\n# PROMPT\n# =========================================================\n\ndef build_surface_writer_prompt(\n    *,\n    user_message,\n    response_plan_text,\n    core_thought,\n    social_move,\n    stance,\n    reply_shape,\n    allow_question,\n    inner_state_guidance,\n    recent_evilnae_messages,\n    channel_recent_evilnae_messages,\n    good_examples,\n    bad_examples,\n    identity_context="",\n    evidence_context="",\n):\n\n    question_rule = (\n        "Eine natürliche Frage ist erlaubt, wenn der Plan sie braucht."\n        if allow_question\n        else "Keine echte Gegenfrage."\n    )\n\n    identity_text = (\n        str(\n            identity_context\n            or ""\n        ).strip()\n        or\n        "Evilnae bleibt Evilnae; keine Sprecherverwechslung."\n    )\n\n    evidence_text = (\n        str(\n            evidence_context\n            or ""\n        ).strip()\n        or\n        "Keine zusätzlichen Fakten außerhalb des Response Plans nötig."\n    )\n\n    return f"""\nSPEAKER:\nEvilnae\n\nUSER MESSAGE:\n{user_message}\n\nRESPONSE PLAN:\n{response_plan_text}\n\nCORE THOUGHT:\n{core_thought}\n\nSOCIAL MOVE:\n{social_move}\n\nSTANCE:\n{stance}\n\nREPLY SHAPE:\n{reply_shape}\n\nQUESTION CONTRACT:\n{question_rule}\n\nINNER STATE:\n{inner_state_guidance}\n\nIDENTITY / SOCIAL OWNERSHIP:\n{identity_text}\n\nTRUSTED EVIDENCE:\n{evidence_text}\n\nRECENT EVILNAE — USER:\n{format_recent_messages(\n    recent_evilnae_messages,\n    limit=5\n)}\n\nRECENT EVILNAE — CHANNEL:\n{format_recent_messages(\n    channel_recent_evilnae_messages,\n    limit=8\n)}\n\nGOOD VOICE EXAMPLES:\n{format_voice_examples(\n    good_examples\n)}\n\nBAD VOICE EXAMPLES:\n{format_voice_examples(\n    bad_examples\n)}\n\nAUFGABE:\nSchreibe JETZT genau eine natürliche Evilnae-Discord-Nachricht\naus dem Response Plan.\n\nKein Vorwort.\nKeine Analyse.\nKein zweiter Gedanke.\nKein Assistant-Abschluss.\n\nJSON:\n{{\n  "o":"",\n  "p":1.0,\n  "f":false,\n  "z":""\n}}\n""".strip()\n\n\n# =========================================================\n# VALIDATION\n# =========================================================\n\ndef validate_surface_writer_candidate(\n    *,\n    user_message,\n    candidate,\n    allow_question,\n    reply_shape,\n    plan_preserved,\n    new_facts,\n):\n\n    candidate = (\n        clean_response_text(\n            candidate\n        )\n    )\n\n    if not candidate:\n\n        return (\n            False,\n            "empty_surface_output"\n        )\n\n    if new_facts:\n\n        return (\n            False,\n            "surface_added_new_facts"\n        )\n\n    if (\n        plan_preserved\n        <\n        0.75\n    ):\n\n        return (\n            False,\n            "surface_plan_drift"\n        )\n\n    if (\n        not allow_question\n        and\n        count_genuine_questions(\n            candidate\n        )\n        > 0\n    ):\n\n        return (\n            False,\n            "surface_question_not_allowed"\n        )\n\n    if re.search(\n        r"\\bfair(?:\\s+enough)?\\b",\n        candidate,\n        flags=re.IGNORECASE\n    ):\n\n        return (\n            False,\n            "surface_banned_word"\n        )\n\n    if re.search(\n        r"<@!?\\d+>",\n        candidate\n    ):\n\n        return (\n            False,\n            "surface_new_mention"\n        )\n\n    normalized = (\n        normalize_simple_text(\n            candidate\n        )\n    )\n\n    if normalized in (\n        TRIVIAL_COLLAPSE_RESPONSES\n    ):\n\n        return (\n            False,\n            "surface_trivial_collapse"\n        )\n\n    if is_user_echo_takeover(\n        user_message,\n        candidate\n    ):\n\n        return (\n            False,\n            "surface_user_echo_takeover"\n        )\n\n    if introduces_unsupported_habit_claim(\n        "",\n        candidate\n    ):\n\n        return (\n            False,\n            "surface_unsupported_habit"\n        )\n\n    if any(\n        pattern.search(\n            candidate\n        )\n\n        for pattern\n        in ASSISTANT_BOILERPLATE_PATTERNS\n    ):\n\n        return (\n            False,\n            "surface_assistant_boilerplate"\n        )\n\n    max_words = {\n        "fragment": 16,\n        "one_liner": 34,\n        "short": 52,\n        "compact": 85,\n        "medium": 140,\n    }.get(\n        str(\n            reply_shape\n            or\n            "one_liner"\n        ).lower(),\n        52,\n    )\n\n    if (\n        len(\n            re.findall(\n                r"[A-Za-zÄÖÜäöüß]+",\n                candidate\n            )\n        )\n        >\n        max_words\n    ):\n\n        return (\n            False,\n            "surface_too_long_for_plan"\n        )\n\n    return (\n        True,\n        "ok"\n    )\n\n\n# =========================================================\n# GENERATE\n# =========================================================\n\nasync def generate_surface_response_from_plan(\n    *,\n    user_message,\n    response_plan_text,\n    core_thought,\n    social_move,\n    stance,\n    reply_shape,\n    allow_question,\n    inner_state_guidance,\n    recent_evilnae_messages,\n    channel_recent_evilnae_messages=None,\n    identity_context="",\n    evidence_context="",\n):\n\n    if not LOCAL_VOICE_ENABLED:\n\n        return SurfaceWriterResult(\n            output_text="",\n            success=False,\n            used=False,\n            reason="local_voice_disabled",\n        )\n\n    if not SURFACE_WRITER_ENABLED:\n\n        return SurfaceWriterResult(\n            output_text="",\n            success=False,\n            used=False,\n            reason="surface_writer_disabled",\n        )\n\n    recent_evilnae_messages = list(\n        recent_evilnae_messages\n        or []\n    )\n\n    channel_recent_evilnae_messages = list(\n        channel_recent_evilnae_messages\n        or\n        recent_evilnae_messages\n    )\n\n    try:\n\n        await asyncio.wait_for(\n            _voice_semaphore.acquire(),\n            timeout=(\n                LOCAL_VOICE_QUEUE_TIMEOUT\n            )\n        )\n\n    except asyncio.TimeoutError:\n\n        print(\n            "[SURFACE WRITER FALLBACK] "\n            "reason=queue_busy"\n        )\n\n        return SurfaceWriterResult(\n            output_text="",\n            success=False,\n            used=False,\n            reason="queue_busy",\n        )\n\n    started = (\n        time.perf_counter()\n    )\n\n    try:\n\n        (\n            good_examples,\n            bad_examples\n        ) = (\n            get_relevant_voice_examples(\n                user_message\n            )\n        )\n\n        prompt = (\n            build_surface_writer_prompt(\n\n                user_message=(\n                    user_message\n                ),\n\n                response_plan_text=(\n                    response_plan_text\n                ),\n\n                core_thought=(\n                    core_thought\n                ),\n\n                social_move=(\n                    social_move\n                ),\n\n                stance=(\n                    stance\n                ),\n\n                reply_shape=(\n                    reply_shape\n                ),\n\n                allow_question=(\n                    allow_question\n                ),\n\n                inner_state_guidance=(\n                    inner_state_guidance\n                ),\n\n                recent_evilnae_messages=(\n                    recent_evilnae_messages\n                ),\n\n                channel_recent_evilnae_messages=(\n                    channel_recent_evilnae_messages\n                ),\n\n                good_examples=(\n                    good_examples\n                ),\n\n                bad_examples=(\n                    bad_examples\n                ),\n\n                identity_context=(\n                    identity_context\n                ),\n\n                evidence_context=(\n                    evidence_context\n                ),\n            )\n        )\n\n        try:\n\n            raw_content = (\n                await run_local_model(\n\n                    system_prompt=(\n                        SURFACE_WRITER_SYSTEM_PROMPT\n                    ),\n\n                    user_prompt=(\n                        prompt\n                    ),\n\n                    temperature=(\n                        SURFACE_WRITER_TEMPERATURE\n                    ),\n\n                    num_predict=(\n                        SURFACE_WRITER_NUM_PREDICT\n                    )\n                )\n            )\n\n        except Exception as error:\n\n            duration = (\n                time.perf_counter()\n                -\n                started\n            )\n\n            print(\n                "[SURFACE WRITER FALLBACK] "\n                f"duration={duration:.2f}s "\n                f"reason="\n                f"{type(error).__name__}"\n            )\n\n            return SurfaceWriterResult(\n                output_text="",\n                success=False,\n                used=False,\n                reason="surface_model_unavailable",\n                duration=duration,\n            )\n\n        if raw_content is None:\n\n            return SurfaceWriterResult(\n                output_text="",\n                success=False,\n                used=False,\n                reason="invalid_surface_response",\n                duration=(\n                    time.perf_counter()\n                    -\n                    started\n                ),\n            )\n\n        data = (\n            extract_json_dict(\n                raw_content\n            )\n        )\n\n        if not data:\n\n            duration = (\n                time.perf_counter()\n                -\n                started\n            )\n\n            print(\n                "[SURFACE WRITER FALLBACK] "\n                f"duration={duration:.2f}s "\n                "reason=json_parse_error "\n                f"raw="\n                f"{str(raw_content)[:300]!r}"\n            )\n\n            return SurfaceWriterResult(\n                output_text="",\n                success=False,\n                used=True,\n                reason="surface_json_parse_error",\n                duration=duration,\n            )\n\n        candidate = (\n            clean_response_text(\n\n                get_result_value(\n                    data,\n                    "o",\n                    "response",\n                    ""\n                )\n            )\n        )\n\n        plan_preserved = (\n            clamp01(\n\n                get_result_value(\n                    data,\n                    "p",\n                    "plan_preserved",\n                    0.0\n                ),\n\n                0.0\n            )\n        )\n\n        new_facts = (\n            parse_bool(\n\n                get_result_value(\n                    data,\n                    "f",\n                    "new_facts",\n                    False\n                ),\n\n                False\n            )\n        )\n\n        reason = str(\n            get_result_value(\n                data,\n                "z",\n                "reason",\n                ""\n            )\n            or ""\n        )[:120]\n\n        (\n            valid,\n            validation_reason\n        ) = (\n            validate_surface_writer_candidate(\n\n                user_message=(\n                    user_message\n                ),\n\n                candidate=(\n                    candidate\n                ),\n\n                allow_question=(\n                    allow_question\n                ),\n\n                reply_shape=(\n                    reply_shape\n                ),\n\n                plan_preserved=(\n                    plan_preserved\n                ),\n\n                new_facts=(\n                    new_facts\n                ),\n            )\n        )\n\n        duration = (\n            time.perf_counter()\n            -\n            started\n        )\n\n        if not valid:\n\n            print(\n                "[SURFACE WRITER REJECT] "\n                f"duration={duration:.2f}s "\n                f"reason={validation_reason} "\n                f"candidate={candidate!r}"\n            )\n\n            return SurfaceWriterResult(\n                output_text="",\n                success=False,\n                used=True,\n                reason=validation_reason,\n                duration=duration,\n                plan_preserved=plan_preserved,\n                new_facts=new_facts,\n            )\n\n        print(\n            "[SURFACE WRITER] "\n            f"v={SURFACE_WRITER_VERSION} "\n            f"model={LOCAL_VOICE_MODEL} "\n            f"duration={duration:.2f}s "\n            f"plan={plan_preserved:.2f} "\n            f"new_facts={new_facts} "\n            f"move={social_move} "\n            f"stance={stance} "\n            f"shape={reply_shape} "\n            f"reason={reason!r} "\n            f"output={candidate!r}"\n        )\n\n        return SurfaceWriterResult(\n            output_text=candidate,\n            success=True,\n            used=True,\n            reason=(\n                reason\n                or\n                "surface_writer_success"\n            ),\n            duration=duration,\n            plan_preserved=plan_preserved,\n            new_facts=False,\n        )\n\n    finally:\n\n        _voice_semaphore.release()\n\n\n# =========================================================\n# DEBUG\n# =========================================================\n\ndef format_surface_writer_debug() -> str:\n\n    return (\n        "[SURFACE WRITER CONFIG] "\n        f"v={SURFACE_WRITER_VERSION} "\n        f"enabled={SURFACE_WRITER_ENABLED} "\n        f"model={LOCAL_VOICE_MODEL} "\n        f"predict={SURFACE_WRITER_NUM_PREDICT} "\n        f"temperature={SURFACE_WRITER_TEMPERATURE:.2f}"\n    )\n\n\n# =========================================================\n# SELF TEST\n# =========================================================\n\ndef _self_test():\n\n    tests = []\n\n    def check(\n        candidate,\n        *,\n        user="ich bin aus dem bett gefallen",\n        allow_question=False,\n        shape="one_liner",\n        preserved=1.0,\n        new_facts=False,\n    ):\n\n        return validate_surface_writer_candidate(\n            user_message=user,\n            candidate=candidate,\n            allow_question=allow_question,\n            reply_shape=shape,\n            plan_preserved=preserved,\n            new_facts=new_facts,\n        )\n\n    tests.append(\n        (\n            "clean one-liner",\n            check(\n                "starker start, direkt gegen dein eigenes bett verloren."\n            )[0],\n        )\n    )\n\n    tests.append(\n        (\n            "plan drift blocked",\n            not check(\n                "joa.",\n                preserved=0.40,\n            )[0],\n        )\n    )\n\n    tests.append(\n        (\n            "new facts blocked",\n            not check(\n                "ich hab das gestern auch gemacht.",\n                new_facts=True,\n            )[0],\n        )\n    )\n\n    tests.append(\n        (\n            "question contract",\n            not check(\n                "und wie ist das passiert?",\n            )[0],\n        )\n    )\n\n    tests.append(\n        (\n            "assistant boilerplate",\n            not check(\n                "Das klingt spannend, ich bin gespannt."\n            )[0],\n        )\n    )\n\n    passed = 0\n\n    print("")\n    print("=" * 58)\n    print(\n        f"SURFACE WRITER v"\n        f"{SURFACE_WRITER_VERSION} TEST"\n    )\n    print("=" * 58)\n\n    for (\n        name,\n        success\n    ) in tests:\n\n        print(\n            f"[{\'PASS\' if success else \'FAIL\'}] "\n            f"{name}"\n        )\n\n        if success:\n            passed += 1\n\n    print(\n        f"RESULT: "\n        f"{passed}/{len(tests)} PASS"\n    )\n\n    return (\n        0\n        if passed == len(tests)\n        else 1\n    )\n\n\nif __name__ == "__main__":\n\n    raise SystemExit(\n        _self_test()\n    )\n'
ROUTER_BLOCK = '        # =================================================\n        # 9.5 QWEN PRIMARY SURFACE WRITER ROUTER\n        #\n        # Qwen formuliert direkt aus dem Response Plan.\n        #\n        # Erfolg:\n        #   Qwen = Primary Text Writer\n        #   OpenAI Writer = übersprungen\n        #\n        # Fehler / Drift / Queue busy:\n        #   bestehender OpenAI Writer läuft unverändert.\n        # =================================================\n\n        surface_evidence_parts = []\n\n        for surface_piece in (\n            character_directive_text,\n            character_state_text,\n        ):\n\n            surface_piece = str(\n                surface_piece\n                or ""\n            ).strip()\n\n            if surface_piece:\n\n                surface_evidence_parts.append(\n                    surface_piece\n                )\n\n        if world_evidence.matched:\n\n            surface_evidence_parts.append(\n                format_world_evidence_for_writer(\n                    world_evidence\n                )\n            )\n\n        if self_evidence.matched:\n\n            surface_evidence_parts.append(\n                format_self_evidence_for_writer(\n                    self_evidence\n                )\n            )\n\n        if knowledge_constraint.active:\n\n            surface_evidence_parts.append(\n                format_knowledge_constraint(\n                    knowledge_constraint\n                )\n            )\n\n        surface_evidence_text = (\n            "\\n\\n".join(\n                surface_evidence_parts\n            )\n            or\n            "Keine zusätzlichen Evidence-Blöcke nötig."\n        )\n\n        surface_writer_used = False\n        surface_writer_result = None\n\n        async def primary_writer_callable(\n            **openai_writer_kwargs\n        ):\n\n            nonlocal surface_writer_used\n            nonlocal surface_writer_result\n\n            try:\n\n                surface_writer_result = (\n                    await generate_surface_response_from_plan(\n\n                        user_message=(\n                            user_text\n                        ),\n\n                        response_plan_text=(\n                            response_plan_text\n                        ),\n\n                        core_thought=(\n                            response_plan\n                            .core_thought\n                        ),\n\n                        social_move=(\n                            response_plan\n                            .social_move\n                        ),\n\n                        stance=(\n                            response_plan\n                            .stance\n                        ),\n\n                        reply_shape=(\n                            response_plan\n                            .reply_shape\n                        ),\n\n                        allow_question=(\n                            response_plan\n                            .allow_question\n                        ),\n\n                        inner_state_guidance=(\n                            inner_state_guidance\n                        ),\n\n                        recent_evilnae_messages=(\n                            state.history\n                            .recent_evilnae_messages\n                        ),\n\n                        channel_recent_evilnae_messages=(\n                            channel_evilnae_messages[\n                                -12:\n                            ]\n                        ),\n\n                        identity_context=(\n                            turn_identity_text\n                            + "\\n\\n"\n                            + social_stance_text\n                        ),\n\n                        evidence_context=(\n                            surface_evidence_text\n                        ),\n                    )\n                )\n\n            except Exception as error:\n\n                print(\n                    "[SURFACE WRITER INTEGRATION ERROR] "\n                    f"user={username} "\n                    f"error="\n                    f"{type(error).__name__}: "\n                    f"{error}"\n                )\n\n                surface_writer_result = None\n\n            if (\n                surface_writer_result\n                and\n                surface_writer_result.success\n                and\n                surface_writer_result.output_text\n            ):\n\n                surface_writer_used = True\n\n                print(\n                    "[WRITER ROUTER] "\n                    f"user={username} "\n                    "primary=qwen_surface "\n                    "openai_writer=skipped"\n                )\n\n                return SimpleNamespace(\n                    output_text=(\n                        surface_writer_result\n                        .output_text\n                    ),\n                    surface_writer=True,\n                )\n\n            fallback_reason = (\n                getattr(\n                    surface_writer_result,\n                    "reason",\n                    "surface_writer_error",\n                )\n                if surface_writer_result\n                else\n                "surface_writer_error"\n            )\n\n            print(\n                "[WRITER ROUTER] "\n                f"user={username} "\n                "primary=qwen_surface_failed "\n                "fallback=openai_writer "\n                f"reason={fallback_reason}"\n            )\n\n            return await safe_openai_request(\n                **openai_writer_kwargs\n            )\n\n        async def secondary_voice_callable(\n            **voice_kwargs\n        ):\n\n            if surface_writer_used:\n\n                print(\n                    "[LOCAL VOICE SECOND PASS SKIP] "\n                    f"user={username} "\n                    "reason=qwen_already_primary"\n                )\n\n                return SimpleNamespace(\n                    output_text=(\n                        voice_kwargs.get(\n                            "draft",\n                            ""\n                        )\n                    ),\n                    meaning_preserved=1.0,\n                    used=False,\n                    rewritten=False,\n                    reason=(\n                        "qwen_already_primary"\n                    ),\n                )\n\n            return await humanize_evilnae_response(\n                **voice_kwargs\n            )\n\n\n'
SIMPLE_IMPORT_OLD = 'import sys\n'
SIMPLE_IMPORT_NEW = 'import sys\nfrom types import SimpleNamespace\n'
SURFACE_IMPORT = 'from surface_writer import (\n    SURFACE_WRITER_VERSION,\n    SURFACE_WRITER_ENABLED,\n    generate_surface_response_from_plan,\n    format_surface_writer_debug,\n)\n\n'
STARTUP_OLD = '    print(\n        "Social Move / Stance Contract: ACTIVE"\n    )\n\n'
STARTUP_NEW = '    print(\n        "Social Move / Stance Contract: ACTIVE"\n    )\n\n    print(\n        f"Qwen Surface Writer v"\n        f"{SURFACE_WRITER_VERSION}: "\n        f"{\'PRIMARY\' if SURFACE_WRITER_ENABLED else \'DISABLED\'}"\n    )\n\n    print(\n        "OpenAI Text Writer: FALLBACK / REPAIR"\n    )\n\n    print(\n        "Duplicate Qwen Humanizer After Qwen Primary: DISABLED"\n    )\n\n    print(\n        format_surface_writer_debug()\n    )\n\n'
WRITER_TASK_OLD = '                writer_task = (\n                    asyncio.create_task(\n                        safe_openai_request(\n'
WRITER_TASK_NEW = '                writer_task = (\n                    asyncio.create_task(\n                        primary_writer_callable(\n'
VOICE_CALL_OLD = '                await humanize_evilnae_response(\n'
VOICE_CALL_NEW = '                await secondary_voice_callable(\n'


def ok(text):
    print(f"[OK] {text}")


def fail(text):
    print()
    print(f"[INSTALL ERROR] {text}")
    print("Nothing was overwritten by this installer.")
    raise SystemExit(1)


def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        fail(
            f"{label}: expected exactly 1 match, found {count}"
        )
    ok(label)
    return text.replace(old, new, 1)


def insert_before_once(text, marker, block, label):
    count = text.count(marker)
    if count != 1:
        fail(
            f"{label}: expected exactly 1 marker, found {count}"
        )
    ok(label)
    return text.replace(marker, block + marker, 1)


def syntax_check(text, filename):
    try:
        ast.parse(text, filename=filename)
    except SyntaxError as error:
        fail(
            f"{filename}: syntax error after patch at "
            f"line {error.lineno}: {error.msg}"
        )
    ok(f"{filename} syntax check")


print("=" * 78)
print("EVILNAE 3.4.0 — QWEN PRIMARY SURFACE WRITER")
print("=" * 78)
print(f"Project: {PROJECT_ROOT}")
print()
print("WICHTIG: bot.py muss vollständig AUS sein.")
print()

for path in (
    BOT_PATH,
    VOICE_PATH,
    PLANNER_PATH,
):
    if not path.exists():
        fail(f"Missing required file: {path.name}")

bot = BOT_PATH.read_text(encoding="utf-8")
voice = VOICE_PATH.read_text(encoding="utf-8")
planner = PLANNER_PATH.read_text(encoding="utf-8")

if (
    TARGET_BOT in bot
    and
    SURFACE_PATH.exists()
):
    print("3.4.0 Qwen Surface Writer is already installed.")
    raise SystemExit(0)

if EXPECTED_BOT not in bot:
    fail("Expected Bot 3.3.0-response-planner")

if EXPECTED_VOICE not in voice:
    fail("Expected Local Voice 1.3.0")

if EXPECTED_PLANNER not in planner:
    fail("Expected Response Planner 1.0")

if SURFACE_PATH.exists():
    fail(
        "surface_writer.py already exists unexpectedly. "
        "Refusing to overwrite it."
    )

for marker in (
    "8.5 RESPONSE PLANNER",
    "response_plan_text",
    "Setze jetzt den RESPONSE PLAN um",
    "await humanize_evilnae_response(",
):
    if marker not in bot:
        fail(f"Required 3.3 invariant missing: {marker}")

ok("3.3.0 Response Planner base detected")

bot = replace_once(
    bot,
    EXPECTED_BOT,
    TARGET_BOT,
    "Bot version -> 3.4.0-qwen-surface-writer",
)

bot = replace_once(
    bot,
    SIMPLE_IMPORT_OLD,
    SIMPLE_IMPORT_NEW,
    "bot.py SimpleNamespace import",
)

bot = insert_before_once(
    bot,
    "from response_planner import (\n",
    SURFACE_IMPORT,
    "bot.py imports Surface Writer",
)

bot = replace_once(
    bot,
    STARTUP_OLD,
    STARTUP_NEW,
    "Startup Surface Writer diagnostics",
)

bot = insert_before_once(
    bot,
    "        writer_token_limit = (\n",
    ROUTER_BLOCK,
    "Build Qwen-primary Writer router",
)

bot = replace_once(
    bot,
    WRITER_TASK_OLD,
    WRITER_TASK_NEW,
    "Main Writer routes through Qwen-primary callable",
)

bot = replace_once(
    bot,
    VOICE_CALL_OLD,
    VOICE_CALL_NEW,
    "Skip duplicate Qwen pass after Qwen-primary success",
)

for marker in (
    TARGET_BOT,
    "Qwen Surface Writer v",
    "primary_writer_callable(",
    "secondary_voice_callable(",
    "generate_surface_response_from_plan(",
    "openai_writer=skipped",
):
    if marker not in bot:
        fail(f"Patched bot.py missing invariant: {marker}")

for marker in (
    'SURFACE_WRITER_VERSION = "1.0"',
    "class SurfaceWriterResult",
    "async def generate_surface_response_from_plan(",
    "surface_plan_drift",
    "surface_added_new_facts",
    "surface_question_not_allowed",
    "surface_assistant_boilerplate",
):
    if marker not in SURFACE_SOURCE:
        fail(f"surface_writer.py missing invariant: {marker}")

syntax_check(bot, "bot.py")
syntax_check(voice, "local_voice.py")
syntax_check(planner, "response_planner.py")
syntax_check(SURFACE_SOURCE, "surface_writer.py")

tests = {
    "Qwen is primary route":
        "primary=qwen_surface" in bot,

    "OpenAI remains fallback":
        "fallback=openai_writer" in bot
        and
        "return await safe_openai_request(" in bot,

    "Second Qwen pass skipped":
        "qwen_already_primary" in bot,

    "No OpenAI dependency in surface module":
        "AsyncOpenAI" not in SURFACE_SOURCE
        and
        "safe_openai_request" not in SURFACE_SOURCE,

    "Plan fidelity gate":
        "surface_plan_drift" in SURFACE_SOURCE,

    "New facts gate":
        "surface_added_new_facts" in SURFACE_SOURCE,

    "Question gate":
        "surface_question_not_allowed" in SURFACE_SOURCE,

    "Voice memory included":
        "get_relevant_voice_examples" in SURFACE_SOURCE,
}

failed = [
    name
    for name, passed
    in tests.items()
    if not passed
]

if failed:
    fail(
        "Contract self-test failed: "
        + ", ".join(failed)
    )

ok(
    f"Contract self-test: "
    f"{len(tests)}/{len(tests)} PASS"
)

timestamp = (
    datetime.now()
    .astimezone()
    .strftime("%Y%m%d-%H%M%S")
)

backup_dir = (
    BACKUP_ROOT
    /
    timestamp
)

suffix = 1

while backup_dir.exists():
    backup_dir = (
        BACKUP_ROOT
        /
        f"{timestamp}_{suffix:02d}"
    )
    suffix += 1

backup_dir.mkdir(
    parents=True,
    exist_ok=False,
)

for path in (
    BOT_PATH,
    VOICE_PATH,
    PLANNER_PATH,
):
    shutil.copy2(
        path,
        backup_dir / path.name,
    )
    ok(f"Backup: {path.name}")


def atomic_write(path, text):
    tmp = Path(
        str(path)
        +
        ".tmp"
    )
    tmp.write_text(
        text,
        encoding="utf-8"
    )
    tmp.replace(
        path
    )


atomic_write(
    SURFACE_PATH,
    SURFACE_SOURCE
)
ok("Created: surface_writer.py")

atomic_write(
    BOT_PATH,
    bot
)
ok("Updated: bot.py")

result = subprocess.run(
    [
        sys.executable,
        "-m",
        "py_compile",
        str(BOT_PATH),
        str(VOICE_PATH),
        str(PLANNER_PATH),
        str(SURFACE_PATH),
    ],
    cwd=str(PROJECT_ROOT),
    check=False,
)

if result.returncode != 0:
    print()
    print("[POST-INSTALL WARNING] py_compile failed.")
    print(f"Backup: {backup_dir}")
    raise SystemExit(
        result.returncode
    )

ok("Post-install py_compile: 4/4")

result = subprocess.run(
    [
        sys.executable,
        str(SURFACE_PATH),
    ],
    cwd=str(PROJECT_ROOT),
    check=False,
)

if result.returncode != 0:
    print()
    print(
        "[POST-INSTALL WARNING] "
        "surface_writer.py self-test failed."
    )
    print(f"Backup: {backup_dir}")
    raise SystemExit(
        result.returncode
    )

ok("Self-test: surface_writer.py")

print()
print("=" * 78)
print("EVILNAE 3.4.0 QWEN PRIMARY SURFACE WRITER INSTALLED")
print("=" * 78)
print()
print("New main path:")
print("  Brain 2.4")
print("      ↓")
print("  Response Planner 1.0")
print("      ↓")
print("  Qwen Surface Writer 1.0  ← PRIMARY")
print("      ↓")
print("  Hard Guards / Quality / Emotes")
print()
print("Fallback path:")
print("  Qwen unavailable / invalid / plan drift")
print("      ↓")
print("  existing OpenAI Writer")
print("      ↓")
print("  existing Qwen Humanizer if useful")
print()
print("Installed:")
print("  [✓] Qwen writes directly from Response Plan + Core Thought")
print("  [✓] OpenAI text-writer API call is skipped on Qwen success")
print("  [✓] no duplicate Qwen rewrite after Qwen-primary success")
print("  [✓] Voice Memory examples feed Qwen surface style")
print("  [✓] trusted Foundation/State/World/Self evidence is available")
print("  [✓] plan fidelity guard")
print("  [✓] no-new-facts guard")
print("  [✓] no-unapproved-question guard")
print("  [✓] user perspective / echo guard")
print("  [✓] assistant-boilerplate guard")
print("  [✓] automatic OpenAI fallback preserved")
print()
print("Unchanged:")
print("  [✓] Foundation / Excel")
print("  [✓] Character State / Learning / Memories / DB")
print("  [✓] Response Planner semantics")
print("  [✓] Routing / Knowledge / Social Ego")
print("  [✓] Local Voice 1.3 humanizer remains fallback-only")
print("  [✓] Emote Layer")
print()
print(f"Backup: {backup_dir}")
print()
print("NO MEMORY RESET REQUIRED.")
print()
print("NEXT:")
print("  python bot.py")
print()
print("Expected startup:")
print("  Bot Version: 3.4.0-qwen-surface-writer")
print("  Qwen Surface Writer v1.0: PRIMARY")
print("  OpenAI Text Writer: FALLBACK / REPAIR")
print()
print("Expected normal reply path:")
print("  [RESPONSE PLAN] ...")
print("  [SURFACE WRITER] ...")
print("  [WRITER ROUTER] ... openai_writer=skipped")
print("  [LOCAL VOICE SECOND PASS SKIP] ...")
