from pathlib import Path
from datetime import datetime
import ast
import re
import shutil
import subprocess
import sys


# =========================================================
# EVILNAE 3.2.0 — LIVE NATURALNESS & RELIABILITY
# =========================================================
#
# Target base:
#   Bot 3.1.3-addressing-reliability
#   Understanding 1.2-social-context
#   Character State 1.1-current-activity
#   Expression 2.4
#   Output Quality 2.4
#   Performance 1.0
#
# Bundles the remaining LIVE-test issues from 2026-08-27:
#
# - automatic logfile every normal `python bot.py` start
# - third rescue actually gets a repair-budget slot
# - Evilnae own desire / intention / hypothetical != Hanae fact request
# - current facts about OTHER people need real current world evidence
# - current activity expires faster and old chat does not imply "still doing it"
# - stronger anti-bot surface
# - better goodnight phrase diversity pressure
# - stronger grammar/output cleanup
# - fast path may not bypass known bot-like phrases
# =========================================================


PROJECT_ROOT = Path(__file__).resolve().parent

FILES = {
    "bot": PROJECT_ROOT / "bot.py",
    "understanding": PROJECT_ROOT / "understanding.py",
    "state": PROJECT_ROOT / "character_state.py",
    "expression": PROJECT_ROOT / "expression.py",
    "quality": PROJECT_ROOT / "response_quality.py",
    "performance": PROJECT_ROOT / "performance.py",
}

BACKUP_ROOT = PROJECT_ROOT / "live_fix_backups"

EXPECTED = {
    "bot": 'BOT_VERSION = "3.1.3-addressing-reliability"',
    "understanding": 'UNDERSTANDING_VERSION = "1.2-social-context"',
    "state": 'CHARACTER_STATE_VERSION = "1.1-current-activity"',
    "expression": 'EXPRESSION_VERSION = "2.4"',
    "quality": 'OUTPUT_QUALITY_VERSION = "2.4"',
    "performance": 'PERFORMANCE_VERSION = "1.0"',
}

TARGET = {
    "bot": 'BOT_VERSION = "3.2.0-live-naturalness"',
    "understanding": 'UNDERSTANDING_VERSION = "1.3-intent-authority"',
    "state": 'CHARACTER_STATE_VERSION = "1.2-fresh-activity"',
    "expression": 'EXPRESSION_VERSION = "2.5"',
    "quality": 'OUTPUT_QUALITY_VERSION = "2.5"',
    "performance": 'PERFORMANCE_VERSION = "1.1-live-reliability"',
}


def header(text):
    print()
    print("=" * 78)
    print(text)
    print("=" * 78)


def ok(text):
    print(f"[OK] {text}")


def fail(text):
    print()
    print(f"[INSTALL ERROR] {text}")
    print("Nothing was overwritten by this installer.")
    print()
    raise SystemExit(1)


def read_utf8(path):
    if not path.exists():
        fail(f"Missing required file: {path.name}")
    try:
        return path.read_text(encoding="utf-8")
    except Exception as error:
        fail(f"Could not read {path.name}: {type(error).__name__}: {error}")


def atomic_write(path, text):
    temp = Path(str(path) + ".tmp")
    temp.write_text(text, encoding="utf-8")
    temp.replace(path)


def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        fail(f"{label}: expected exactly 1 match, found {count}")
    ok(label)
    return text.replace(old, new, 1)


def insert_before_once(text, marker, block, label):
    count = text.count(marker)
    if count != 1:
        fail(f"{label}: expected exactly 1 marker, found {count}")
    ok(label)
    return text.replace(marker, block + marker, 1)


def replace_section(text, start_marker, end_marker, new_section, label):
    start = text.find(start_marker)
    if start < 0:
        fail(f"{label}: start marker not found")
    end = text.find(end_marker, start + len(start_marker))
    if end < 0:
        fail(f"{label}: end marker not found")
    ok(label)
    return text[:start] + new_section + text[end:]


def syntax_check(text, filename):
    try:
        ast.parse(text, filename=filename)
    except SyntaxError as error:
        fail(
            f"{filename}: syntax error after patch at "
            f"line {error.lineno}: {error.msg}"
        )
    ok(f"{filename} syntax check")


header("EVILNAE 3.2.0 LIVE NATURALNESS & RELIABILITY")
print(f"Project: {PROJECT_ROOT}")
print()
print("WICHTIG: bot.py muss vollständig AUS sein.")
print()

contents = {key: read_utf8(path) for key, path in FILES.items()}

if all(TARGET[key] in contents[key] for key in TARGET):
    print("3.2.0 is already installed.")
    raise SystemExit(0)

for key, marker in EXPECTED.items():
    if marker not in contents[key]:
        fail(
            f"Unexpected {FILES[key].name} base. "
            f"Expected marker: {marker}"
        )

for marker in (
    "RELIABILITY DIRECT STATEMENT RESCUE SUCCESS",
    "SOCIAL STANCE / EVILNAE EGO v1",
    "_HANAE_COMPARISON_PROVOCATION_PATTERN",
):
    if marker not in contents["bot"]:
        fail(f"Required 3.1.x bot invariant missing: {marker}")

if "social_comparison_or_provocation" not in contents["understanding"]:
    fail("Understanding 1.2 social-comparison fix is missing")

ok("3.1.3 live base detected")

for key in EXPECTED:
    contents[key] = replace_once(
        contents[key], EXPECTED[key], TARGET[key], f"{FILES[key].name} version"
    )

# =========================================================
# 1) BOT — AUTOMATIC FILE LOGGING
# =========================================================

contents["bot"] = replace_once(
    contents["bot"],
    "import asyncio\nimport time\nimport sys\nfrom collections import deque\n",
    "import asyncio\nimport time\nimport sys\nimport atexit\nimport threading\nfrom collections import deque\n",
    "bot.py logging imports",
)

AUTO_LOGGING_BLOCK = r'''# =========================================================
# 3.2.0 AUTOMATIC LIVE FILE LOGGING
# =========================================================
# Every normal `python bot.py` start now writes stdout/stderr
# to logs/evilnae_YYYYMMDD_HHMMSS.log while still showing the
# same output in the terminal.
# =========================================================

AUTO_FILE_LOGGING_VERSION = "1.0"
AUTO_LOG_KEEP_FILES = 60

_AUTO_LOG_FILE = None
_AUTO_LOG_PATH = None
_AUTO_LOG_LOCK = threading.RLock()


class _EvilnaeTeeStream:

    def __init__(self, console_stream, file_stream):
        self._console_stream = console_stream
        self._file_stream = file_stream

    def write(self, data):
        value = str(data if data is not None else "")
        with _AUTO_LOG_LOCK:
            try:
                self._console_stream.write(value)
            except Exception:
                pass
            try:
                self._file_stream.write(value)
                self._file_stream.flush()
            except Exception:
                pass
        return len(value)

    def flush(self):
        with _AUTO_LOG_LOCK:
            try:
                self._console_stream.flush()
            except Exception:
                pass
            try:
                self._file_stream.flush()
            except Exception:
                pass

    def isatty(self):
        try:
            return bool(self._console_stream.isatty())
        except Exception:
            return False

    def fileno(self):
        return self._console_stream.fileno()

    @property
    def encoding(self):
        return getattr(self._console_stream, "encoding", "utf-8")

    def __getattr__(self, name):
        return getattr(self._console_stream, name)


def _prune_old_auto_logs(log_directory):
    try:
        names = sorted(
            (
                name
                for name in os.listdir(log_directory)
                if name.startswith("evilnae_") and name.endswith(".log")
            ),
            reverse=True,
        )
        for old_name in names[AUTO_LOG_KEEP_FILES:]:
            try:
                os.remove(os.path.join(log_directory, old_name))
            except Exception:
                pass
    except Exception:
        pass


def _flush_auto_log():
    try:
        if _AUTO_LOG_FILE is not None:
            _AUTO_LOG_FILE.flush()
    except Exception:
        pass


def _setup_auto_file_logging():
    global _AUTO_LOG_FILE
    global _AUTO_LOG_PATH

    log_directory = os.path.join(os.getcwd(), "logs")
    os.makedirs(log_directory, exist_ok=True)

    timestamp = time.strftime("%Y%m%d_%H%M%S")
    log_path = os.path.join(log_directory, f"evilnae_{timestamp}.log")

    try:
        log_file = open(log_path, "a", encoding="utf-8", buffering=1)
    except Exception as error:
        print(
            "[AUTO FILE LOGGING ERROR] "
            f"{type(error).__name__}: {error}"
        )
        return None

    _AUTO_LOG_FILE = log_file
    _AUTO_LOG_PATH = log_path

    original_stdout = sys.stdout
    original_stderr = sys.stderr

    sys.stdout = _EvilnaeTeeStream(original_stdout, log_file)
    sys.stderr = _EvilnaeTeeStream(original_stderr, log_file)

    atexit.register(_flush_auto_log)
    _prune_old_auto_logs(log_directory)

    print(
        "[AUTO FILE LOGGING] "
        f"v={AUTO_FILE_LOGGING_VERSION} "
        f"path={os.path.abspath(log_path)} "
        f"keep={AUTO_LOG_KEEP_FILES}"
    )

    return log_path


AUTO_LOG_PATH = _setup_auto_file_logging()


'''

contents["bot"] = insert_before_once(
    contents["bot"],
    "# =========================================================\n# VERSION\n# =========================================================\n",
    AUTO_LOGGING_BLOCK,
    "bot.py automatic logfile",
)

# =========================================================
# 2) PERFORMANCE — THIRD REPAIR SLOT + FAST PATH BLOCKERS
# =========================================================

contents["performance"] = replace_once(
    contents["performance"],
    "RESPONSE_REPAIR_BUDGET = 2",
    "RESPONSE_REPAIR_BUDGET = 3",
    "Performance repair budget -> 3",
)

FAST_PATH_BLOCKERS = r'''    re.compile(
        r"\bfreut\s+mich\s+auch\b"
        r"|\bimmer\s+schön,?\s+wenn\b"
        r"|\bwird\s+notiert\b"
        r"|\bfeierabend\s+klingt\s+verdient\b"
        r"|\bmach(?:'|’)?s\s+dir\s+gemütlich\b"
        r"|\bmach(?:'|’)?s\s+dir\s+gemuetlich\b",
        re.IGNORECASE
    ),

'''

contents["performance"] = insert_before_once(
    contents["performance"],
    '    re.compile(\n        r"\\bdas\\s+klingt\\b",\n',
    FAST_PATH_BLOCKERS,
    "Performance blocks bot-surface fast path",
)

# =========================================================
# 3) UNDERSTANDING — OWN INTENT != PERSON FACT
# =========================================================

SELF_INTENT_HELPER = r'''# =========================================================
# 1.3 EVILNAE OWN INTENT / HYPOTHETICAL
# =========================================================
# A person can be mentioned only as context/object of a
# question about Evilnae herself.
# =========================================================

EVILNAE_SELF_INTENT_PATTERNS = [
    re.compile(
        r"\bhättest\s+du\s+(?:lust|bock)\b"
        r"|\bhaettest\s+du\s+(?:lust|bock)\b",
        flags=re.IGNORECASE,
    ),
    re.compile(
        r"\bhast\s+du\s+(?:lust|bock)\b",
        flags=re.IGNORECASE,
    ),
    re.compile(
        r"\b(?:willst|möchtest|moechtest)\s+du\s+"
        r"(?!(?:wissen|sagen|erzählen|erzaehlen)\b)",
        flags=re.IGNORECASE,
    ),
    re.compile(
        r"\bwürdest\s+du\b|\bwuerdest\s+du\b",
        flags=re.IGNORECASE,
    ),
    re.compile(
        r"\bkönntest\s+du\s+dir\s+vorstellen\b"
        r"|\bkoenntest\s+du\s+dir\s+vorstellen\b",
        flags=re.IGNORECASE,
    ),
    re.compile(
        r"\bsollen\s+wir\b",
        flags=re.IGNORECASE,
    ),
]


def is_evilnae_self_intent_or_hypothetical(text: str) -> bool:
    value = str(text or "")
    return any(pattern.search(value) for pattern in EVILNAE_SELF_INTENT_PATTERNS)


'''

contents["understanding"] = insert_before_once(
    contents["understanding"],
    "# =========================================================\n# 1.2 SOCIAL COMPARISON / PROVOCATION\n# =========================================================\n",
    SELF_INTENT_HELPER,
    "Understanding own-intent helper",
)

contents["understanding"] = replace_once(
    contents["understanding"],
    '''    if is_evilnae_opinion_question(
        user_text,
        subject_name
    ):

        return KnowledgeConstraint(
''',
    '''    if is_evilnae_self_intent_or_hypothetical(
        user_text
    ):

        return KnowledgeConstraint(

            active=False,

            subject_name=(
                subject_name
            ),

            subject_id=(
                subject_id
            ),

            knowledge_available=(
                knowledge_available
            ),

            knowledge_source=(
                knowledge_source
            ),

            reason=(
                "evilnae_self_intent_or_hypothetical"
            )
        )

    if is_evilnae_opinion_question(
        user_text,
        subject_name
    ):

        return KnowledgeConstraint(
''',
    "Understanding bypasses knowledge guard for Evilnae own intent",
)

OLD_SUBJECT_AUTH = '''        # Knowledge availability is SUBJECT-SCOPED.
        # A random Self/Foundation fact about Evilnae must never authorize a
        # factual claim about Hanae merely because the Brain returned True.
        subject_authorized = (
            knowledge_source == "conversation_world"
            or _foundation_authorizes_subject_fact(
                user_text,
                subject_name,
            )
        )

        if subject_authorized:
            return KnowledgeConstraint(

                active=False,

                subject_name=(
                    subject_name
                ),

                subject_id=(
                    subject_id
                ),

                scope=(
                    infer_knowledge_scope(
                        user_text
                    )
                ),
'''

NEW_SUBJECT_AUTH = '''        # Knowledge availability is SUBJECT-SCOPED.
        # CURRENT facts are stricter than stable/person facts:
        # Foundation canon can never prove what another person does RIGHT NOW.
        requested_scope = (
            infer_knowledge_scope(
                user_text
            )
        )

        if requested_scope == "current":

            subject_authorized = (
                knowledge_source
                ==
                "conversation_world"
            )

        else:

            subject_authorized = (
                knowledge_source
                ==
                "conversation_world"
                or
                _foundation_authorizes_subject_fact(
                    user_text,
                    subject_name,
                )
            )

        if subject_authorized:
            return KnowledgeConstraint(

                active=False,

                subject_name=(
                    subject_name
                ),

                subject_id=(
                    subject_id
                ),

                scope=(
                    requested_scope
                ),
'''

contents["understanding"] = replace_once(
    contents["understanding"],
    OLD_SUBJECT_AUTH,
    NEW_SUBJECT_AUTH,
    "Understanding current facts require Conversation World",
)

# =========================================================
# 4) BOT — OTHER-PERSON CURRENT FACT GUARD
# =========================================================

NEW_CURRENT_FACT_FUNCTION = r'''def has_unsupported_current_fact(
    answer,
    decision
):

    if not answer:
        return False

    answer_text = str(answer or "")

    suspicious_patterns = [
        r"\b(?:sie|er)\s+ist\s+gerade\b",
        r"\b(?:sie|er)\s+macht\s+gerade\b",
        r"\b(?:sie|er)\s+schaut\s+gerade\b",
        r"\b(?:sie|er)\s+spielt\s+gerade\b",
        r"\b(?:sie|er)\s+sitzt\s+gerade\b",
        r"\b(?:sie|er)\s+liegt\s+gerade\b",
        r"\b(?:sie|er)\s+arbeitet\s+gerade\b",
        r"\b(?:sie|er)\s+ist\s+jetzt\b",
        r"\b(?:sie|er)\s+macht\s+jetzt\b",
        r"\b(?:hanae|error)\b.{0,45}\b(?:gerade|jetzt|aktuell|momentan)\b",
        r"\b(?:hanae|error)\s+"
        r"(?:ist|macht|schaut|guckt|spielt|sitzt|liegt|arbeitet|bereitet|streamt|isst|trinkt)\b"
        r".{0,55}\b(?:gerade|jetzt|aktuell|momentan)\b",
    ]

    suspicious = any(
        re.search(pattern, answer_text, flags=re.IGNORECASE)
        for pattern in suspicious_patterns
    )

    if not suspicious:
        return False

    knowledge_available = bool(
        getattr(decision, "knowledge_available", False)
    )
    knowledge_source = str(
        getattr(decision, "knowledge_source", "unknown") or "unknown"
    )

    # Current facts about someone else need explicit Conversation World evidence.
    if knowledge_available and knowledge_source == "conversation_world":
        return False

    return True


'''

contents["bot"] = replace_section(
    contents["bot"],
    "def has_unsupported_current_fact(\n",
    "def character_identity_violation_reasons(",
    NEW_CURRENT_FACT_FUNCTION,
    "bot.py stricter other-person current-fact guard",
)

# =========================================================
# 5) CHARACTER STATE — FRESHER ACTIVITY TTL
# =========================================================

OLD_TTL = '''TTL_SECONDS = {
    "location": 4 * 60 * 60,
    "activity": 2 * 60 * 60,
    "game": 3 * 60 * 60,
    "food": 90 * 60,
    "drink": 2 * 60 * 60,
    "music": 60 * 60,
    "outfit": 12 * 60 * 60,
    "weather": 2 * 60 * 60,
}
'''

NEW_TTL = '''TTL_SECONDS = {
    "location": 2 * 60 * 60,
    "activity": 45 * 60,
    "game": 90 * 60,
    "food": 45 * 60,
    "drink": 60 * 60,
    "music": 45 * 60,
    "outfit": 12 * 60 * 60,
    "weather": 2 * 60 * 60,
}
'''

contents["state"] = replace_once(
    contents["state"], OLD_TTL, NEW_TTL, "Character State shorter live TTLs"
)

NEW_ACTIVE_STATES = r'''def _active_states() -> dict:
    now = time.time()
    changed = False

    with _LOCK:
        data = _load()
        states = data.get("states", {})

        for key in list(states):
            state = states.get(key, {})

            try:
                stored_expires_at = float(state.get("expires_at") or 0.0)
            except Exception:
                stored_expires_at = 0.0

            try:
                updated_at = float(
                    state.get("updated_at")
                    or state.get("created_at")
                    or 0.0
                )
            except Exception:
                updated_at = 0.0

            current_ttl = TTL_SECONDS.get(key, 60 * 60)
            ttl_cap = updated_at + current_ttl if updated_at else 0.0

            candidates = [
                value
                for value in (stored_expires_at, ttl_cap)
                if value > 0.0
            ]
            effective_expires_at = min(candidates) if candidates else 0.0

            if effective_expires_at and effective_expires_at < now:
                states.pop(key, None)
                changed = True
                continue

            if effective_expires_at and stored_expires_at != effective_expires_at:
                state["expires_at"] = effective_expires_at
                changed = True

        if changed:
            _save(data)

        return dict(states)


'''

contents["state"] = replace_section(
    contents["state"],
    "def _active_states() -> dict:\n",
    "def _asks_current_activity(",
    NEW_ACTIVE_STATES,
    "Character State retroactive TTL cap",
)

contents["state"] = replace_once(
    contents["state"],
    '''                    "Die allgemeine No-Invention-Regel gilt hier NICHT gegen solche erlaubten Alltagsaktivitäten.",
                    "Wähle GENAU EINE konkrete Sache, die sie gerade macht, statt vage 'chillen', 'nichts' oder 'rumhängen' zu antworten.",
''',
    '''                    "Die allgemeine No-Invention-Regel gilt hier NICHT gegen solche erlaubten Alltagsaktivitäten.",
                    "ÄLTERE Chat-Nachrichten über eine frühere Tätigkeit bedeuten NICHT automatisch, dass Evilnae sie Stunden später noch macht.",
                    "Wenn kein aktiver State mehr existiert, entscheide ihren aktuellen Alltag neu statt eine alte Tätigkeit aus dem Channel-Verlauf fortzuschreiben.",
                    "Wähle GENAU EINE konkrete Sache, die sie gerade macht, statt vage 'chillen', 'nichts' oder 'rumhängen' zu antworten.",
''',
    "Character State old-chat activity freshness rule",
)

# =========================================================
# 6) EXPRESSION — HARDER ANTI-BOT SURFACE
# =========================================================

BOT_SURFACE_PATTERNS = r'''# =========================================================
# 2.5 EVILNAE BOT-SURFACE PHRASES
# =========================================================

EVILNAE_BOT_SURFACE_PATTERNS = [
    re.compile(r"\bfreut\s+mich\s+auch\b", flags=re.IGNORECASE),
    re.compile(
        r"\bimmer\s+schön,?\s+wenn\b|\bimmer\s+schoen,?\s+wenn\b",
        flags=re.IGNORECASE,
    ),
    re.compile(r"\bwird\s+notiert\b", flags=re.IGNORECASE),
    re.compile(r"\bfeierabend\s+klingt\s+verdient\b", flags=re.IGNORECASE),
    re.compile(
        r"\bmach(?:'|’)?s\s+dir\s+gemütlich\b"
        r"|\bmach(?:'|’)?s\s+dir\s+gemuetlich\b",
        flags=re.IGNORECASE,
    ),
]


'''

contents["expression"] = insert_before_once(
    contents["expression"],
    "# =========================================================\n# NORMALIZATION\n# =========================================================\n",
    BOT_SURFACE_PATTERNS,
    "Expression Evilnae-specific bot-surface patterns",
)

contents["expression"] = replace_once(
    contents["expression"],
    '''- Bei Smalltalk lieber eine konkrete eigene Haltung, einen trockenen Nebensatz, einen kleinen passenden Roast oder ein persönliches Detail als leere Positivität.
- Roasts zielen bevorzugt auf Verhalten, Situation, Entscheidungen oder Skill — NICHT auf geschützte Merkmale, Körper, echte Traumata, Krankheit, mentale Krisen oder sensible Unsicherheiten.
''',
    '''- Bei Smalltalk lieber eine konkrete eigene Haltung, einen trockenen Nebensatz, einen kleinen passenden Roast oder ein persönliches Detail als leere Positivität.
- Fragen nach Evilnaes eigener Lust, Absicht oder hypothetischem Verhalten beantwortet sie mit EINER eigenen Haltung — nicht mit "weiß ich nicht", nur weil Hanae im Satz vorkommt.
- Bei mehreren Gute-Nacht-Nachrichten hintereinander NICHT jeden User mit derselben "Gute Nacht / schlaf gut / träum schön"-Schablone bedienen. Kurz variieren: trockener Kommentar, kleiner Roast, "bis morgen", knapper Abschied oder passende Reaction-Energy.
- Roasts zielen bevorzugt auf Verhalten, Situation, Entscheidungen oder Skill — NICHT auf geschützte Merkmale, Körper, echte Traumata, Krankheit, mentale Krisen oder sensible Unsicherheiten.
''',
    "Expression own-intent + goodnight diversity guidance",
)

EXPRESSION_BOT_CHECK = r'''    # =====================================================
    # EVILNAE-SPECIFIC BOT SURFACE
    # =====================================================

    if any(
        pattern.search(answer)
        for pattern in EVILNAE_BOT_SURFACE_PATTERNS
    ):
        reasons.append("evilnae_bot_surface")

'''

contents["expression"] = insert_before_once(
    contents["expression"],
    "    # =====================================================\n    # GENERIC FILLER\n    # =====================================================\n",
    EXPRESSION_BOT_CHECK,
    "Expression blocks known bot-surface phrases",
)

# =========================================================
# 7) OUTPUT QUALITY — DIVERSITY + GRAMMAR
# =========================================================

QUALITY_GENERIC_PATTERNS = r'''    "bot_happy_mirror": (
        re.compile(
            r"\bfreut\s+mich\s+auch\b"
            r"|\bimmer\s+schön,?\s+wenn\b"
            r"|\bimmer\s+schoen,?\s+wenn\b",
            re.I
        ), 4
    ),
    "assistant_noted_schedule": (
        re.compile(r"\bwird\s+notiert\b", re.I), 4
    ),
    "assistant_deserved_validation": (
        re.compile(r"\bfeierabend\s+klingt\s+verdient\b", re.I), 4
    ),
    "cozy_service_phrase": (
        re.compile(
            r"\bmach(?:'|’)?s\s+dir\s+gemütlich\b"
            r"|\bmach(?:'|’)?s\s+dir\s+gemuetlich\b",
            re.I
        ), 3
    ),
'''

contents["quality"] = insert_before_once(
    contents["quality"],
    '    "sounds_like_wrapper": (\n',
    QUALITY_GENERIC_PATTERNS,
    "Output Quality bot-surface penalties",
)

GOODNIGHT_FAMILIES = r'''    "goodnight_sleep": (
        re.compile(
            r"\b(?:gute\s+nacht|schlaf\s+(?:gut|schön|schoen))\b",
            re.I
        ),
    ),
    "goodnight_dream": (
        re.compile(
            r"\bträum\w*.{0,30}\b(?:schön|schoen|süß|suess|was)\b"
            r"|\bträum\s+was\b",
            re.I
        ),
    ),
    "goodnight_comfy": (
        re.compile(
            r"\bmach(?:'|’)?s\s+dir\s+(?:gemütlich|gemuetlich)\b",
            re.I
        ),
    ),
'''

contents["quality"] = insert_before_once(
    contents["quality"],
    '    "goodnight_spooky": (\n',
    GOODNIGHT_FAMILIES,
    "Output Quality goodnight phrase families",
)

GRAMMAR_PATTERNS = r'''LEADING_PUNCTUATION_PATTERN = re.compile(
    r"^\s*[!?;,]{1,3}\s+",
    re.I
)

BAD_CASE_AFTER_ZU_PATTERN = re.compile(
    r"\bzu\s+(?:ihre|seine|deine|meine|unsere|eure)\b",
    re.I
)


'''

contents["quality"] = insert_before_once(
    contents["quality"],
    "REPEATED_WORD_PATTERN = re.compile(\n",
    GRAMMAR_PATTERNS,
    "Output Quality extra grammar patterns",
)

QUALITY_GRAMMAR_CHECK = r'''    if LEADING_PUNCTUATION_PATTERN.search(text):
        issues.append("leading_punctuation_fragment")
        grammar_score += 3

    if BAD_CASE_AFTER_ZU_PATTERN.search(text):
        issues.append("bad_case_after_zu")
        grammar_score += 3

'''

contents["quality"] = insert_before_once(
    contents["quality"],
    "    if REPEATED_WORD_PATTERN.search(\n        text\n    ):\n",
    QUALITY_GRAMMAR_CHECK,
    "Output Quality leading punctuation + dative-case checks",
)

contents["quality"] = replace_once(
    contents["quality"],
    '''- Keine kaputten Satzfragmente oder Komma-Wortketten.
- Die Antwort braucht echten Text mit mindestens einem Wort.
''',
    '''- Keine kaputten Satzfragmente oder Komma-Wortketten.
- Keine führenden Satzzeichenreste wie "! Ich hab...".
- Bei mehreren Gute-Nacht-Antworten nicht dieselbe Schlaf-/Traum-Schablone wiederverwenden.
- Die Antwort braucht echten Text mit mindestens einem Wort.
''',
    "Output Quality repair guidance",
)

# =========================================================
# VERIFY PATCH INVARIANTS
# =========================================================

required_markers = {
    "bot": (
        TARGET["bot"],
        "AUTO_FILE_LOGGING_VERSION",
        "[AUTO FILE LOGGING]",
        "knowledge_source == \"conversation_world\"",
    ),
    "understanding": (
        TARGET["understanding"],
        "EVILNAE_SELF_INTENT_PATTERNS",
        "evilnae_self_intent_or_hypothetical",
        'requested_scope == "current"',
    ),
    "state": (
        TARGET["state"],
        '"activity": 45 * 60',
        "ÄLTERE Chat-Nachrichten",
    ),
    "expression": (
        TARGET["expression"],
        "EVILNAE_BOT_SURFACE_PATTERNS",
        "evilnae_bot_surface",
        "mehreren Gute-Nacht-Nachrichten",
    ),
    "quality": (
        TARGET["quality"],
        "bot_happy_mirror",
        "goodnight_sleep",
        "leading_punctuation_fragment",
        "bad_case_after_zu",
    ),
    "performance": (
        TARGET["performance"],
        "RESPONSE_REPAIR_BUDGET = 3",
        "feierabend",
    ),
}

for key, markers in required_markers.items():
    for marker in markers:
        if marker not in contents[key]:
            fail(f"Patched {FILES[key].name} missing invariant: {marker}")

for key, text in contents.items():
    syntax_check(text, FILES[key].name)

# =========================================================
# INSTALLER-LEVEL BEHAVIOR SELF TESTS
# =========================================================

intent_patterns = [
    re.compile(r"\bhättest\s+du\s+(?:lust|bock)\b|\bhaettest\s+du\s+(?:lust|bock)\b", re.I),
    re.compile(r"\bhast\s+du\s+(?:lust|bock)\b", re.I),
    re.compile(
        r"\b(?:willst|möchtest|moechtest)\s+du\s+"
        r"(?!(?:wissen|sagen|erzählen|erzaehlen)\b)",
        re.I,
    ),
    re.compile(r"\bwürdest\s+du\b|\bwuerdest\s+du\b", re.I),
]


def own_intent(text):
    return any(pattern.search(text) for pattern in intent_patterns)


behavior_tests = {
    "Hanae stream chaos is Evilnae own intent": own_intent(
        "Evil, hättest du Lust Hanaes Stream ins Chaos zu stürzen?"
    ),
    "Hanae action hypothetical is own intent": own_intent(
        "Würdest du mit Hanae Valorant spielen?"
    ),
    "embedded Hanae fact request is NOT own intent": not own_intent(
        "Willst du wissen was Hanae gerade macht?"
    ),
    "leading punctuation pattern": bool(
        re.search(r"^\s*[!?;,]{1,3}\s+", "! Ich hab wie ein Stein geschlafen")
    ),
    "bad zu-case pattern": bool(
        re.search(
            r"\bzu\s+(?:ihre|seine|deine|meine|unsere|eure)\b",
            "nichts im Vergleich zu ihre wilden Abenteuer",
            flags=re.I,
        )
    ),
}

failed_behavior = [name for name, passed in behavior_tests.items() if not passed]
if failed_behavior:
    fail("Behavior self-test failed: " + ", ".join(failed_behavior))

ok(f"Behavior self-test: {len(behavior_tests)}/{len(behavior_tests)} PASS")

# =========================================================
# BACKUP — COLLISION SAFE
# =========================================================

timestamp = datetime.now().astimezone().strftime("%Y%m%d-%H%M%S")
backup_directory = BACKUP_ROOT / timestamp

if backup_directory.exists():
    suffix = 1
    while True:
        candidate = BACKUP_ROOT / f"{timestamp}_{suffix:02d}"
        if not candidate.exists():
            backup_directory = candidate
            break
        suffix += 1
        if suffix > 99:
            fail(f"Could not find free backup suffix for {timestamp}")

try:
    backup_directory.mkdir(parents=True, exist_ok=False)
except Exception as error:
    fail(
        "Could not create backup directory: "
        f"{type(error).__name__}: {error}"
    )

for path in FILES.values():
    try:
        shutil.copy2(path, backup_directory / path.name)
    except Exception as error:
        fail(
            f"Backup failed for {path.name}: "
            f"{type(error).__name__}: {error}"
        )
    ok(f"Backup: {path.name}")

# =========================================================
# WRITE
# =========================================================

try:
    for key, path in FILES.items():
        atomic_write(path, contents[key])
        ok(f"Updated: {path.name}")
except Exception as error:
    print()
    print(f"[WRITE ERROR] {type(error).__name__}: {error}")
    print(f"Backups: {backup_directory}")
    raise

# =========================================================
# POST-WRITE COMPILE + SAFE SELF TESTS
# =========================================================

compile_result = subprocess.run(
    [sys.executable, "-m", "py_compile", *[str(path) for path in FILES.values()]],
    cwd=str(PROJECT_ROOT),
    check=False,
)

if compile_result.returncode != 0:
    print()
    print("[POST-INSTALL WARNING] py_compile failed.")
    print(f"Backup: {backup_directory}")
    raise SystemExit(compile_result.returncode)

ok("Post-install py_compile: 6/6")

for module_name in ("response_quality.py", "character_state.py"):
    result = subprocess.run(
        [sys.executable, module_name],
        cwd=str(PROJECT_ROOT),
        check=False,
    )
    if result.returncode != 0:
        print()
        print(f"[POST-INSTALL WARNING] {module_name} self-test failed.")
        print(f"Backup: {backup_directory}")
        raise SystemExit(result.returncode)
    ok(f"Self-test: {module_name}")

header("EVILNAE 3.2.0 LIVE NATURALNESS & RELIABILITY INSTALLED")
print("Installed:")
print("  [✓] automatic logs on every normal python bot.py start")
print("  [✓] repair budget 2 -> 3 so the final Direct rescue can actually run")
print("  [✓] Evilnae desire/intention/hypothetical no longer becomes Hanae fact lookup")
print("  [✓] current other-person facts require Conversation World evidence")
print("  [✓] Foundation cannot authorize what another person is doing RIGHT NOW")
print("  [✓] activity TTL 2h -> 45m; game 3h -> 90m")
print("  [✓] old saved activity is immediately capped to the new TTL")
print("  [✓] old channel activity is not automatically treated as still current")
print("  [✓] stronger Evilnae-specific anti-bot surface guard")
print("  [✓] fast path cannot skip known bot-like phrases")
print("  [✓] stronger goodnight repetition/diversity pressure")
print("  [✓] leading punctuation and common 'zu ihre' grammar break detected")
print()
print("Unchanged:")
print("  [✓] Character Foundation / Excel")
print("  [✓] Character Learning / Memories / DB")
print("  [✓] Social Ego / Roast system")
print("  [✓] Routing Hardening 1.2")
print("  [✓] Emote system (whatever local 1.2/1.3 version is installed)")
print("  [✓] larger Planner / Episodes / Learning 2.0 roadmap")
print()
print(f"Backup: {backup_directory}")
print()
print("NO MEMORY RESET REQUIRED.")
print()
print("NEXT:")
print("  python bot.py")
print()
print("Expected early startup line:")
print("  [AUTO FILE LOGGING] v=1.0 path=...\\logs\\evilnae_YYYYMMDD_HHMMSS.log")
print()
