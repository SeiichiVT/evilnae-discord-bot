
from pathlib import Path
from datetime import datetime

import ast
import shutil
import subprocess
import sys

PROJECT_ROOT = Path(__file__).resolve().parent

BOT_PATH = PROJECT_ROOT / "bot.py"
EPISODES_PATH = PROJECT_ROOT / "conversation_episodes.py"
SALIENCE_PATH = PROJECT_ROOT / "emotional_salience.py"

BACKUP_ROOT = PROJECT_ROOT / "live_fix_backups"

EXPECTED_BOT = 'BOT_VERSION = "3.5.0-conversation-episodes"'
TARGET_BOT = 'BOT_VERSION = "3.6.0-emotional-salience"'

SALIENCE_SOURCE = 'import hashlib\nimport json\nimport os\nimport re\nimport threading\nimport time\nfrom collections import Counter\nfrom dataclasses import dataclass, field\nfrom pathlib import Path\nfrom typing import Any\n\nfrom conversation_episodes import (\n    EPISODE_STATE_PATH,\n)\n\n\nEMOTIONAL_SALIENCE_VERSION = "1.0"\n\nSALIENCE_STATE_PATH = Path(\n    os.getenv(\n        "EVILNAE_SALIENCE_STATE_PATH",\n        "evilnae_salience.json",\n    )\n)\n\nSALIENCE_MAX_EPISODES = int(\n    os.getenv(\n        "EVILNAE_SALIENCE_MAX_EPISODES",\n        "240",\n    )\n)\n\nRETENTION_CANDIDATE_THRESHOLD = float(\n    os.getenv(\n        "EVILNAE_SALIENCE_RETENTION_THRESHOLD",\n        "0.50",\n    )\n)\n\n_LOCK = threading.RLock()\n\n\n@dataclass\nclass SalienceResult:\n    episode_id: str = ""\n    event_score: float = 0.0\n    event_level: str = "mundane"\n    valence: str = "neutral"\n    signals: list[str] = field(\n        default_factory=list\n    )\n    episode_score: float = 0.0\n    retention_candidate: bool = False\n    duplicate: bool = False\n\n\ndef _default_data():\n    return {\n        "version": EMOTIONAL_SALIENCE_VERSION,\n        "episodes": {},\n    }\n\n\ndef _load():\n    if not SALIENCE_STATE_PATH.exists():\n        return _default_data()\n\n    try:\n        data = json.loads(\n            SALIENCE_STATE_PATH.read_text(\n                encoding="utf-8"\n            )\n        )\n    except Exception:\n        return _default_data()\n\n    if not isinstance(data, dict):\n        return _default_data()\n\n    data.setdefault(\n        "version",\n        EMOTIONAL_SALIENCE_VERSION,\n    )\n    data.setdefault(\n        "episodes",\n        {},\n    )\n\n    return data\n\n\ndef _save(data):\n    data[\n        "version"\n    ] = EMOTIONAL_SALIENCE_VERSION\n\n    temp = Path(\n        str(SALIENCE_STATE_PATH)\n        +\n        ".tmp"\n    )\n\n    temp.write_text(\n        json.dumps(\n            data,\n            ensure_ascii=False,\n            indent=2,\n        ),\n        encoding="utf-8",\n    )\n\n    temp.replace(\n        SALIENCE_STATE_PATH\n    )\n\n\ndef _clean(value: Any, limit=500):\n    text = re.sub(\n        r"\\s+",\n        " ",\n        str(value or ""),\n    ).strip()\n\n    return text[:limit]\n\n\ndef _clamp01(value):\n    try:\n        number = float(value)\n    except Exception:\n        number = 0.0\n\n    return max(\n        0.0,\n        min(\n            1.0,\n            number,\n        ),\n    )\n\n\ndef _level(score):\n    score = _clamp01(score)\n\n    if score >= 0.70:\n        return "significant"\n\n    if score >= 0.45:\n        return "important"\n\n    if score >= 0.20:\n        return "notable"\n\n    return "mundane"\n\n\ndef _event_key(\n    *,\n    message_id,\n    user_id,\n    text,\n):\n    if message_id:\n        return (\n            "msg:"\n            +\n            str(message_id)\n        )\n\n    raw = (\n        f"{user_id}|"\n        f"{text}"\n    )\n\n    return (\n        "hash:"\n        +\n        hashlib.sha1(\n            raw.encode(\n                "utf-8",\n                errors="ignore",\n            )\n        ).hexdigest()\n    )\n\n\nMUNDANE_ONLY_PATTERNS = [\n    re.compile(\n        r"^\\s*(?:hi|hey|huhu|moin|morgen|guten morgen|"\n        r"gute nacht|nacht|bye|tschüss|tschuess|bis morgen)"\n        r"[!.? ]*$",\n        re.I,\n    ),\n    re.compile(\n        r"^\\s*(?:lol|lmao|xd|xD|haha+|hehe+|jo|jup|jap|"\n        r"okay|ok|true|real|same)[!.? ]*$",\n        re.I,\n    ),\n]\n\nPOSITIVE_RELATION_PATTERNS = [\n    re.compile(\n        r"\\b(?:ich\\s+mag\\s+dich|hab\\s+dich\\s+lieb|"\n        r"ich\\s+liebe\\s+dich|du\\s+bist\\s+mir\\s+wichtig|"\n        r"du\\s+bist\\s+die\\s+beste|du\\s+bist\\s+süß|"\n        r"du\\s+bist\\s+suess)\\b",\n        re.I,\n    ),\n]\n\nNEGATIVE_RELATION_PATTERNS = [\n    re.compile(\n        r"\\b(?:ich\\s+hasse\\s+dich|ich\\s+mag\\s+dich\\s+nicht|"\n        r"du\\s+nervst|du\\s+bist\\s+gemein|"\n        r"bin\\s+enttäuscht\\s+von\\s+dir|"\n        r"bin\\s+enttaeuscht\\s+von\\s+dir)\\b",\n        re.I,\n    ),\n]\n\nAPOLOGY_PATTERNS = [\n    re.compile(\n        r"\\b(?:sorry|tut\\s+mir\\s+leid|verzeih(?:\\s+mir)?|"\n        r"entschuldige|entschuldigung)\\b",\n        re.I,\n    ),\n]\n\nVULNERABILITY_PATTERNS = [\n    re.compile(\n        r"\\b(?:mir\\s+geht\'?s\\s+(?:nicht\\s+gut|schlecht)|"\n        r"ich\\s+bin\\s+traurig|ich\\s+hab(?:e)?\\s+angst|"\n        r"ich\\s+fühl(?:e)?\\s+mich\\s+einsam|"\n        r"ich\\s+fuehl(?:e)?\\s+mich\\s+einsam|"\n        r"ich\\s+bin\\s+überfordert|ich\\s+bin\\s+ueberfordert|"\n        r"ich\\s+weine|ich\\s+heule|panik|"\n        r"macht\\s+mich\\s+fertig)\\b",\n        re.I,\n    ),\n]\n\nEXPLICIT_FEEDBACK_PATTERNS = [\n    re.compile(\n        r"\\b(?:deine\\s+antwort|deine\\s+reaktion|"\n        r"du\\s+hast\\s+(?:gerade\\s+)?(?:so|voll|echt)\\s+"\n        r"(?:süß|suess|gemein|kalt|lieb)\\s+reagiert|"\n        r"mehr\\s+nicht\\?|"\n        r"das\\s+war\\s+(?:süß|suess|gemein|kalt|lieb)|"\n        r"hätte\\s+.*\\s+süßer\\s+reagiert|"\n        r"haette\\s+.*\\s+suesser\\s+reagiert)\\b",\n        re.I,\n    ),\n]\n\nCORRECTION_PATTERNS = [\n    re.compile(\n        r"\\b(?:das\\s+stimmt\\s+nicht|das\\s+ist\\s+falsch|"\n        r"nein[, ]+evil|du\\s+hast\\s+.*\\s+verwechselt|"\n        r"ich\\s+meinte\\s+doch|das\\s+hab\\s+ich\\s+nicht\\s+gesagt|"\n        r"das\\s+habe\\s+ich\\s+nicht\\s+gesagt)\\b",\n        re.I,\n    ),\n]\n\nCALLBACK_PATTERNS = [\n    re.compile(\n        r"\\b(?:weißt\\s+du\\s+noch|weisst\\s+du\\s+noch|"\n        r"erinnerst\\s+du\\s+dich|wie\\s+gestern|"\n        r"wie\\s+letztens|unser\\s+running\\s+gag)\\b",\n        re.I,\n    ),\n]\n\nMILESTONE_PATTERNS = [\n    re.compile(\n        r"\\b(?:endlich\\s+geschafft|ich\\s+hab(?:e)?\\s+es\\s+geschafft|"\n        r"bestanden|gewonnen|job\\s+bekommen|"\n        r"beförderung|befoerderung|geburtstag|"\n        r"jubiläum|jubilaeum)\\b",\n        re.I,\n    ),\n]\n\nPERSONAL_PREFERENCE_PATTERNS = [\n    re.compile(\n        r"\\b(?:mein(?:e|er)?\\s+lieblings\\w+|"\n        r"ich\\s+liebe\\s+(?!dich\\b)|"\n        r"ich\\s+hasse\\s+(?!dich\\b)|"\n        r"ich\\s+spiele\\s+am\\s+liebsten|"\n        r"ich\\s+schaue\\s+am\\s+liebsten)\\b",\n        re.I,\n    ),\n]\n\n\ndef analyze_event_salience(\n    text,\n    *,\n    direct=False,\n    is_hanae=False,\n):\n    value = _clean(\n        text,\n        1200,\n    )\n\n    lower = value.lower()\n\n    if not value:\n        return (\n            0.0,\n            "mundane",\n            "neutral",\n            [],\n        )\n\n    if any(\n        pattern.search(value)\n        for pattern\n        in MUNDANE_ONLY_PATTERNS\n    ):\n        return (\n            0.05,\n            "mundane",\n            "neutral",\n            ["routine_smalltalk"],\n        )\n\n    score = 0.08\n    signals = []\n    positive = 0\n    negative = 0\n\n    if direct:\n        score += 0.04\n        signals.append(\n            "direct_interaction"\n        )\n\n    if is_hanae:\n        score += 0.03\n        signals.append(\n            "hanae_relationship_context"\n        )\n\n    if any(\n        pattern.search(value)\n        for pattern\n        in POSITIVE_RELATION_PATTERNS\n    ):\n        score += 0.46\n        positive += 2\n        signals.append(\n            "positive_relationship_signal"\n        )\n\n    if any(\n        pattern.search(value)\n        for pattern\n        in NEGATIVE_RELATION_PATTERNS\n    ):\n        score += 0.46\n        negative += 2\n        signals.append(\n            "negative_relationship_signal"\n        )\n\n    if any(\n        pattern.search(value)\n        for pattern\n        in APOLOGY_PATTERNS\n    ):\n        score += 0.34\n        signals.append(\n            "relationship_repair"\n        )\n\n    if any(\n        pattern.search(value)\n        for pattern\n        in VULNERABILITY_PATTERNS\n    ):\n        score += 0.48\n        negative += 2\n        signals.append(\n            "vulnerability"\n        )\n\n    if any(\n        pattern.search(value)\n        for pattern\n        in EXPLICIT_FEEDBACK_PATTERNS\n    ):\n        score += 0.44\n        signals.append(\n            "explicit_feedback"\n        )\n\n        if (\n            "süß" in lower\n            or\n            "suess" in lower\n            or\n            "lieb" in lower\n        ):\n            positive += 1\n\n        if (\n            "gemein" in lower\n            or\n            "kalt" in lower\n            or\n            "mehr nicht" in lower\n        ):\n            negative += 1\n\n    if any(\n        pattern.search(value)\n        for pattern\n        in CORRECTION_PATTERNS\n    ):\n        score += 0.36\n        signals.append(\n            "explicit_correction"\n        )\n\n    if any(\n        pattern.search(value)\n        for pattern\n        in CALLBACK_PATTERNS\n    ):\n        score += 0.28\n        signals.append(\n            "shared_callback"\n        )\n\n    if any(\n        pattern.search(value)\n        for pattern\n        in MILESTONE_PATTERNS\n    ):\n        score += 0.30\n        positive += 1\n        signals.append(\n            "personal_milestone"\n        )\n\n    if any(\n        pattern.search(value)\n        for pattern\n        in PERSONAL_PREFERENCE_PATTERNS\n    ):\n        score += 0.18\n        signals.append(\n            "personal_preference"\n        )\n\n    word_count = len(\n        re.findall(\n            r"[A-Za-zÄÖÜäöüß0-9]+",\n            value,\n        )\n    )\n\n    if word_count >= 24:\n        score += 0.05\n        signals.append(\n            "substantial_disclosure"\n        )\n\n    if not signals:\n        signals.append(\n            "ordinary_interaction"\n        )\n\n    score = _clamp01(\n        score\n    )\n\n    if positive > negative:\n        valence = "positive"\n    elif negative > positive:\n        valence = "negative"\n    elif positive and negative:\n        valence = "mixed"\n    else:\n        valence = "neutral"\n\n    return (\n        score,\n        _level(score),\n        valence,\n        signals,\n    )\n\n\ndef _episode_score(record):\n    max_score = _clamp01(\n        record.get(\n            "max_event_score",\n            0.0,\n        )\n    )\n\n    important_count = int(\n        record.get(\n            "important_event_count",\n            0,\n        )\n        or 0\n    )\n\n    signal_count = len(\n        record.get(\n            "signal_counts",\n            {}\n        )\n        or {}\n    )\n\n    return _clamp01(\n        max_score\n        +\n        min(\n            0.16,\n            important_count\n            *\n            0.035,\n        )\n        +\n        min(\n            0.08,\n            signal_count\n            *\n            0.01,\n        )\n    )\n\n\ndef observe_salience_event(\n    *,\n    episode_id,\n    channel_id,\n    user_id,\n    username,\n    text,\n    message_id="",\n    direct=False,\n    is_hanae=False,\n):\n    episode_id = str(\n        episode_id\n        or ""\n    )\n\n    if not episode_id:\n        return SalienceResult()\n\n    text = _clean(\n        text,\n        1200,\n    )\n\n    (\n        event_score,\n        event_level,\n        valence,\n        signals,\n    ) = analyze_event_salience(\n        text,\n        direct=direct,\n        is_hanae=is_hanae,\n    )\n\n    key = _event_key(\n        message_id=message_id,\n        user_id=user_id,\n        text=text,\n    )\n\n    with _LOCK:\n        data = _load()\n        episodes = data[\n            "episodes"\n        ]\n\n        record = dict(\n            episodes.get(\n                episode_id,\n                {}\n            )\n            or {}\n        )\n\n        if not record:\n            record = {\n                "episode_id":\n                    episode_id,\n                "channel_id":\n                    str(channel_id),\n                "status":\n                    "active",\n                "created_at":\n                    time.time(),\n                "updated_at":\n                    time.time(),\n                "event_count":\n                    0,\n                "important_event_count":\n                    0,\n                "max_event_score":\n                    0.0,\n                "episode_score":\n                    0.0,\n                "signal_counts":\n                    {},\n                "valence_counts":\n                    {},\n                "strongest_signal":\n                    "",\n                "strongest_excerpt":\n                    "",\n                "seen_event_keys":\n                    [],\n                "retention_candidate":\n                    False,\n                "close_reason":\n                    "",\n                "closed_at":\n                    0.0,\n            }\n\n        seen = list(\n            record.get(\n                "seen_event_keys",\n                []\n            )\n            or []\n        )\n\n        if key in seen:\n            return SalienceResult(\n                episode_id=episode_id,\n                event_score=event_score,\n                event_level=event_level,\n                valence=valence,\n                signals=signals,\n                episode_score=float(\n                    record.get(\n                        "episode_score",\n                        0.0,\n                    )\n                    or 0.0\n                ),\n                retention_candidate=bool(\n                    record.get(\n                        "retention_candidate",\n                        False,\n                    )\n                ),\n                duplicate=True,\n            )\n\n        seen.append(\n            key\n        )\n\n        record[\n            "seen_event_keys"\n        ] = seen[-180:]\n\n        record[\n            "event_count"\n        ] = (\n            int(\n                record.get(\n                    "event_count",\n                    0,\n                )\n                or 0\n            )\n            +\n            1\n        )\n\n        if event_score >= 0.45:\n            record[\n                "important_event_count"\n            ] = (\n                int(\n                    record.get(\n                        "important_event_count",\n                        0,\n                    )\n                    or 0\n                )\n                +\n                1\n            )\n\n        previous_max = float(\n            record.get(\n                "max_event_score",\n                0.0,\n            )\n            or 0.0\n        )\n\n        if event_score > previous_max:\n            record[\n                "max_event_score"\n            ] = event_score\n\n            record[\n                "strongest_signal"\n            ] = (\n                signals[0]\n                if signals\n                else\n                "ordinary_interaction"\n            )\n\n            record[\n                "strongest_excerpt"\n            ] = _clean(\n                text,\n                220,\n            )\n\n            record[\n                "strongest_user_id"\n            ] = str(\n                user_id\n                or ""\n            )\n\n            record[\n                "strongest_username"\n            ] = _clean(\n                username,\n                100,\n            )\n\n        signal_counts = Counter(\n            record.get(\n                "signal_counts",\n                {}\n            )\n            or {}\n        )\n\n        for signal in signals:\n            signal_counts[\n                signal\n            ] += 1\n\n        record[\n            "signal_counts"\n        ] = dict(\n            signal_counts\n        )\n\n        valence_counts = Counter(\n            record.get(\n                "valence_counts",\n                {}\n            )\n            or {}\n        )\n\n        valence_counts[\n            valence\n        ] += 1\n\n        record[\n            "valence_counts"\n        ] = dict(\n            valence_counts\n        )\n\n        record[\n            "updated_at"\n        ] = time.time()\n\n        record[\n            "episode_score"\n        ] = _episode_score(\n            record\n        )\n\n        record[\n            "retention_candidate"\n        ] = (\n            record[\n                "episode_score"\n            ]\n            >=\n            RETENTION_CANDIDATE_THRESHOLD\n        )\n\n        episodes[\n            episode_id\n        ] = record\n\n        # Keep the newest records only.\n        if len(\n            episodes\n        ) > SALIENCE_MAX_EPISODES:\n\n            ordered = sorted(\n                episodes.items(),\n                key=lambda item:\n                    float(\n                        item[1].get(\n                            "updated_at",\n                            0.0,\n                        )\n                        or 0.0\n                    ),\n            )\n\n            for old_id, _ in ordered[\n                :max(\n                    0,\n                    len(episodes)\n                    -\n                    SALIENCE_MAX_EPISODES\n                )\n            ]:\n                episodes.pop(\n                    old_id,\n                    None,\n                )\n\n        _save(\n            data\n        )\n\n        return SalienceResult(\n            episode_id=episode_id,\n            event_score=event_score,\n            event_level=event_level,\n            valence=valence,\n            signals=signals,\n            episode_score=float(\n                record[\n                    "episode_score"\n                ]\n            ),\n            retention_candidate=bool(\n                record[\n                    "retention_candidate"\n                ]\n            ),\n            duplicate=False,\n        )\n\n\ndef sync_closed_episode_salience():\n    if not EPISODE_STATE_PATH.exists():\n        return 0\n\n    try:\n        episode_data = json.loads(\n            EPISODE_STATE_PATH.read_text(\n                encoding="utf-8"\n            )\n        )\n    except Exception:\n        return 0\n\n    closed = (\n        episode_data.get(\n            "closed",\n            [],\n        )\n        if isinstance(\n            episode_data,\n            dict,\n        )\n        else []\n    )\n\n    if not isinstance(\n        closed,\n        list,\n    ):\n        return 0\n\n    updated = 0\n\n    with _LOCK:\n        data = _load()\n        records = data[\n            "episodes"\n        ]\n\n        for episode in closed:\n            if not isinstance(\n                episode,\n                dict,\n            ):\n                continue\n\n            episode_id = str(\n                episode.get(\n                    "episode_id",\n                    "",\n                )\n            )\n\n            if not episode_id:\n                continue\n\n            record = records.get(\n                episode_id\n            )\n\n            if not isinstance(\n                record,\n                dict,\n            ):\n                continue\n\n            if record.get(\n                "status"\n            ) == "closed":\n                continue\n\n            record[\n                "status"\n            ] = "closed"\n\n            record[\n                "closed_at"\n            ] = float(\n                episode.get(\n                    "ended_at",\n                    time.time(),\n                )\n                or time.time()\n            )\n\n            record[\n                "close_reason"\n            ] = str(\n                episode.get(\n                    "close_reason",\n                    "closed",\n                )\n                or "closed"\n            )\n\n            record[\n                "episode_digest"\n            ] = _clean(\n                episode.get(\n                    "digest",\n                    "",\n                ),\n                700,\n            )\n\n            record[\n                "episode_score"\n            ] = _episode_score(\n                record\n            )\n\n            record[\n                "retention_candidate"\n            ] = (\n                record[\n                    "episode_score"\n                ]\n                >=\n                RETENTION_CANDIDATE_THRESHOLD\n            )\n\n            record[\n                "updated_at"\n            ] = time.time()\n\n            updated += 1\n\n        if updated:\n            _save(\n                data\n            )\n\n    return updated\n\n\ndef get_episode_salience(\n    episode_id,\n):\n    with _LOCK:\n        data = _load()\n\n        record = (\n            data.get(\n                "episodes",\n                {}\n            )\n            .get(\n                str(\n                    episode_id\n                    or ""\n                )\n            )\n        )\n\n        if not isinstance(\n            record,\n            dict,\n        ):\n            return None\n\n        return json.loads(\n            json.dumps(\n                record,\n                ensure_ascii=False,\n            )\n        )\n\n\ndef format_salience_context(\n    result,\n):\n    if result is None:\n        return (\n            "[EMOTIONAL SALIENCE]\\n"\n            "current=unknown\\n"\n            "Kein Learning aus diesem Block."\n        )\n\n    if result.event_level == "significant":\n        guidance = (\n            "Der Moment kann emotional stark relevant sein. "\n            "Nicht mit Template-Smalltalk wegwischen. "\n            "Ton und Beziehungskontext ernst nehmen."\n        )\n    elif result.event_level == "important":\n        guidance = (\n            "Der Moment ist wichtig genug für bewusste Kontinuität. "\n            "Nicht unnötig trivialisieren."\n        )\n    elif result.event_level == "notable":\n        guidance = (\n            "Bemerkenswerter Moment, aber kein Drama erzwingen."\n        )\n    else:\n        guidance = (\n            "Gewöhnlicher Moment. Keine künstliche Bedeutung aufblasen."\n        )\n\n    return (\n        "[EMOTIONAL SALIENCE]\\n"\n        f"current_event_score="\n        f"{result.event_score:.2f}\\n"\n        f"current_level="\n        f"{result.event_level}\\n"\n        f"valence="\n        f"{result.valence}\\n"\n        f"signals="\n        f"{\', \'.join(result.signals) if result.signals else \'none\'}\\n"\n        f"episode_score="\n        f"{result.episode_score:.2f}\\n"\n        f"retention_candidate="\n        f"{result.retention_candidate}\\n"\n        f"guidance="\n        f"{guidance}\\n"\n        "HARD: Salience ist keine Faktenquelle und schreibt "\n        "noch KEIN Character Learning / Memory."\n    )\n\n\ndef format_salience_debug(\n    result,\n):\n    return (\n        "[EMOTIONAL SALIENCE] "\n        f"v={EMOTIONAL_SALIENCE_VERSION} "\n        f"episode={result.episode_id!r} "\n        f"event={result.event_score:.2f} "\n        f"level={result.event_level} "\n        f"valence={result.valence} "\n        f"signals={result.signals} "\n        f"episode_score={result.episode_score:.2f} "\n        f"retention={result.retention_candidate} "\n        f"duplicate={result.duplicate}"\n    )\n\n\ndef format_salience_stats_debug():\n    with _LOCK:\n        data = _load()\n\n    records = list(\n        (\n            data.get(\n                "episodes",\n                {}\n            )\n            or {}\n        ).values()\n    )\n\n    active = sum(\n        1\n        for item in records\n        if isinstance(item, dict)\n        and item.get("status") != "closed"\n    )\n\n    closed = sum(\n        1\n        for item in records\n        if isinstance(item, dict)\n        and item.get("status") == "closed"\n    )\n\n    candidates = sum(\n        1\n        for item in records\n        if isinstance(item, dict)\n        and bool(\n            item.get(\n                "retention_candidate",\n                False,\n            )\n        )\n    )\n\n    return (\n        "[EMOTIONAL SALIENCE STATE] "\n        f"v={EMOTIONAL_SALIENCE_VERSION} "\n        f"active={active} "\n        f"closed={closed} "\n        f"retention_candidates={candidates} "\n        f"threshold={RETENTION_CANDIDATE_THRESHOLD:.2f}"\n    )\n\n\ndef _self_test():\n    tests = []\n\n    mundane = analyze_event_salience(\n        "Guten Morgen!"\n    )\n\n    tests.append(\n        (\n            "routine greeting stays mundane",\n            mundane[1] == "mundane",\n        )\n    )\n\n    vulnerable = analyze_event_salience(\n        "Mir gehts heute echt schlecht und ich bin traurig",\n        direct=True,\n    )\n\n    tests.append(\n        (\n            "vulnerability is important",\n            vulnerable[0] >= 0.45\n            and\n            "vulnerability"\n            in vulnerable[3],\n        )\n    )\n\n    feedback = analyze_event_salience(\n        "Wow Evil, das war gerade echt gemein",\n        direct=True,\n    )\n\n    tests.append(\n        (\n            "explicit feedback matters",\n            feedback[0] >= 0.45\n            and\n            "explicit_feedback"\n            in feedback[3],\n        )\n    )\n\n    correction = analyze_event_salience(\n        "Das stimmt nicht, du hast Hanae und mich verwechselt",\n        direct=True,\n    )\n\n    tests.append(\n        (\n            "correction is retained as signal",\n            "explicit_correction"\n            in correction[3],\n        )\n    )\n\n    callback = analyze_event_salience(\n        "Weißt du noch wie wir gestern über den Boss geredet haben?"\n    )\n\n    tests.append(\n        (\n            "shared callback is notable",\n            callback[0] >= 0.20\n            and\n            "shared_callback"\n            in callback[3],\n        )\n    )\n\n    passed = sum(\n        1\n        for _, success\n        in tests\n        if success\n    )\n\n    print("")\n    print("=" * 58)\n    print(\n        f"EMOTIONAL SALIENCE v"\n        f"{EMOTIONAL_SALIENCE_VERSION} TEST"\n    )\n    print("=" * 58)\n\n    for name, success in tests:\n        print(\n            f"[{\'PASS\' if success else \'FAIL\'}] "\n            f"{name}"\n        )\n\n    print(\n        f"RESULT: "\n        f"{passed}/{len(tests)} PASS"\n    )\n\n    return (\n        0\n        if passed == len(tests)\n        else 1\n    )\n\n\nif __name__ == "__main__":\n    raise SystemExit(\n        _self_test()\n    )\n'
SALIENCE_IMPORT = 'from emotional_salience import (\n    EMOTIONAL_SALIENCE_VERSION,\n    observe_salience_event,\n    sync_closed_episode_salience,\n    format_salience_context,\n    format_salience_debug,\n    format_salience_stats_debug,\n)\n\n'
EPISODE_OBSERVE_MARKER = '    # =====================================================\n    # PERSISTENT CONVERSATION EPISODES\n    # =====================================================\n\n    episode_observation = (\n        observe_episode_message(\n            channel_id=channel_id,\n            role="user",\n            user_id=user_id,\n            username=username,\n            content=(\n                perception.text\n                or perception.raw_content\n                or "[nonverbale Reaktion]"\n            ),\n            message_id=getattr(\n                message,\n                "id",\n                "",\n            ),\n            timestamp=(\n                message.created_at.timestamp()\n                if getattr(\n                    message,\n                    "created_at",\n                    None,\n                )\n                else time.time()\n            ),\n        )\n    )\n\n    synced_episode_evilnae = (\n        sync_evilnae_from_snapshot(\n            channel_id,\n            channel_snapshot,\n        )\n    )\n\n    persistent_episode_context_text = (\n        format_episode_context(\n            channel_id\n        )\n    )\n\n    print(\n        format_episode_observation_debug(\n            episode_observation\n        )\n    )\n\n    if synced_episode_evilnae:\n        print(\n            "[CONVERSATION EPISODE SYNC] "\n            f"user={username} "\n            f"evilnae_events_added="\n            f"{synced_episode_evilnae}"\n        )\n\n'
SALIENCE_OBSERVE_BLOCK = '    # =====================================================\n    # EMOTIONAL SALIENCE\n    #\n    # Scores how much this moment may matter.\n    # This does NOT learn or alter the character yet.\n    # =====================================================\n\n    salience_result = (\n        observe_salience_event(\n            episode_id=(\n                episode_observation\n                .episode_id\n            ),\n            channel_id=channel_id,\n            user_id=user_id,\n            username=username,\n            text=(\n                perception.text\n                or perception.raw_content\n                or "[nonverbale Reaktion]"\n            ),\n            message_id=getattr(\n                message,\n                "id",\n                "",\n            ),\n            direct=bool(\n                getattr(\n                    perception,\n                    "directly_addresses_evilnae",\n                    False,\n                )\n                or\n                getattr(\n                    perception,\n                    "is_reply_to_evilnae",\n                    False,\n                )\n            ),\n            is_hanae=(\n                str(user_id)\n                ==\n                str(HANAE_USER_ID)\n            ),\n        )\n    )\n\n    salience_context_text = (\n        format_salience_context(\n            salience_result\n        )\n    )\n\n    closed_salience_synced = (\n        sync_closed_episode_salience()\n    )\n\n    print(\n        format_salience_debug(\n            salience_result\n        )\n    )\n\n    if closed_salience_synced:\n        print(\n            "[EMOTIONAL SALIENCE SYNC] "\n            f"closed_updated="\n            f"{closed_salience_synced}"\n        )\n\n'
STARTUP_SALIENCE_BLOCK = '    closed_salience_synced = (\n        sync_closed_episode_salience()\n    )\n\n    print(\n        format_salience_stats_debug()\n    )\n\n    if closed_salience_synced:\n        print(\n            "[EMOTIONAL SALIENCE RECOVERY] "\n            f"closed_updated="\n            f"{closed_salience_synced}"\n        )\n\n'


def ok(text):
    print(f"[OK] {text}")


def fail(text):
    print()
    print(f"[INSTALL ERROR] {text}")
    print("Nothing was overwritten by this installer.")
    raise SystemExit(1)


def replace_once(text, old, new, label):
    count = text.count(old)

    if count != 1:
        fail(
            f"{label}: expected exactly 1 match, "
            f"found {count}"
        )

    ok(label)

    return text.replace(
        old,
        new,
        1,
    )


def insert_before_once(text, marker, block, label):
    count = text.count(marker)

    if count != 1:
        fail(
            f"{label}: expected exactly 1 marker, "
            f"found {count}"
        )

    ok(label)

    return text.replace(
        marker,
        block + marker,
        1,
    )


def insert_after_once(text, marker, block, label):
    count = text.count(marker)

    if count != 1:
        fail(
            f"{label}: expected exactly 1 marker, "
            f"found {count}"
        )

    ok(label)

    return text.replace(
        marker,
        marker + block,
        1,
    )


def syntax_check(text, filename):
    try:
        ast.parse(
            text,
            filename=filename,
        )

    except SyntaxError as error:
        fail(
            f"{filename}: syntax error after patch at "
            f"line {error.lineno}: {error.msg}"
        )

    ok(
        f"{filename} syntax check"
    )


print("=" * 78)
print("EVILNAE 3.6.0 — EMOTIONAL SALIENCE")
print("=" * 78)

print(
    f"Project: {PROJECT_ROOT}"
)

print()
print(
    "WICHTIG: bot.py muss vollständig AUS sein."
)
print()


for required in (
    BOT_PATH,
    EPISODES_PATH,
):
    if not required.exists():
        fail(
            f"Missing required file: {required.name}"
        )


bot = BOT_PATH.read_text(
    encoding="utf-8"
)

episodes = EPISODES_PATH.read_text(
    encoding="utf-8"
)


if (
    TARGET_BOT in bot
    and
    SALIENCE_PATH.exists()
    and
    'EMOTIONAL_SALIENCE_VERSION = "1.0"'
    in SALIENCE_PATH.read_text(
        encoding="utf-8"
    )
):
    print(
        "3.6.0 Emotional Salience already installed."
    )

    raise SystemExit(
        0
    )


if EXPECTED_BOT not in bot:
    fail(
        "Expected Bot 3.5.0-conversation-episodes"
    )


if (
    'CONVERSATION_EPISODES_VERSION = "1.0"'
    not in episodes
):
    fail(
        "Expected Conversation Episodes v1.0"
    )


if SALIENCE_PATH.exists():
    fail(
        "emotional_salience.py already exists unexpectedly."
    )


for marker in (
    "Conversation Episodes v",
    "Episode -> Character Learning: DISABLED",
    "persistent_episode_context_text",
    "Qwen Surface Writer v",
):
    if marker not in bot:
        fail(
            f"Required 3.5 invariant missing: {marker}"
        )


ok(
    "3.5.0 Conversation Episodes base detected"
)

print(
    "[PREFLIGHT] Using exact Episode v1.0 anchors"
)


bot = replace_once(
    bot,
    EXPECTED_BOT,
    TARGET_BOT,
    "Bot version -> 3.6.0-emotional-salience",
)


bot = insert_before_once(
    bot,
    "from conversation_episodes import (\n",
    SALIENCE_IMPORT,
    "bot.py imports Emotional Salience",
)


bot = insert_after_once(
    bot,
    EPISODE_OBSERVE_MARKER,
    SALIENCE_OBSERVE_BLOCK,
    "Observe Emotional Salience after Episode observation",
)


bot = replace_once(
    bot,
    """    print(
        "Episode -> Character Learning: DISABLED"
    )

""",
    """    print(
        "Episode -> Character Learning: DISABLED"
    )

    print(
        f"Emotional Salience v"
        f"{EMOTIONAL_SALIENCE_VERSION}: ACTIVE"
    )

    print(
        "Salience -> Character Learning: DISABLED"
    )

    print(
        "Retention Candidate != Memory: ACTIVE"
    )

""",
    "Startup Emotional Salience banner",
)


bot = insert_after_once(
    bot,
    """    if stale_episodes_closed:
        print(
            "[CONVERSATION EPISODE RECOVERY] "
            f"closed_stale="
            f"{stale_episodes_closed}"
        )

""",
    STARTUP_SALIENCE_BLOCK,
    "Startup reconciles Emotional Salience",
)


bot = replace_once(
    bot,
    """            + persistent_episode_context_text
        )

        # B3F -> BRAIN
""",
    """            + persistent_episode_context_text
            + "\\n\\n"
            + salience_context_text
        )

        # B3F -> BRAIN
""",
    "Brain receives Emotional Salience",
)


bot = replace_once(
    bot,
    """            + persistent_episode_context_text
        )
""",
    """            + persistent_episode_context_text
            + "\\n\\n"
            + salience_context_text
        )
""",
    "Writer receives Emotional Salience",
)


bot = replace_once(
    bot,
    """            persistent_episode_context_text,
        ):
""",
    """            persistent_episode_context_text,
            salience_context_text,
        ):
""",
    "Qwen Surface Writer receives Emotional Salience",
)


for marker in (
    TARGET_BOT,
    "EMOTIONAL_SALIENCE_VERSION",
    "salience_context_text",
    "observe_salience_event(",
    "Salience -> Character Learning: DISABLED",
    "Retention Candidate != Memory: ACTIVE",
):
    if marker not in bot:
        fail(
            f"Patched bot.py missing invariant: {marker}"
        )


for marker in (
    'EMOTIONAL_SALIENCE_VERSION = "1.0"',
    "def analyze_event_salience(",
    "def observe_salience_event(",
    "def sync_closed_episode_salience(",
    "retention_candidate",
    "explicit_feedback",
    "vulnerability",
):
    if marker not in SALIENCE_SOURCE:
        fail(
            f"emotional_salience.py missing invariant: "
            f"{marker}"
        )


syntax_check(
    SALIENCE_SOURCE,
    "emotional_salience.py",
)

syntax_check(
    bot,
    "bot.py",
)


contract_tests = {
    "no new OpenAI/Ollama call":
        (
            "safe_openai_request" not in SALIENCE_SOURCE
            and
            "ollama" not in SALIENCE_SOURCE.lower()
            and
            "AsyncOpenAI" not in SALIENCE_SOURCE
        ),

    "salience does not write Character Learning":
        (
            "character_learning" not in SALIENCE_SOURCE
            and
            "observe_character_learning" not in SALIENCE_SOURCE
        ),

    "four salience levels":
        all(
            level in SALIENCE_SOURCE
            for level in (
                "mundane",
                "notable",
                "important",
                "significant",
            )
        ),

    "relationship signals":
        (
            "positive_relationship_signal"
            in SALIENCE_SOURCE
            and
            "negative_relationship_signal"
            in SALIENCE_SOURCE
        ),

    "feedback/correction signals":
        (
            "explicit_feedback"
            in SALIENCE_SOURCE
            and
            "explicit_correction"
            in SALIENCE_SOURCE
        ),

    "episode aggregate score":
        "def _episode_score("
        in SALIENCE_SOURCE,

    "Brain gets salience":
        "+ salience_context_text"
        in bot,

    "Qwen gets salience":
        "salience_context_text,"
        in bot,
}


failed = [
    name
    for name, success
    in contract_tests.items()
    if not success
]


if failed:
    fail(
        "Contract self-test failed: "
        +
        ", ".join(
            failed
        )
    )


ok(
    f"Contract self-test: "
    f"{len(contract_tests)}/"
    f"{len(contract_tests)} PASS"
)


timestamp = (
    datetime.now()
    .astimezone()
    .strftime(
        "%Y%m%d-%H%M%S"
    )
)

backup_dir = (
    BACKUP_ROOT
    /
    timestamp
)

suffix = 1

while backup_dir.exists():
    backup_dir = (
        BACKUP_ROOT
        /
        f"{timestamp}_{suffix:02d}"
    )

    suffix += 1


backup_dir.mkdir(
    parents=True,
    exist_ok=False,
)


for path in (
    BOT_PATH,
    EPISODES_PATH,
):
    shutil.copy2(
        path,
        backup_dir / path.name,
    )

    ok(
        f"Backup: {path.name}"
    )


def atomic_write(path, text):
    temp = Path(
        str(path)
        +
        ".tmp"
    )

    temp.write_text(
        text,
        encoding="utf-8"
    )

    temp.replace(
        path
    )


atomic_write(
    SALIENCE_PATH,
    SALIENCE_SOURCE,
)

ok(
    "Created: emotional_salience.py"
)


atomic_write(
    BOT_PATH,
    bot,
)

ok(
    "Updated: bot.py"
)


result = subprocess.run(
    [
        sys.executable,
        "-m",
        "py_compile",
        str(
            SALIENCE_PATH
        ),
        str(
            EPISODES_PATH
        ),
        str(
            BOT_PATH
        ),
    ],
    cwd=str(
        PROJECT_ROOT
    ),
    check=False,
)


if result.returncode != 0:
    print(
        f"Backup: {backup_dir}"
    )

    raise SystemExit(
        result.returncode
    )


ok(
    "Post-install py_compile: 3/3"
)


result = subprocess.run(
    [
        sys.executable,
        str(
            SALIENCE_PATH
        ),
    ],
    cwd=str(
        PROJECT_ROOT
    ),
    check=False,
)


if result.returncode != 0:
    print(
        f"Backup: {backup_dir}"
    )

    raise SystemExit(
        result.returncode
    )


ok(
    "Self-test: emotional_salience.py"
)


print()
print("=" * 78)
print(
    "EVILNAE 3.6.0 EMOTIONAL SALIENCE INSTALLED"
)
print("=" * 78)

print()
print("New:")
print(
    "  [✓] every episode event receives salience 0.00 - 1.00"
)
print(
    "  [✓] levels: mundane / notable / important / significant"
)
print(
    "  [✓] positive / negative / mixed / neutral valence"
)
print(
    "  [✓] relationship signals"
)
print(
    "  [✓] vulnerability / meaningful disclosure signal"
)
print(
    "  [✓] explicit feedback signal"
)
print(
    "  [✓] explicit correction signal"
)
print(
    "  [✓] shared callback / milestone / preference signals"
)
print(
    "  [✓] aggregate salience score per Conversation Episode"
)
print(
    "  [✓] retention_candidate flag for later Reflection/Learning 2.0"
)
print(
    "  [✓] closed Episode salience reconciliation"
)
print(
    "  [✓] Salience context -> Brain / Writer / Qwen"
)

print()
print("IMPORTANT:")
print(
    "  [✓] retention_candidate is NOT a Memory"
)
print(
    "  [✓] Salience DOES NOT change Character Learning yet"
)
print(
    "  [✓] Salience DOES NOT overwrite Canon"
)
print(
    "  [✓] no new OpenAI/Ollama call"
)

print()
print(
    "State file: evilnae_salience.json"
)

print()
print(
    f"Backup: {backup_dir}"
)

print()
print(
    "NO MEMORY RESET REQUIRED."
)

print()
print("NEXT:")
print(
    "  python bot.py"
)

print()
print("Expected startup:")
print(
    "  Bot Version: 3.6.0-emotional-salience"
)
print(
    "  Emotional Salience v1.0: ACTIVE"
)
print(
    "  [EMOTIONAL SALIENCE STATE] v=1.0 ..."
)

print()
print("Expected on messages:")
print(
    "  [EMOTIONAL SALIENCE] v=1.0 episode='...' "
    "event=... level=... signals=[...]"
)
