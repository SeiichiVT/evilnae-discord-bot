
from pathlib import Path
from datetime import datetime

import ast
import shutil
import subprocess
import sys


PROJECT_ROOT = Path(__file__).resolve().parent

BOT_PATH = PROJECT_ROOT / "bot.py"
SALIENCE_PATH = PROJECT_ROOT / "emotional_salience.py"

BACKUP_ROOT = PROJECT_ROOT / "live_fix_backups"

EXPECTED_BOT = 'BOT_VERSION = "3.6.0-emotional-salience"'

EXPECTED_SALIENCE = 'EMOTIONAL_SALIENCE_VERSION = "1.0"'
TARGET_SALIENCE = 'EMOTIONAL_SALIENCE_VERSION = "1.0.1-feedback-fix"'

OLD_PATTERN = '        r"das\\s+war\\s+(?:süß|suess|gemein|kalt|lieb)|"\n'
NEW_PATTERN = '        r"das\\s+war\\s+"\n        r"(?:(?:gerade|eben|ja|halt|schon|echt|wirklich|"\n        r"ziemlich|voll|so|mal)\\s+){0,4}"\n        r"(?:süß|suess|gemein|kalt|lieb)|"\n'


def ok(text):
    print(f"[OK] {text}")


def fail(text):
    print()
    print(f"[REPAIR ERROR] {text}")
    print("Nothing was overwritten by this repair.")
    raise SystemExit(1)


def syntax_check(text, filename):
    try:
        ast.parse(text, filename=filename)
    except SyntaxError as error:
        fail(
            f"{filename}: syntax error after patch at "
            f"line {error.lineno}: {error.msg}"
        )

    ok(f"{filename} syntax check")


print("=" * 78)
print("EVILNAE 3.6.0 — EMOTIONAL SALIENCE FEEDBACK REPAIR")
print("=" * 78)
print(f"Project: {PROJECT_ROOT}")
print()
print("WICHTIG: bot.py muss vollständig AUS sein.")
print()

if not BOT_PATH.exists():
    fail("bot.py missing")

if not SALIENCE_PATH.exists():
    fail("emotional_salience.py missing")

bot = BOT_PATH.read_text(encoding="utf-8")
salience = SALIENCE_PATH.read_text(encoding="utf-8")

if EXPECTED_BOT not in bot:
    fail("Expected Bot 3.6.0-emotional-salience")

if TARGET_SALIENCE in salience:
    print("Feedback repair is already installed.")
    raise SystemExit(0)

if EXPECTED_SALIENCE not in salience:
    fail("Expected Emotional Salience v1.0")

pattern_count = salience.count(OLD_PATTERN)

if pattern_count != 1:
    fail(
        "Expected exactly one old explicit-feedback pattern, "
        f"found {pattern_count}"
    )

ok("3.6.0 partially-installed base detected")

salience = salience.replace(
    EXPECTED_SALIENCE,
    TARGET_SALIENCE,
    1,
)

ok("Emotional Salience version -> 1.0.1-feedback-fix")

salience = salience.replace(
    OLD_PATTERN,
    NEW_PATTERN,
    1,
)

ok("Expanded explicit-feedback modifier matching")

for marker in (
    TARGET_SALIENCE,
    "gerade|eben|ja|halt|schon|echt|wirklich",
    "ziemlich|voll|so|mal",
    "explicit_feedback",
):
    if marker not in salience:
        fail(f"Patched file missing invariant: {marker}")

syntax_check(salience, "emotional_salience.py")

# ---------------------------------------------------------
# In-memory behavior tests BEFORE writing.
# ---------------------------------------------------------

namespace = {
    "__name__": "_salience_repair_test_",
}

try:
    exec(
        compile(
            salience,
            "emotional_salience.py",
            "exec",
        ),
        namespace,
    )
except Exception as error:
    fail(
        "Could not load patched salience code for behavior test: "
        f"{type(error).__name__}: {error}"
    )

analyze = namespace.get("analyze_event_salience")

if analyze is None:
    fail("analyze_event_salience missing after patch")

feedback_tests = {
    "original failing phrase":
        "explicit_feedback"
        in analyze(
            "Wow Evil, das war gerade echt gemein",
            direct=True,
        )[3],

    "simple feedback":
        "explicit_feedback"
        in analyze(
            "Das war gemein",
            direct=True,
        )[3],

    "natural filler feedback":
        "explicit_feedback"
        in analyze(
            "Das war ja mal wirklich süß",
            direct=True,
        )[3],

    "cold feedback":
        "explicit_feedback"
        in analyze(
            "Das war eben ziemlich kalt",
            direct=True,
        )[3],
}

failed_tests = [
    name
    for name, passed
    in feedback_tests.items()
    if not passed
]

if failed_tests:
    fail(
        "Feedback behavior self-test failed: "
        + ", ".join(failed_tests)
    )

ok(
    f"Feedback behavior self-test: "
    f"{len(feedback_tests)}/{len(feedback_tests)} PASS"
)

# ---------------------------------------------------------
# Backup + write.
# ---------------------------------------------------------

timestamp = (
    datetime.now()
    .astimezone()
    .strftime("%Y%m%d-%H%M%S")
)

backup_dir = BACKUP_ROOT / timestamp
suffix = 1

while backup_dir.exists():
    backup_dir = BACKUP_ROOT / f"{timestamp}_{suffix:02d}"
    suffix += 1

backup_dir.mkdir(
    parents=True,
    exist_ok=False,
)

shutil.copy2(
    SALIENCE_PATH,
    backup_dir / SALIENCE_PATH.name,
)

ok("Backup: emotional_salience.py")

temp = Path(str(SALIENCE_PATH) + ".tmp")
temp.write_text(
    salience,
    encoding="utf-8",
)
temp.replace(SALIENCE_PATH)

ok("Updated: emotional_salience.py")

# ---------------------------------------------------------
# Compile + original self-test.
# ---------------------------------------------------------

result = subprocess.run(
    [
        sys.executable,
        "-m",
        "py_compile",
        str(SALIENCE_PATH),
        str(BOT_PATH),
    ],
    cwd=str(PROJECT_ROOT),
    check=False,
)

if result.returncode != 0:
    print()
    print("[POST-REPAIR WARNING] py_compile failed.")
    print(f"Backup: {backup_dir}")
    raise SystemExit(result.returncode)

ok("Post-repair py_compile: 2/2")

result = subprocess.run(
    [
        sys.executable,
        str(SALIENCE_PATH),
    ],
    cwd=str(PROJECT_ROOT),
    check=False,
)

if result.returncode != 0:
    print()
    print(
        "[POST-REPAIR WARNING] "
        "emotional_salience.py self-test still failed."
    )
    print(f"Backup: {backup_dir}")
    raise SystemExit(result.returncode)

ok("Original Emotional Salience self-test: PASS")

print()
print("=" * 78)
print("EVILNAE EMOTIONAL SALIENCE FEEDBACK REPAIR INSTALLED")
print("=" * 78)
print()
print("Fixed:")
print("  [✓] Das war gemein")
print("  [✓] Das war gerade echt gemein")
print("  [✓] Das war ja mal wirklich süß")
print("  [✓] Das war eben ziemlich kalt")
print()
print("Bot stays:")
print("  3.6.0-emotional-salience")
print()
print(f"Backup: {backup_dir}")
print()
print("NO MEMORY RESET REQUIRED.")
print()
print("NEXT:")
print("  python bot.py")
print()
print("Expected:")
print("  Emotional Salience v1.0.1-feedback-fix: ACTIVE")
