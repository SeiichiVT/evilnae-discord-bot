from pathlib import Path
from datetime import datetime

import ast
import shutil
import subprocess
import sys


PROJECT_ROOT = Path(__file__).resolve().parent

FILES = {
    "bot": PROJECT_ROOT / "bot.py",
    "planner": PROJECT_ROOT / "response_planner.py",
    "surface": PROJECT_ROOT / "surface_writer.py",
    "quality": PROJECT_ROOT / "response_quality.py",
    "routing": PROJECT_ROOT / "routing_hardening.py",
    "episodes": PROJECT_ROOT / "conversation_episodes.py",
}

BACKUP_ROOT = PROJECT_ROOT / "live_fix_backups"

EXPECTED = {
    "bot": 'BOT_VERSION = "3.6.0-emotional-salience"',
    "planner": 'RESPONSE_PLANNER_VERSION = "1.0"',
    "surface": 'SURFACE_WRITER_VERSION = "1.0"',
    "quality": 'OUTPUT_QUALITY_VERSION = "2.5"',
    "routing": 'ROUTING_HARDENING_VERSION = "1.2"',
    "episodes": 'CONVERSATION_EPISODES_VERSION = "1.0"',
}

TARGET = {
    "bot": 'BOT_VERSION = "3.6.1-affect-repetition"',
    "planner": 'RESPONSE_PLANNER_VERSION = "1.1-affect-grounded"',
    "surface": 'SURFACE_WRITER_VERSION = "1.1-context-safe"',
    "quality": 'OUTPUT_QUALITY_VERSION = "2.6-concept-repetition"',
    "routing": 'ROUTING_HARDENING_VERSION = "1.3-trailing-vocative"',
    "episodes": 'CONVERSATION_EPISODES_VERSION = "1.1-authority-safe"',
}

PLANNER_HELPERS = '\n# =========================================================\n# 1.1 AFFECT / SELF-REPORT GROUNDING\n# =========================================================\n\nLOW_MOTIVATION_PATTERN = re.compile(\n    r"\\b(?:"\n    r"null\\s+bock|kein(?:en)?\\s+bock|keine\\s+lust|"\n    r"nicht\\s+aus\\s+lust|unmotiviert|widerwillig|"\n    r"nicht\\s+in\\s+stimmung|schlecht\\s+gelaunt|"\n    r"angepisst|genervt|keine\\s+motivation|"\n    r"alles\\s+egal|mehr\\s+muss\\s+nicht"\n    r")\\b",\n    re.IGNORECASE,\n)\n\nFRIENDLY_SOCIAL_PATTERN = re.compile(\n    r"\\b(?:guten\\s+morgen|morgen|hey|hi|huhu|"\n    r"wie\\s+geht(?:\'|’)?s|wie\\s+geht\\s+es\\s+dir|"\n    r"wie\\s+steht(?:\'|’)?s|schönen\\s+guten\\s+morgen|"\n    r"schoenen\\s+guten\\s+morgen)\\b",\n    re.IGNORECASE,\n)\n\nMOOD_QUERY_PATTERN = re.compile(\n    r"\\b(?:schlecht\\s+gelaunt|gute\\s+laune|"\n    r"keine\\s+gute\\s+laune|was\\s+los|"\n    r"bist\\s+du\\s+genervt|bist\\s+du\\s+sauer)\\b",\n    re.IGNORECASE,\n)\n\nSELF_REPORT_POSITIVE_PATTERN = re.compile(\n    r"\\bich\\s+bin\\s+"\n    r"(?:(?:echt|wirklich|voll|total|ziemlich)\\s+)?"\n    r"(?:gut\\s+gelaunt|happy|fröhlich|froh)\\b",\n    re.IGNORECASE,\n)\n\nSELF_REPORT_DENIAL_PATTERN = re.compile(\n    r"\\b(?:"\n    r"bin\\s+ich\\s+(?:gar\\s+)?nicht|"\n    r"ich\\s+bin\\s+(?:gar\\s+)?nicht"\n    r")\\b",\n    re.IGNORECASE,\n)\n\n\ndef _state_number(\n    state,\n    name,\n    default,\n):\n    try:\n        return float(\n            getattr(\n                state,\n                name,\n                default,\n            )\n        )\n    except Exception:\n        return float(\n            default\n        )\n\n\ndef _state_supports_negative_mood(\n    state,\n) -> bool:\n    if state is None:\n        return False\n\n    valence = _state_number(\n        state,\n        "valence",\n        0.20,\n    )\n\n    irritation = _state_number(\n        state,\n        "irritation",\n        0.08,\n    )\n\n    boredom = _state_number(\n        state,\n        "boredom",\n        0.20,\n    )\n\n    return bool(\n        valence <= -0.15\n        or irritation >= 0.32\n        or boredom >= 0.68\n    )\n\n\ndef _count_recent_low_motivation(\n    recent_messages,\n) -> int:\n    count = 0\n\n    for message in (\n        recent_messages\n        or []\n    )[-12:]:\n        if LOW_MOTIVATION_PATTERN.search(\n            str(\n                message\n                or ""\n            )\n        ):\n            count += 1\n\n    return count\n\n\n'
PLANNER_GROUNDING = '\n    # -----------------------------------------------------\n    # AFFECT AUTHORITY\n    #\n    # Dry wording is a style.\n    # It is NOT evidence that Evilnae is annoyed,\n    # unmotivated or in a bad mood.\n    #\n    # The current Inner State outranks accidental wording\n    # from previous generated messages.\n    # -----------------------------------------------------\n\n    user_text_clean = _clean_text(\n        user_text,\n        900,\n    )\n\n    state_supports_negative = (\n        _state_supports_negative_mood(\n            current_inner_state\n        )\n    )\n\n    recent_low_motivation = (\n        _count_recent_low_motivation(\n            recent_evilnae_messages\n        )\n    )\n\n    user_self_report_positive = bool(\n        SELF_REPORT_POSITIVE_PATTERN.search(\n            user_text_clean\n        )\n    )\n\n    user_self_report_denial = bool(\n        SELF_REPORT_DENIAL_PATTERN.search(\n            user_text_clean\n        )\n    )\n\n    if (\n        user_self_report_positive\n        or\n        user_self_report_denial\n    ):\n\n        if user_self_report_positive:\n            core_thought = (\n                "Der User beschreibt seinen eigenen aktuellen "\n                "Zustand als gut gelaunt. Diese Selbstbeschreibung "\n                "hat Vorrang. Locker darauf reagieren; ein kleiner "\n                "Tease ist okay, aber nicht als Fakt widersprechen."\n            )\n\n        else:\n            core_thought = (\n                "Der User korrigiert gerade eine Aussage über sich. "\n                "Seine aktuelle Selbstbeschreibung hat Vorrang. "\n                "Die korrigierte Behauptung nicht weiter als Fakt "\n                "wiederholen."\n            )\n\n        must_avoid = _merge_unique(\n            must_avoid,\n            [\n                "der Selbstbeschreibung des Users als Fakt widersprechen",\n                "die gerade korrigierte Behauptung erneut behaupten",\n            ],\n        )\n\n        warmth = max(\n            warmth,\n            0.50,\n        )\n\n        banter = min(\n            banter,\n            0.45,\n        )\n\n        if stance in {\n            "dry",\n            "annoyed",\n        }:\n            stance = "playful"\n\n        if move in {\n            "counter",\n            "challenge",\n            "disagree",\n        }:\n            move = "acknowledge"\n\n    if not state_supports_negative:\n\n        if LOW_MOTIVATION_PATTERN.search(\n            core_thought\n        ):\n\n            if MOOD_QUERY_PATTERN.search(\n                user_text_clean\n            ):\n                core_thought = (\n                    "Evilnaes aktueller Inner State ist neutral. "\n                    "Auf die Frage nach ihrer Laune ehrlich und locker "\n                    "reagieren: trocken darf klingen, aber keine "\n                    "schlechte Laune, Null-Bock-Stimmung oder Genervtheit "\n                    "erfinden."\n                )\n\n            else:\n                core_thought = (\n                    "Auf den konkreten Inhalt reagieren. Evilnaes "\n                    "aktueller Inner State ist neutral; trockener Humor "\n                    "darf NICHT als Null-Bock-, genervte oder schlechte "\n                    "Stimmung erfunden werden."\n                )\n\n            if stance == "annoyed":\n                stance = "dry"\n\n            warmth = max(\n                warmth,\n                0.46,\n            )\n\n        if recent_low_motivation >= 2:\n\n            must_avoid = _merge_unique(\n                must_avoid,\n                [\n                    "erneut Null-Bock/keine-Lust/unmotiviert/widerwillig sagen",\n                    "die negative Morgen-/Motivationsstimmung aus früheren Antworten fortschreiben",\n                    "denselben Low-Motivation-Gedanken nur mit Synonymen wiederholen",\n                ],\n            )\n\n            warmth = max(\n                warmth,\n                0.46,\n            )\n\n    # Friendly Smalltalk should not automatically become\n    # irritated or emotionally shut down when the actual state is neutral.\n    if (\n        FRIENDLY_SOCIAL_PATTERN.search(\n            user_text_clean\n        )\n        and\n        not state_supports_negative\n        and\n        social_mode\n        not in {\n            "serious",\n            "betrayal_rivalry",\n            "comparison_provocation",\n            "competitive",\n        }\n    ):\n\n        warmth = max(\n            warmth,\n            0.50,\n        )\n\n        if (\n            stance == "dry"\n            and\n            banter <= 0.35\n        ):\n            stance = "playful"\n\n    must_avoid = _merge_unique(\n        must_avoid,\n        [\n            "trocken mit angepisst oder lustlos verwechseln",\n            "frühere Evilnae-Ausgaben als Beweis für ihre aktuelle Stimmung behandeln",\n        ],\n    )\n\n'
SURFACE_HELPERS = '\n# =========================================================\n# 1.1 CONTEXT-SAFE SURFACE HELPERS\n# =========================================================\n\nLOW_MOTIVATION_SURFACE_PATTERN = re.compile(\n    r"\\b(?:"\n    r"null\\s+bock|kein(?:en)?\\s+bock|keine\\s+lust|"\n    r"nicht\\s+aus\\s+lust|unmotiviert|widerwillig|"\n    r"nicht\\s+in\\s+stimmung|schlecht\\s+gelaunt|"\n    r"angepisst|genervt|keine\\s+motivation"\n    r")\\b",\n    re.IGNORECASE,\n)\n\n\ndef _surface_words(\n    text,\n):\n    return re.findall(\n        r"[A-Za-zÄÖÜäöüß0-9]+",\n        str(\n            text\n            or ""\n        ).lower(),\n    )\n\n\ndef _surface_similarity(\n    left,\n    right,\n):\n    left_norm = normalize_simple_text(\n        left\n    )\n\n    right_norm = normalize_simple_text(\n        right\n    )\n\n    if (\n        not left_norm\n        or\n        not right_norm\n    ):\n        return 0.0\n\n    return SequenceMatcher(\n        None,\n        left_norm,\n        right_norm,\n    ).ratio()\n\n\ndef _inner_state_is_neutralish(\n    inner_state_guidance,\n):\n    text = str(\n        inner_state_guidance\n        or ""\n    ).lower()\n\n    # Current guidance/debug formats both expose either\n    # the dominant feeling or the low irritation/positive valence.\n    if "neutral" in text:\n        return True\n\n    irritation_match = re.search(\n        r"irritation\\s*[=:]\\s*([0-9.]+)",\n        text,\n    )\n\n    valence_match = re.search(\n        r"valence\\s*[=:]\\s*(-?[0-9.]+)",\n        text,\n    )\n\n    try:\n        irritation = (\n            float(\n                irritation_match.group(1)\n            )\n            if irritation_match\n            else None\n        )\n    except Exception:\n        irritation = None\n\n    try:\n        valence = (\n            float(\n                valence_match.group(1)\n            )\n            if valence_match\n            else None\n        )\n    except Exception:\n        valence = None\n\n    return bool(\n        irritation is not None\n        and irritation < 0.25\n        and (\n            valence is None\n            or valence > -0.10\n        )\n    )\n\n\ndef surface_context_violation_reason(\n    *,\n    candidate,\n    user_message,\n    response_plan_text,\n    inner_state_guidance,\n    evidence_context,\n    recent_evilnae_messages,\n    channel_recent_evilnae_messages,\n):\n    candidate = str(\n        candidate\n        or ""\n    ).strip()\n\n    candidate_norm = normalize_simple_text(\n        candidate\n    )\n\n    candidate_words = _surface_words(\n        candidate\n    )\n\n    recent = [\n        str(\n            item\n            or ""\n        ).strip()\n\n        for item\n        in (\n            list(\n                recent_evilnae_messages\n                or []\n            )\n            +\n            list(\n                channel_recent_evilnae_messages\n                or []\n            )\n        )\n\n        if str(\n            item\n            or ""\n        ).strip()\n    ]\n\n    # Exact short repeats were previously invisible because\n    # the old quality guard focused on 4-word ngrams.\n    if (\n        len(candidate_words) >= 2\n        and\n        any(\n            candidate_norm\n            ==\n            normalize_simple_text(\n                previous\n            )\n\n            for previous\n            in recent[-16:]\n        )\n    ):\n        return (\n            "surface_exact_recent_repeat"\n        )\n\n    if len(candidate_words) >= 5:\n\n        max_similarity = max(\n            [\n                _surface_similarity(\n                    candidate,\n                    previous,\n                )\n\n                for previous\n                in recent[-12:]\n            ]\n            or\n            [0.0]\n        )\n\n        if max_similarity >= 0.86:\n            return (\n                "surface_near_recent_copy"\n            )\n\n    # Past generated outputs are NOT evidence for current emotion.\n    if (\n        _inner_state_is_neutralish(\n            inner_state_guidance\n        )\n        and\n        LOW_MOTIVATION_SURFACE_PATTERN.search(\n            candidate\n        )\n        and\n        not LOW_MOTIVATION_SURFACE_PATTERN.search(\n            str(\n                response_plan_text\n                or ""\n            )\n        )\n    ):\n        return (\n            "surface_invented_negative_mood"\n        )\n\n    allowed_grounding = " ".join(\n        (\n            str(\n                user_message\n                or ""\n            ),\n            str(\n                response_plan_text\n                or ""\n            ),\n            str(\n                evidence_context\n                or ""\n            ),\n        )\n    ).lower()\n\n    # Concrete years / numeric autobiographical claims are not\n    # allowed to appear from nowhere.\n    candidate_numbers = re.findall(\n        r"\\b(?:19|20)\\d{2}\\b",\n        candidate,\n    )\n\n    for number in candidate_numbers:\n        if number not in allowed_grounding:\n            return (\n                "surface_unsupported_numeric_fact"\n            )\n\n    unsupported_experience = bool(\n        re.search(\n            r"\\bich\\s+(?:hab|habe)\\s+schon\\b"\n            r"|\\baus\\s+dem\\s+jahr\\s+\\d{4}\\b",\n            candidate,\n            flags=re.IGNORECASE,\n        )\n    )\n\n    if (\n        unsupported_experience\n        and\n        not re.search(\n            r"\\bich\\s+(?:hab|habe)\\s+schon\\b"\n            r"|\\baus\\s+dem\\s+jahr\\s+\\d{4}\\b",\n            allowed_grounding,\n            flags=re.IGNORECASE,\n        )\n    ):\n        return (\n            "surface_unsupported_experience_claim"\n        )\n\n    return ""\n\n\n'
QUALITY_FAMILIES = '    "low_motivation_mood": (\n        re.compile(\n            r"\\b(?:"\n            r"null\\s+bock|kein(?:en)?\\s+bock|keine\\s+lust|"\n            r"nicht\\s+aus\\s+lust|unmotiviert|widerwillig|"\n            r"nicht\\s+in\\s+stimmung|schlecht\\s+gelaunt|"\n            r"keine\\s+motivation"\n            r")\\b",\n            re.I\n        ),\n    ),\n    "minimal_shutdown": (\n        re.compile(\n            r"\\bmehr\\s+muss\\s+nicht\\b",\n            re.I\n        ),\n        re.compile(\n            r"\\bwochenende\\b.{0,35}\\bich\\s+(?:da|auch)\\b",\n            re.I\n        ),\n        re.compile(\n            r"\\bich\\s+bin\\s+wach\\b.{0,35}\\boptional\\b",\n            re.I\n        ),\n    ),\n'
QUALITY_EXACT_REPEAT = '    # =====================================================\n    # EXACT SHORT / FULL MESSAGE REPETITION\n    # =====================================================\n\n    normalized_candidate = _normalize(\n        text\n    )\n\n    exact_recent_repeat = bool(\n        normalized_candidate\n        and\n        word_count >= 2\n        and\n        any(\n            _normalize(\n                recent_message\n            )\n            ==\n            normalized_candidate\n\n            for recent_message\n            in recent[-16:]\n        )\n    )\n\n    if exact_recent_repeat:\n\n        issues.append(\n            "exact_recent_message_repeat"\n        )\n\n        repetition_score += 5\n\n'
QUALITY_FAMILY_BONUS = '    if (\n        "low_motivation_mood"\n        in repeated_families\n    ):\n\n        issues.append(\n            "repeated_low_motivation_concept"\n        )\n\n        repetition_score += 3\n\n    if (\n        "minimal_shutdown"\n        in repeated_families\n    ):\n\n        issues.append(\n            "repeated_shutdown_concept"\n        )\n\n        repetition_score += 2\n\n'
ROUTING_FIX = '    # v1.3: trailing vocative after a first-person correction.\n    #\n    # "bin ich gar nicht evil!" = addressed TO Evilnae,\n    # not a third-person statement ABOUT Evilnae.\n    if (\n        is_end\n        and\n        re.search(\n            r"\\b(?:bin|war)\\s+ich\\s+(?:gar\\s+)?nicht\\b",\n            text[\n                :match.start()\n            ],\n            flags=re.IGNORECASE,\n        )\n    ):\n        return True\n\n'
EPISODE_AUTHORITY_OLD = '        (\n            "Abgeschlossene Episoden geben Kontext, "\n            "verändern aber noch nicht Evilnaes Charakter."\n        ),\n        "",\n'
EPISODE_AUTHORITY_NEW = '        (\n            "Abgeschlossene Episoden geben Kontext, "\n            "verändern aber noch nicht Evilnaes Charakter."\n        ),\n        (\n            "WICHTIG: Frühere von Evilnae GENERIERTE Antworten sind "\n            "historischer Dialog, KEINE Autorität für ihre aktuelle Stimmung "\n            "oder für Fakten über andere Personen. Inner State, Character State "\n            "und aktuelle User-Korrekturen haben Vorrang."\n        ),\n        (\n            "Nicht aus einer früheren trockenen/negativen Formulierung "\n            "automatisch dieselbe Stimmung in die nächste Antwort fortschreiben."\n        ),\n        "",\n'
CURRENT_FACT_FUNCTION = 'def has_unsupported_current_fact(\n    answer,\n    decision\n):\n\n    if not answer:\n        return False\n\n    answer_text = str(\n        answer\n        or ""\n    )\n\n    suspicious_patterns = [\n        r"\\b(?:sie|er)\\s+ist\\s+gerade\\b",\n        r"\\b(?:sie|er)\\s+macht\\s+gerade\\b",\n        r"\\b(?:sie|er)\\s+schaut\\s+gerade\\b",\n        r"\\b(?:sie|er)\\s+spielt\\s+gerade\\b",\n        r"\\b(?:sie|er)\\s+sitzt\\s+gerade\\b",\n        r"\\b(?:sie|er)\\s+liegt\\s+gerade\\b",\n        r"\\b(?:sie|er)\\s+arbeitet\\s+gerade\\b",\n        r"\\b(?:sie|er)\\s+ist\\s+jetzt\\b",\n        r"\\b(?:sie|er)\\s+macht\\s+jetzt\\b",\n\n        r"\\b(?:hanae|error)\\b.{0,45}"\n        r"\\b(?:gerade|jetzt|aktuell|momentan)\\b",\n\n        r"\\b(?:hanae|error)\\s+"\n        r"(?:ist|macht|schaut|guckt|spielt|sitzt|liegt|"\n        r"arbeitet|bereitet|streamt|isst|trinkt)\\b"\n        r".{0,55}\\b(?:gerade|jetzt|aktuell|momentan)\\b",\n\n        # v3.6.1: volatile PRESENT states do not need the word\n        # "gerade" to be current claims.\n        r"\\b(?:hanae|error|sie|er)\\s+"\n        r"(?:ist|wirkt)\\s+(?:auch\\s+)?"\n        r"(?:schlecht\\s+gelaunt|gut\\s+gelaunt|"\n        r"müde|muede|traurig|happy|glücklich|gluecklich|"\n        r"genervt|sauer|krank|hungrig|wach|beschäftigt|beschaeftigt)\\b",\n    ]\n\n    suspicious = any(\n        re.search(\n            pattern,\n            answer_text,\n            flags=re.IGNORECASE,\n        )\n\n        for pattern\n        in suspicious_patterns\n    )\n\n    if not suspicious:\n        return False\n\n    knowledge_available = bool(\n        getattr(\n            decision,\n            "knowledge_available",\n            False,\n        )\n    )\n\n    knowledge_source = str(\n        getattr(\n            decision,\n            "knowledge_source",\n            "unknown",\n        )\n        or\n        "unknown"\n    )\n\n    # Volatile current facts about another person need\n    # explicit Conversation World evidence.\n    if (\n        knowledge_available\n        and\n        knowledge_source\n        ==\n        "conversation_world"\n    ):\n        return False\n\n    return True\n\n\n'


def ok(text):
    print(f"[OK] {text}")


def fail(text):
    print()
    print(f"[INSTALL ERROR] {text}")
    print("Nothing was overwritten by this installer.")
    raise SystemExit(1)


def replace_once(text, old, new, label):
    count = text.count(old)

    if count != 1:
        fail(
            f"{label}: expected exactly 1 match, found {count}"
        )

    ok(label)

    return text.replace(
        old,
        new,
        1,
    )


def insert_before_once(text, marker, block, label):
    count = text.count(marker)

    if count != 1:
        fail(
            f"{label}: expected exactly 1 marker, found {count}"
        )

    ok(label)

    return text.replace(
        marker,
        block + marker,
        1,
    )


def insert_after_once(text, marker, block, label):
    count = text.count(marker)

    if count != 1:
        fail(
            f"{label}: expected exactly 1 marker, found {count}"
        )

    ok(label)

    return text.replace(
        marker,
        marker + block,
        1,
    )


def replace_section(
    text,
    start_marker,
    end_marker,
    new_section,
    label,
):
    start_count = text.count(
        start_marker
    )

    if start_count != 1:
        fail(
            f"{label}: expected 1 start marker, found {start_count}"
        )

    start = text.index(
        start_marker
    )

    end = text.find(
        end_marker,
        start + len(start_marker),
    )

    if end < 0:
        fail(
            f"{label}: end marker not found"
        )

    ok(label)

    return (
        text[:start]
        +
        new_section
        +
        text[end:]
    )


def syntax_check(text, filename):
    try:
        ast.parse(
            text,
            filename=filename,
        )

    except SyntaxError as error:
        fail(
            f"{filename}: syntax error after patch at "
            f"line {error.lineno}: {error.msg}"
        )

    ok(
        f"{filename} syntax check"
    )


print("=" * 78)
print("EVILNAE 3.6.1 — AFFECT & REPETITION STABILIZER")
print("=" * 78)
print(f"Project: {PROJECT_ROOT}")
print()
print("WICHTIG: bot.py muss vollständig AUS sein.")
print()

contents = {}

for key, path in FILES.items():

    if not path.exists():
        fail(
            f"Missing required file: {path.name}"
        )

    contents[key] = path.read_text(
        encoding="utf-8"
    )


# ---------------------------------------------------------
# BASE VERSIONS
# ---------------------------------------------------------

for key, expected in EXPECTED.items():

    if TARGET[key] in contents[key]:
        continue

    if expected not in contents[key]:
        fail(
            f"Unexpected {FILES[key].name} version. "
            f"Expected marker: {expected}"
        )

ok(
    "3.6.0 live base detected"
)


# ---------------------------------------------------------
# VERSIONS
# ---------------------------------------------------------

for key in FILES:

    if TARGET[key] in contents[key]:
        continue

    contents[key] = replace_once(
        contents[key],
        EXPECTED[key],
        TARGET[key],
        f"{FILES[key].name} version",
    )


# ---------------------------------------------------------
# RESPONSE PLANNER 1.1
# ---------------------------------------------------------

planner = contents["planner"]

planner = replace_once(
    planner,
    "from dataclasses import dataclass, field\n",
    "import re\n\nfrom dataclasses import dataclass, field\n",
    "Planner imports re",
)

planner = insert_before_once(
    planner,
    "def build_response_plan(\n",
    PLANNER_HELPERS,
    "Planner affect-grounding helpers",
)

planner = replace_once(
    planner,
    """def build_response_plan(
    *,
    decision,
    conversation_mode: str,
    social_mode: str = "",
    expression_style: str = "",
) -> ResponsePlan:
""",
    """def build_response_plan(
    *,
    decision,
    conversation_mode: str,
    social_mode: str = "",
    expression_style: str = "",
    user_text: str = "",
    current_inner_state=None,
    is_hanae: bool = False,
    recent_evilnae_messages=None,
) -> ResponsePlan:
""",
    "Planner receives current affect/context",
)

planner = insert_before_once(
    planner,
    """    expression_style = _clean_text(expression_style, 60).lower()
""",
    PLANNER_GROUNDING,
    "Planner grounds affect + user self-report",
)

contents["planner"] = planner


# ---------------------------------------------------------
# BOT -> PLANNER ARGUMENTS
# ---------------------------------------------------------

bot = contents["bot"]

bot = replace_once(
    bot,
    """                expression_style=(
                    expression_plan.style
                ),
""",
    """                expression_style=(
                    expression_plan.style
                ),
                user_text=(
                    user_text
                ),
                current_inner_state=(
                    current_inner_state
                ),
                is_hanae=(
                    is_hanae
                ),
                recent_evilnae_messages=(
                    channel_evilnae_messages[
                        -12:
                    ]
                ),
""",
    "Bot passes real Inner State + recent outputs to Planner",
)

bot = replace_section(
    bot,
    "def has_unsupported_current_fact(\n",
    "def character_identity_violation_reasons(",
    CURRENT_FACT_FUNCTION,
    "Bot expands volatile other-person current fact guard",
)

contents["bot"] = bot


# ---------------------------------------------------------
# SURFACE WRITER 1.1
# ---------------------------------------------------------

surface = contents["surface"]

surface = replace_once(
    surface,
    "from dataclasses import dataclass\n",
    "from dataclasses import dataclass\nfrom difflib import SequenceMatcher\n",
    "Surface Writer imports SequenceMatcher",
)

surface = insert_before_once(
    surface,
    "# =========================================================\n# VALIDATION\n# =========================================================\n",
    SURFACE_HELPERS,
    "Surface Writer context-safety helpers",
)

surface = replace_once(
    surface,
    """TRUSTED EVIDENCE darf Fakten liefern.
Alles andere ist nur Stil/Kontext.
""",
    """TRUSTED EVIDENCE darf Fakten liefern.
Alles andere ist nur Stil/Kontext.

AFFECT AUTHORITY:
- Trocken = Schreibstil, NICHT automatisch schlechte Laune.
- Frühere Evilnae-Antworten sind KEIN Beweis für ihre aktuelle Stimmung.
- INNER STATE ist die Autorität für aktuelle Emotion.
- Wenn INNER STATE neutral ist, erfinde kein "Null Bock",
  "keine Lust", "unmotiviert", "widerwillig" oder "schlecht gelaunt".
- Ein vorheriger Satz darf NICHT als Inhaltsvorlage für den nächsten dienen.
""",
    "Surface Writer dry-is-not-angry rule",
)

surface = replace_once(
    surface,
    """RECENT EVILNAE — USER:
""",
    """ANTI-COPY HISTORY — RECENT EVILNAE / USER:
Diese Zeilen dienen zur KONTINUITÄT und zum VERMEIDEN von Wiederholungen.
NICHT ihren Inhalt, ihre Stimmung oder Formulierung kopieren.

""",
    "Surface Writer marks user history as anti-copy",
)

surface = replace_once(
    surface,
    """RECENT EVILNAE — CHANNEL:
""",
    """ANTI-COPY HISTORY — RECENT EVILNAE / CHANNEL:
Wenn hier bereits dieselbe Stimmung, Pointe oder Antwortidee vorkam,
musst du einen ANDEREN inhaltlichen Winkel wählen — nicht nur Synonyme.

""",
    "Surface Writer marks channel history as anti-copy",
)

surface = replace_once(
    surface,
    """        (
            valid,
            validation_reason
        ) = (
            validate_surface_writer_candidate(

                user_message=(
                    user_message
                ),

                candidate=(
                    candidate
                ),

                allow_question=(
                    allow_question
                ),

                reply_shape=(
                    reply_shape
                ),

                plan_preserved=(
                    plan_preserved
                ),

                new_facts=(
                    new_facts
                ),
            )
        )
""",
    """        context_violation = (
            surface_context_violation_reason(
                candidate=(
                    candidate
                ),
                user_message=(
                    user_message
                ),
                response_plan_text=(
                    response_plan_text
                ),
                inner_state_guidance=(
                    inner_state_guidance
                ),
                evidence_context=(
                    evidence_context
                ),
                recent_evilnae_messages=(
                    recent_evilnae_messages
                ),
                channel_recent_evilnae_messages=(
                    channel_recent_evilnae_messages
                ),
            )
        )

        if context_violation:

            valid = False
            validation_reason = (
                context_violation
            )

        else:

            (
                valid,
                validation_reason
            ) = (
                validate_surface_writer_candidate(

                    user_message=(
                        user_message
                    ),

                    candidate=(
                        candidate
                    ),

                    allow_question=(
                        allow_question
                    ),

                    reply_shape=(
                        reply_shape
                    ),

                    plan_preserved=(
                        plan_preserved
                    ),

                    new_facts=(
                        new_facts
                    ),
                )
            )
""",
    "Surface Writer validates anti-copy / affect / unsupported facts",
)

contents["surface"] = surface


# ---------------------------------------------------------
# OUTPUT QUALITY 2.6
# ---------------------------------------------------------

quality = contents["quality"]

quality = insert_after_once(
    quality,
    "PHRASE_FAMILIES = {\n",
    QUALITY_FAMILIES,
    "Output Quality low-motivation concept families",
)

quality = insert_before_once(
    quality,
    """    # =====================================================
    # EXACT PHRASE REPETITION
    # =====================================================
""",
    QUALITY_EXACT_REPEAT,
    "Output Quality exact short-message repetition",
)

quality = insert_before_once(
    quality,
    """    if (
        max_recent_similarity
""",
    QUALITY_FAMILY_BONUS,
    "Output Quality repeated concept severity",
)

quality = replace_once(
    quality,
    """- Bei mehreren Gute-Nacht-Antworten nicht dieselbe Schlaf-/Traum-Schablone wiederverwenden.
- Die Antwort braucht echten Text mit mindestens einem Wort.
""",
    """- Bei mehreren Gute-Nacht-Antworten nicht dieselbe Schlaf-/Traum-Schablone wiederverwenden.
- Bei semantic/concept repetition NICHT nur Synonyme austauschen. Ändere den tatsächlichen Gedanken/Winkel.
- Insbesondere "keine Lust" -> "Null Bock" -> "unmotiviert" -> "widerwillig" ist DIESELBE Wiederholung und muss inhaltlich verlassen werden.
- Die Antwort braucht echten Text mit mindestens einem Wort.
""",
    "Output Quality repair changes concept, not synonym",
)

contents["quality"] = quality


# ---------------------------------------------------------
# ROUTING 1.3
# ---------------------------------------------------------

routing = contents["routing"]

routing = insert_before_once(
    routing,
    """    words = re.findall(
""",
    ROUTING_FIX,
    "Routing recognizes trailing Evil vocative after self-correction",
)

contents["routing"] = routing


# ---------------------------------------------------------
# EPISODES 1.1 — OWN OUTPUT != CURRENT STATE AUTHORITY
# ---------------------------------------------------------

episodes = contents["episodes"]

episodes = replace_once(
    episodes,
    EPISODE_AUTHORITY_OLD,
    EPISODE_AUTHORITY_NEW,
    "Episode context marks old Evilnae output non-authoritative",
)

contents["episodes"] = episodes


# ---------------------------------------------------------
# INVARIANTS + SYNTAX — BEFORE WRITING
# ---------------------------------------------------------

required = {
    "bot": (
        TARGET["bot"],
        "current_inner_state=(",
        "volatile PRESENT states",
    ),
    "planner": (
        TARGET["planner"],
        "LOW_MOTIVATION_PATTERN",
        "_state_supports_negative_mood",
        "user_self_report_positive",
        "trocken mit angepisst",
    ),
    "surface": (
        TARGET["surface"],
        "ANTI-COPY HISTORY",
        "surface_exact_recent_repeat",
        "surface_invented_negative_mood",
        "surface_unsupported_numeric_fact",
    ),
    "quality": (
        TARGET["quality"],
        "low_motivation_mood",
        "minimal_shutdown",
        "exact_recent_message_repeat",
        "repeated_low_motivation_concept",
    ),
    "routing": (
        TARGET["routing"],
        "trailing vocative",
        r"(?:bin|war)\s+ich",
    ),
    "episodes": (
        TARGET["episodes"],
        "KEINE Autorität für ihre aktuelle Stimmung",
    ),
}

for key, markers in required.items():

    for marker in markers:

        if marker not in contents[key]:
            fail(
                f"Patched {FILES[key].name} missing invariant: {marker}"
            )


for key, text in contents.items():

    syntax_check(
        text,
        FILES[key].name,
    )


# ---------------------------------------------------------
# INSTALLER-LEVEL BEHAVIOR TESTS
# ---------------------------------------------------------

namespace = {
    "__name__": "_planner_test_",
}

exec(
    compile(
        contents["planner"],
        "response_planner.py",
        "exec",
    ),
    namespace,
)

build_plan = namespace[
    "build_response_plan"
]


class FakeState:
    valence = 0.20
    irritation = 0.08
    boredom = 0.20


class FakeDecision:
    action = "reply"
    tone = "dry"
    response_length = "short"
    ask_question = False
    question_goal = ""
    response_goal = ""
    reasoning_summary = ""
    avoid_phrases = []
    social_move = "answer"
    stance = "dry"
    core_thought = "Bin gerade echt nicht in Stimmung, nichts läuft spannend."
    emotional_angle = ""
    target_focus = "current_user"
    reply_shape = "one_liner"
    banter_intensity = 0.20
    warmth_intensity = 0.20
    plan_must_include = []
    plan_must_avoid = []


neutral_plan = build_plan(
    decision=FakeDecision(),
    conversation_mode="direct",
    social_mode="",
    expression_style="natural",
    user_text="Guten Morgen Evil, wie geht's?",
    current_inner_state=FakeState(),
    recent_evilnae_messages=[
        "Ich bin wach. Nur nicht aus Lust.",
        "Bin da, aber mit Null Bock.",
    ],
)

if "nicht in Stimmung" in neutral_plan.core_thought:
    fail(
        "Behavior test: neutral state still preserved invented bad mood"
    )

if neutral_plan.warmth_intensity < 0.46:
    fail(
        "Behavior test: neutral friendly interaction warmth floor failed"
    )


class CorrectionDecision(FakeDecision):
    core_thought = (
        "Hanae ist auch schlecht gelaunt, passt."
    )


correction_plan = build_plan(
    decision=CorrectionDecision(),
    conversation_mode="continuation",
    social_mode="sibling_banter",
    expression_style="natural",
    user_text="Ich bin gut gelaunt sis",
    current_inner_state=FakeState(),
    is_hanae=True,
    recent_evilnae_messages=[],
)

if "Selbstbeschreibung" not in correction_plan.core_thought:
    fail(
        "Behavior test: self-report correction did not override plan"
    )

if not any(
    "widersprechen"
    in item
    for item
    in correction_plan.must_avoid
):
    fail(
        "Behavior test: self-report contradiction guard missing"
    )


# Exact short repetition behavior from patched quality.
quality_namespace = {
    "__name__": "_quality_test_",
}

exec(
    compile(
        contents["quality"],
        "response_quality.py",
        "exec",
    ),
    quality_namespace,
)

analyze_quality = quality_namespace[
    "analyze_response_quality"
]

exact_repeat = analyze_quality(
    "NÖ. Genau so.",
    recent_evilnae_messages=[
        "NÖ. Genau so.",
    ],
)

if not exact_repeat.severe:
    fail(
        "Behavior test: exact short repeat is not severe"
    )

low_concept = analyze_quality(
    "Bin da, aber komplett unmotiviert.",
    recent_evilnae_messages=[
        "Bin da, aber mit Null Bock.",
    ],
)

if not low_concept.severe:
    fail(
        "Behavior test: low-motivation synonym loop is not severe"
    )


ok(
    "Behavior self-test: 6/6 PASS"
)


# ---------------------------------------------------------
# BACKUP
# ---------------------------------------------------------

timestamp = (
    datetime.now()
    .astimezone()
    .strftime(
        "%Y%m%d-%H%M%S"
    )
)

backup_dir = (
    BACKUP_ROOT
    /
    timestamp
)

suffix = 1

while backup_dir.exists():

    backup_dir = (
        BACKUP_ROOT
        /
        f"{timestamp}_{suffix:02d}"
    )

    suffix += 1


backup_dir.mkdir(
    parents=True,
    exist_ok=False,
)


for path in FILES.values():

    shutil.copy2(
        path,
        backup_dir / path.name,
    )

    ok(
        f"Backup: {path.name}"
    )


# ---------------------------------------------------------
# WRITE
# ---------------------------------------------------------

def atomic_write(
    path,
    text,
):
    temp = Path(
        str(path)
        +
        ".tmp"
    )

    temp.write_text(
        text,
        encoding="utf-8",
    )

    temp.replace(
        path
    )


for key, path in FILES.items():

    atomic_write(
        path,
        contents[key],
    )

    ok(
        f"Updated: {path.name}"
    )


# ---------------------------------------------------------
# COMPILE
# ---------------------------------------------------------

result = subprocess.run(
    [
        sys.executable,
        "-m",
        "py_compile",
        *[
            str(path)
            for path
            in FILES.values()
        ],
    ],
    cwd=str(
        PROJECT_ROOT
    ),
    check=False,
)


if result.returncode != 0:

    print(
        f"Backup: {backup_dir}"
    )

    raise SystemExit(
        result.returncode
    )


ok(
    "Post-install py_compile: 6/6"
)


# ---------------------------------------------------------
# SAFE MODULE SELF TESTS
# ---------------------------------------------------------

for module in (
    "response_planner.py",
    "response_quality.py",
    "surface_writer.py",
    "conversation_episodes.py",
):

    result = subprocess.run(
        [
            sys.executable,
            module,
        ],
        cwd=str(
            PROJECT_ROOT
        ),
        check=False,
    )

    if result.returncode != 0:

        print()
        print(
            f"[POST-INSTALL WARNING] {module} self-test failed."
        )

        print(
            f"Backup: {backup_dir}"
        )

        raise SystemExit(
            result.returncode
        )

    ok(
        f"Self-test: {module}"
    )


print()
print("=" * 78)
print("EVILNAE 3.6.1 AFFECT & REPETITION STABILIZER INSTALLED")
print("=" * 78)

print()
print("Fixed:")
print("  [✓] Dry style != invented bad mood")
print("  [✓] Inner State is authority for current Evilnae affect")
print("  [✓] neutral state blocks Null-Bock/unmotiviert/widerwillig loops")
print("  [✓] recent Evilnae messages are anti-copy history, not content source")
print("  [✓] exact short repeats such as 'NÖ. Genau so.' are severe")
print("  [✓] concept repeats catch Lust -> Null Bock -> unmotiviert -> widerwillig")
print("  [✓] repair must change the idea, not just use a synonym")
print("  [✓] user self-report/correction outranks Evilnae's guess about that user")
print("  [✓] volatile Hanae/Error mood facts require Conversation World evidence")
print("  [✓] 'bin ich gar nicht evil!' is recognized as trailing vocative/direct")
print("  [✓] unsupported invented years/experience claims rejected by Qwen Surface Writer")

print()
print("Unchanged:")
print("  [✓] Foundation / Excel")
print("  [✓] Character Learning / Memories / DB")
print("  [✓] Emotional Salience data")
print("  [✓] Conversation Episode data")
print("  [✓] Inner State values")
print("  [✓] Social Ego / Roast system")
print("  [✓] Emote Layer")

print()
print(f"Backup: {backup_dir}")

print()
print("NO MEMORY RESET REQUIRED.")

print()
print("NEXT:")
print("  python bot.py")

print()
print("Expected startup:")
print("  Bot Version: 3.6.1-affect-repetition")
print("  Response Planner v1.1-affect-grounded: ACTIVE")
print("  Conversation Episodes v1.1-authority-safe: ACTIVE")
print("  Qwen Surface Writer v1.1-context-safe: PRIMARY")
print("  Output Quality v2.6-concept-repetition: ACTIVE")
print("  Routing Hardening v1.3-trailing-vocative: ACTIVE")
