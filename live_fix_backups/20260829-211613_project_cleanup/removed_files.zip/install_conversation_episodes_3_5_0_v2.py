
from pathlib import Path
from datetime import datetime

import ast
import shutil
import subprocess
import sys

PROJECT_ROOT = Path(__file__).resolve().parent
BOT_PATH = PROJECT_ROOT / "bot.py"
EPISODE_PATH = PROJECT_ROOT / "conversation_episodes.py"
BACKUP_ROOT = PROJECT_ROOT / "live_fix_backups"

EXPECTED_BOT = 'BOT_VERSION = "3.4.0-qwen-surface-writer"'
TARGET_BOT = 'BOT_VERSION = "3.5.0-conversation-episodes"'

EPISODE_SOURCE = 'import hashlib\nimport json\nimport os\nimport re\nimport threading\nimport time\nfrom dataclasses import dataclass\nfrom pathlib import Path\nfrom typing import Any, Optional\n\nCONVERSATION_EPISODES_VERSION = "1.0"\n\nEPISODE_GAP_SECONDS = int(\n    os.getenv("EVILNAE_EPISODE_GAP_SECONDS", str(20 * 60))\n)\nEPISODE_HARD_MAX_SECONDS = int(\n    os.getenv("EVILNAE_EPISODE_HARD_MAX_SECONDS", str(90 * 60))\n)\nEPISODE_MAX_EVENTS = int(\n    os.getenv("EVILNAE_EPISODE_MAX_EVENTS", "80")\n)\nEPISODE_MAX_CLOSED = int(\n    os.getenv("EVILNAE_EPISODE_MAX_CLOSED", "120")\n)\nEPISODE_PROMPT_EVENTS = int(\n    os.getenv("EVILNAE_EPISODE_PROMPT_EVENTS", "12")\n)\nEPISODE_STATE_PATH = Path(\n    os.getenv("EVILNAE_EPISODE_STATE_PATH", "evilnae_episodes.json")\n)\n\n_LOCK = threading.RLock()\n\n\n@dataclass\nclass EpisodeObservation:\n    episode_id: str = ""\n    started_new: bool = False\n    closed_previous: bool = False\n    close_reason: str = ""\n    event_added: bool = False\n    active_event_count: int = 0\n    participant_count: int = 0\n\n\ndef _default_data():\n    return {\n        "version": CONVERSATION_EPISODES_VERSION,\n        "channels": {},\n        "closed": [],\n    }\n\n\ndef _load():\n    if not EPISODE_STATE_PATH.exists():\n        return _default_data()\n\n    try:\n        data = json.loads(\n            EPISODE_STATE_PATH.read_text(encoding="utf-8")\n        )\n    except Exception:\n        return _default_data()\n\n    if not isinstance(data, dict):\n        return _default_data()\n\n    data.setdefault("version", CONVERSATION_EPISODES_VERSION)\n    data.setdefault("channels", {})\n    data.setdefault("closed", [])\n    return data\n\n\ndef _save(data):\n    data["version"] = CONVERSATION_EPISODES_VERSION\n\n    temp = Path(str(EPISODE_STATE_PATH) + ".tmp")\n    temp.write_text(\n        json.dumps(\n            data,\n            ensure_ascii=False,\n            indent=2,\n        ),\n        encoding="utf-8",\n    )\n    temp.replace(EPISODE_STATE_PATH)\n\n\ndef _clean(value, limit=800):\n    text = re.sub(\n        r"\\s+",\n        " ",\n        str(value or ""),\n    ).strip()\n    return text[:limit]\n\n\ndef _new_episode(channel_id, timestamp):\n    return {\n        "episode_id":\n            f"ep_{str(channel_id)}_{int(timestamp * 1000)}",\n        "channel_id": str(channel_id),\n        "status": "active",\n        "started_at": float(timestamp),\n        "updated_at": float(timestamp),\n        "ended_at": 0.0,\n        "close_reason": "",\n        "participants": {},\n        "events": [],\n        "seen_event_keys": [],\n        "digest": "",\n    }\n\n\ndef _event_key(\n    *,\n    role,\n    user_id,\n    username,\n    content,\n    message_id="",\n):\n    if message_id:\n        return "msg:" + str(message_id)\n\n    raw = (\n        f"{role}|{user_id}|"\n        f"{username}|{content}"\n    )\n\n    return (\n        "hash:"\n        +\n        hashlib.sha1(\n            raw.encode(\n                "utf-8",\n                errors="ignore",\n            )\n        ).hexdigest()\n    )\n\n\ndef _participant_names(episode):\n    result = []\n\n    for item in (\n        episode.get("participants", {})\n        or {}\n    ).values():\n\n        if not isinstance(item, dict):\n            continue\n\n        name = _clean(\n            item.get("username", ""),\n            80,\n        )\n\n        if name:\n            result.append(name)\n\n    return result\n\n\ndef _build_digest(episode):\n    names = _participant_names(episode)\n\n    participant_text = (\n        ", ".join(names[:6])\n        if names\n        else "unbekannte Teilnehmer"\n    )\n\n    meaningful = []\n\n    for event in episode.get("events", []) or []:\n        if not isinstance(event, dict):\n            continue\n\n        content = _clean(\n            event.get("content", ""),\n            180,\n        )\n\n        if not content:\n            continue\n\n        if content.startswith("[nonverbale"):\n            continue\n\n        if len(\n            re.findall(\n                r"[A-Za-zÄÖÜäöüß0-9]+",\n                content,\n            )\n        ) < 2:\n            continue\n\n        meaningful.append(content)\n\n    if not meaningful:\n        return f"Gespräch mit {participant_text}"\n\n    snippets = []\n\n    for text in meaningful[:2] + meaningful[-2:]:\n        if text not in snippets:\n            snippets.append(text)\n\n    return (\n        f"Teilnehmer: {participant_text}. "\n        f"Verlauf: {\' | \'.join(snippets)}"\n    )[:900]\n\n\ndef _boundary_reason(episode, timestamp):\n    updated_at = float(\n        episode.get("updated_at", 0.0)\n        or 0.0\n    )\n\n    started_at = float(\n        episode.get("started_at", 0.0)\n        or 0.0\n    )\n\n    if (\n        updated_at\n        and\n        timestamp - updated_at\n        >=\n        EPISODE_GAP_SECONDS\n    ):\n        return "conversation_gap"\n\n    if (\n        started_at\n        and\n        timestamp - started_at\n        >=\n        EPISODE_HARD_MAX_SECONDS\n    ):\n        return "hard_duration_limit"\n\n    if len(\n        episode.get("events", [])\n        or []\n    ) >= EPISODE_MAX_EVENTS:\n        return "event_limit"\n\n    return ""\n\n\ndef _close_locked(\n    data,\n    channel_key,\n    *,\n    timestamp,\n    reason,\n):\n    episode = (\n        data.get("channels", {})\n        .get(channel_key)\n    )\n\n    if not isinstance(episode, dict):\n        return None\n\n    episode["status"] = "closed"\n    episode["ended_at"] = float(timestamp)\n    episode["updated_at"] = float(timestamp)\n    episode["close_reason"] = reason or "closed"\n    episode["digest"] = _build_digest(episode)\n    episode.pop("seen_event_keys", None)\n\n    closed = list(\n        data.get("closed", [])\n        or []\n    )\n\n    closed.append(episode)\n\n    data["closed"] = closed[\n        -EPISODE_MAX_CLOSED:\n    ]\n\n    data["channels"].pop(\n        channel_key,\n        None,\n    )\n\n    return episode\n\n\ndef observe_episode_message(\n    *,\n    channel_id: Any,\n    role: str,\n    content: str,\n    user_id: Any = "",\n    username: str = "",\n    message_id: Any = "",\n    timestamp: Optional[float] = None,\n):\n    timestamp = float(\n        timestamp\n        if timestamp is not None\n        else time.time()\n    )\n\n    channel_key = str(channel_id)\n    role = _clean(role, 40).lower() or "user"\n    content = _clean(content, 900)\n    user_id = str(user_id or "")\n    username = _clean(username, 100)\n    message_id = str(message_id or "")\n\n    if not content:\n        return EpisodeObservation()\n\n    with _LOCK:\n        data = _load()\n        episode = (\n            data["channels"]\n            .get(channel_key)\n        )\n\n        started_new = False\n        closed_previous = False\n        close_reason = ""\n\n        if isinstance(episode, dict):\n            close_reason = _boundary_reason(\n                episode,\n                timestamp,\n            )\n\n            if close_reason:\n                _close_locked(\n                    data,\n                    channel_key,\n                    timestamp=timestamp,\n                    reason=close_reason,\n                )\n                episode = None\n                closed_previous = True\n\n        if not isinstance(episode, dict):\n            episode = _new_episode(\n                channel_id,\n                timestamp,\n            )\n            data["channels"][\n                channel_key\n            ] = episode\n            started_new = True\n\n        key = _event_key(\n            role=role,\n            user_id=user_id,\n            username=username,\n            content=content,\n            message_id=message_id,\n        )\n\n        seen = list(\n            episode.get("seen_event_keys", [])\n            or []\n        )\n\n        if key in seen:\n            return EpisodeObservation(\n                episode_id=episode.get(\n                    "episode_id",\n                    "",\n                ),\n                started_new=started_new,\n                closed_previous=closed_previous,\n                close_reason=close_reason,\n                event_added=False,\n                active_event_count=len(\n                    episode.get("events", [])\n                    or []\n                ),\n                participant_count=len(\n                    episode.get("participants", {})\n                    or {}\n                ),\n            )\n\n        events = list(\n            episode.get("events", [])\n            or []\n        )\n\n        events.append(\n            {\n                "role": role,\n                "user_id": user_id,\n                "username": username,\n                "content": content,\n                "message_id": message_id,\n                "timestamp": timestamp,\n            }\n        )\n\n        episode["events"] = events[\n            -EPISODE_MAX_EVENTS:\n        ]\n\n        seen.append(key)\n\n        episode["seen_event_keys"] = seen[\n            -(EPISODE_MAX_EVENTS * 2):\n        ]\n\n        if role not in {\n            "evilnae",\n            "assistant",\n            "bot",\n        }:\n            pkey = (\n                user_id\n                or username\n                or "unknown"\n            )\n\n            participants = (\n                episode.get("participants", {})\n                or {}\n            )\n\n            item = dict(\n                participants.get(pkey, {})\n                or {}\n            )\n\n            item["user_id"] = user_id\n            item["username"] = (\n                username\n                or item.get(\n                    "username",\n                    "unknown",\n                )\n            )\n            item["message_count"] = (\n                int(\n                    item.get(\n                        "message_count",\n                        0,\n                    )\n                    or 0\n                )\n                +\n                1\n            )\n            item["last_seen"] = timestamp\n\n            participants[pkey] = item\n            episode["participants"] = participants\n\n        episode["updated_at"] = timestamp\n\n        _save(data)\n\n        return EpisodeObservation(\n            episode_id=episode.get(\n                "episode_id",\n                "",\n            ),\n            started_new=started_new,\n            closed_previous=closed_previous,\n            close_reason=close_reason,\n            event_added=True,\n            active_event_count=len(\n                episode.get("events", [])\n                or []\n            ),\n            participant_count=len(\n                episode.get("participants", {})\n                or {}\n            ),\n        )\n\n\ndef sync_evilnae_from_snapshot(\n    channel_id,\n    snapshot,\n):\n    added = 0\n\n    for item in snapshot or []:\n        if not isinstance(item, dict):\n            continue\n\n        role = _clean(\n            item.get(\n                "role",\n                item.get("type", ""),\n            ),\n            40,\n        ).lower()\n\n        username = _clean(\n            item.get(\n                "username",\n                item.get("author_name", ""),\n            ),\n            100,\n        )\n\n        if not (\n            role in {\n                "assistant",\n                "evilnae",\n                "bot",\n            }\n            or\n            username.lower()\n            ==\n            "evilnae"\n        ):\n            continue\n\n        content = _clean(\n            item.get(\n                "content",\n                item.get("text", ""),\n            ),\n            900,\n        )\n\n        if not content:\n            continue\n\n        raw_timestamp = item.get(\n            "timestamp",\n            None,\n        )\n\n        try:\n            event_timestamp = (\n                float(raw_timestamp)\n                if raw_timestamp is not None\n                else None\n            )\n        except Exception:\n            event_timestamp = None\n\n        result = observe_episode_message(\n            channel_id=channel_id,\n            role="evilnae",\n            content=content,\n            user_id=item.get(\n                "user_id",\n                item.get(\n                    "author_id",\n                    "evilnae",\n                ),\n            ),\n            username=username or "Evilnae",\n            message_id=item.get(\n                "message_id",\n                item.get("id", ""),\n            ),\n            timestamp=event_timestamp,\n        )\n\n        if result.event_added:\n            added += 1\n\n    return added\n\n\ndef close_stale_episodes(\n    now=None,\n):\n    now = float(\n        now\n        if now is not None\n        else time.time()\n    )\n\n    closed_count = 0\n\n    with _LOCK:\n        data = _load()\n\n        for channel_key in list(\n            data.get("channels", {})\n            or {}\n        ):\n            episode = (\n                data["channels"]\n                .get(channel_key)\n            )\n\n            if not isinstance(episode, dict):\n                continue\n\n            reason = _boundary_reason(\n                episode,\n                now,\n            )\n\n            if not reason:\n                continue\n\n            _close_locked(\n                data,\n                channel_key,\n                timestamp=now,\n                reason=(\n                    "startup_stale"\n                    if reason == "conversation_gap"\n                    else reason\n                ),\n            )\n\n            closed_count += 1\n\n        if closed_count:\n            _save(data)\n\n    return closed_count\n\n\ndef get_active_episode(channel_id):\n    with _LOCK:\n        data = _load()\n\n        episode = (\n            data.get("channels", {})\n            .get(str(channel_id))\n        )\n\n        if not isinstance(episode, dict):\n            return None\n\n        return json.loads(\n            json.dumps(\n                episode,\n                ensure_ascii=False,\n            )\n        )\n\n\ndef get_recent_closed_episodes(\n    channel_id,\n    *,\n    limit=3,\n):\n    channel_key = str(channel_id)\n\n    with _LOCK:\n        data = _load()\n\n        result = [\n            item\n\n            for item\n            in data.get("closed", [])\n            or []\n\n            if (\n                isinstance(item, dict)\n                and\n                str(\n                    item.get(\n                        "channel_id",\n                        "",\n                    )\n                )\n                ==\n                channel_key\n            )\n        ]\n\n    return result[\n        -max(1, int(limit)):\n    ]\n\n\ndef format_episode_context(\n    channel_id,\n):\n    active = get_active_episode(\n        channel_id\n    )\n\n    recent = get_recent_closed_episodes(\n        channel_id,\n        limit=2,\n    )\n\n    lines = [\n        "[PERSISTENT CONVERSATION EPISODES]",\n        (\n            "Episode = zusammenhängendes Gesprächserlebnis, "\n            "nicht automatisch langfristige Erinnerung."\n        ),\n        (\n            "Abgeschlossene Episoden geben Kontext, "\n            "verändern aber noch nicht Evilnaes Charakter."\n        ),\n        "",\n    ]\n\n    if active:\n        names = _participant_names(active)\n\n        lines.extend(\n            [\n                "ACTIVE EPISODE:",\n                f"id={active.get(\'episode_id\', \'\')}",\n                (\n                    "participants="\n                    +\n                    (\n                        ", ".join(names[:8])\n                        if names\n                        else\n                        "keine"\n                    )\n                ),\n                "recent events:",\n            ]\n        )\n\n        for event in (\n            active.get("events", [])\n            or []\n        )[-EPISODE_PROMPT_EVENTS:]:\n\n            if not isinstance(event, dict):\n                continue\n\n            role = _clean(\n                event.get("role", "user"),\n                40,\n            )\n\n            name = _clean(\n                event.get("username", ""),\n                80,\n            )\n\n            content = _clean(\n                event.get("content", ""),\n                260,\n            )\n\n            if not content:\n                continue\n\n            speaker = (\n                "Evilnae"\n                if role in {\n                    "evilnae",\n                    "assistant",\n                    "bot",\n                }\n                else\n                (name or "User")\n            )\n\n            lines.append(\n                f"- {speaker}: {content}"\n            )\n\n    else:\n        lines.append(\n            "ACTIVE EPISODE: keine"\n        )\n\n    if recent:\n        lines.extend(\n            [\n                "",\n                "RECENT CLOSED EPISODES:",\n            ]\n        )\n\n        for item in recent:\n            lines.append(\n                f"- {item.get(\'episode_id\', \'\')}: "\n                f"{_clean(item.get(\'digest\', \'\'), 600)}"\n            )\n\n    return "\\n".join(lines).strip()\n\n\ndef format_episode_observation_debug(\n    result,\n):\n    return (\n        "[CONVERSATION EPISODE] "\n        f"v={CONVERSATION_EPISODES_VERSION} "\n        f"id={result.episode_id!r} "\n        f"new={result.started_new} "\n        f"closed_previous={result.closed_previous} "\n        f"close_reason={result.close_reason!r} "\n        f"event_added={result.event_added} "\n        f"events={result.active_event_count} "\n        f"participants={result.participant_count}"\n    )\n\n\ndef format_episode_stats_debug():\n    with _LOCK:\n        data = _load()\n\n    return (\n        "[CONVERSATION EPISODES] "\n        f"v={CONVERSATION_EPISODES_VERSION} "\n        f"active={len(data.get(\'channels\', {}) or {})} "\n        f"closed={len(data.get(\'closed\', []) or [])} "\n        f"gap={EPISODE_GAP_SECONDS}s "\n        f"max_events={EPISODE_MAX_EVENTS}"\n    )\n\n\ndef _self_test():\n    global EPISODE_STATE_PATH\n\n    original = EPISODE_STATE_PATH\n    test_path = Path(\n        "_evilnae_episode_selftest.json"\n    )\n\n    EPISODE_STATE_PATH = test_path\n\n    try:\n        if test_path.exists():\n            test_path.unlink()\n\n        tests = []\n\n        first = observe_episode_message(\n            channel_id="1",\n            role="user",\n            user_id="10",\n            username="Alice",\n            content="ich hab heute den boss gelegt",\n            message_id="100",\n            timestamp=1000.0,\n        )\n\n        tests.append(\n            (\n                "new episode starts",\n                first.started_new\n                and\n                first.event_added,\n            )\n        )\n\n        second = observe_episode_message(\n            channel_id="1",\n            role="user",\n            user_id="10",\n            username="Alice",\n            content="war komplett cursed",\n            message_id="101",\n            timestamp=1050.0,\n        )\n\n        tests.append(\n            (\n                "same episode continues",\n                (\n                    not second.started_new\n                    and\n                    second.active_event_count == 2\n                ),\n            )\n        )\n\n        duplicate = observe_episode_message(\n            channel_id="1",\n            role="user",\n            user_id="10",\n            username="Alice",\n            content="war komplett cursed",\n            message_id="101",\n            timestamp=1051.0,\n        )\n\n        tests.append(\n            (\n                "message id dedupe",\n                (\n                    not duplicate.event_added\n                    and\n                    duplicate.active_event_count == 2\n                ),\n            )\n        )\n\n        rotated = observe_episode_message(\n            channel_id="1",\n            role="user",\n            user_id="11",\n            username="Bob",\n            content="neues thema",\n            message_id="102",\n            timestamp=(\n                1050.0\n                +\n                EPISODE_GAP_SECONDS\n                +\n                5\n            ),\n        )\n\n        tests.append(\n            (\n                "20m gap rotates",\n                (\n                    rotated.started_new\n                    and\n                    rotated.closed_previous\n                    and\n                    rotated.close_reason\n                    ==\n                    "conversation_gap"\n                ),\n            )\n        )\n\n        context = format_episode_context("1")\n\n        tests.append(\n            (\n                "prompt context",\n                (\n                    "ACTIVE EPISODE"\n                    in context\n                    and\n                    "Bob"\n                    in context\n                ),\n            )\n        )\n\n        closed = get_recent_closed_episodes(\n            "1",\n            limit=3,\n        )\n\n        tests.append(\n            (\n                "closed archive digest",\n                (\n                    len(closed) == 1\n                    and\n                    bool(\n                        closed[0].get(\n                            "digest"\n                        )\n                    )\n                ),\n            )\n        )\n\n        passed = sum(\n            1\n            for _, success\n            in tests\n            if success\n        )\n\n        print("")\n        print("=" * 58)\n        print(\n            f"CONVERSATION EPISODES v"\n            f"{CONVERSATION_EPISODES_VERSION} TEST"\n        )\n        print("=" * 58)\n\n        for name, success in tests:\n            print(\n                f"[{\'PASS\' if success else \'FAIL\'}] "\n                f"{name}"\n            )\n\n        print(\n            f"RESULT: "\n            f"{passed}/{len(tests)} PASS"\n        )\n\n        return (\n            0\n            if passed == len(tests)\n            else 1\n        )\n\n    finally:\n        EPISODE_STATE_PATH = original\n\n        try:\n            if test_path.exists():\n                test_path.unlink()\n        except Exception:\n            pass\n\n\nif __name__ == "__main__":\n    raise SystemExit(\n        _self_test()\n    )\n'
EPISODE_IMPORT = 'from conversation_episodes import (\n    CONVERSATION_EPISODES_VERSION,\n    observe_episode_message,\n    sync_evilnae_from_snapshot,\n    close_stale_episodes,\n    format_episode_context,\n    format_episode_observation_debug,\n    format_episode_stats_debug,\n)\n\n'
EPISODE_OBSERVE = '    # =====================================================\n    # PERSISTENT CONVERSATION EPISODES\n    # =====================================================\n\n    episode_observation = (\n        observe_episode_message(\n            channel_id=channel_id,\n            role="user",\n            user_id=user_id,\n            username=username,\n            content=(\n                perception.text\n                or perception.raw_content\n                or "[nonverbale Reaktion]"\n            ),\n            message_id=getattr(\n                message,\n                "id",\n                "",\n            ),\n            timestamp=(\n                message.created_at.timestamp()\n                if getattr(\n                    message,\n                    "created_at",\n                    None,\n                )\n                else time.time()\n            ),\n        )\n    )\n\n    synced_episode_evilnae = (\n        sync_evilnae_from_snapshot(\n            channel_id,\n            channel_snapshot,\n        )\n    )\n\n    persistent_episode_context_text = (\n        format_episode_context(\n            channel_id\n        )\n    )\n\n    print(\n        format_episode_observation_debug(\n            episode_observation\n        )\n    )\n\n    if synced_episode_evilnae:\n        print(\n            "[CONVERSATION EPISODE SYNC] "\n            f"user={username} "\n            f"evilnae_events_added="\n            f"{synced_episode_evilnae}"\n        )\n\n'
STARTUP_BLOCK = '    stale_episodes_closed = (\n        close_stale_episodes()\n    )\n\n    print(\n        format_episode_stats_debug()\n    )\n\n    if stale_episodes_closed:\n        print(\n            "[CONVERSATION EPISODE RECOVERY] "\n            f"closed_stale="\n            f"{stale_episodes_closed}"\n        )\n\n'


def ok(text):
    print(f"[OK] {text}")


def fail(text):
    print()
    print(f"[INSTALL ERROR] {text}")
    print("Nothing was overwritten by this installer.")
    raise SystemExit(1)


def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        fail(
            f"{label}: expected exactly 1 match, found {count}"
        )
    ok(label)
    return text.replace(old, new, 1)


def insert_before_once(text, marker, block, label):
    count = text.count(marker)
    if count != 1:
        fail(
            f"{label}: expected exactly 1 marker, found {count}"
        )
    ok(label)
    return text.replace(marker, block + marker, 1)


def insert_after_once(text, marker, block, label):
    count = text.count(marker)
    if count != 1:
        fail(
            f"{label}: expected exactly 1 marker, found {count}"
        )
    ok(label)
    return text.replace(marker, marker + block, 1)


def insert_after_in_function_once(
    text,
    *,
    function_marker,
    marker,
    block,
    label,
):
    """
    Scope an insertion to one function instead of demanding
    that a common statement occurs exactly once in bot.py.

    This is needed because apply_time_decay() legitimately
    exists in several runtime paths.
    """

    function_count = text.count(
        function_marker
    )

    if function_count != 1:
        fail(
            f"{label}: expected exactly 1 function marker "
            f"{function_marker!r}, found {function_count}"
        )

    function_start = text.index(
        function_marker
    )

    next_event = text.find(
        "\n@bot.event",
        function_start + len(function_marker),
    )

    next_async_top_level = text.find(
        "\nasync def ",
        function_start + len(function_marker),
    )

    candidates = [
        pos
        for pos in (
            next_event,
            next_async_top_level,
        )
        if pos >= 0
    ]

    function_end = (
        min(candidates)
        if candidates
        else len(text)
    )

    section = text[
        function_start:function_end
    ]

    marker_count = section.count(
        marker
    )

    if marker_count != 1:
        fail(
            f"{label}: inside {function_marker!r} expected "
            f"exactly 1 target marker, found {marker_count}"
        )

    local_index = section.index(
        marker
    )

    absolute_end = (
        function_start
        + local_index
        + len(marker)
    )

    ok(label)

    return (
        text[:absolute_end]
        + block
        + text[absolute_end:]
    )


def syntax_check(text, filename):
    try:
        ast.parse(text, filename=filename)
    except SyntaxError as error:
        fail(
            f"{filename}: syntax error after patch at "
            f"line {error.lineno}: {error.msg}"
        )
    ok(f"{filename} syntax check")


print("=" * 78)
print("EVILNAE 3.5.0 — PERSISTENT CONVERSATION EPISODES V2")
print("=" * 78)
print(f"Project: {PROJECT_ROOT}")
print()
print("WICHTIG: bot.py muss vollständig AUS sein.")
print()

if not BOT_PATH.exists():
    fail("bot.py missing")

bot = BOT_PATH.read_text(encoding="utf-8")

if (
    TARGET_BOT in bot
    and EPISODE_PATH.exists()
    and 'CONVERSATION_EPISODES_VERSION = "1.0"'
    in EPISODE_PATH.read_text(encoding="utf-8")
):
    print("3.5.0 Conversation Episodes already installed.")
    raise SystemExit(0)

if EXPECTED_BOT not in bot:
    fail("Expected Bot 3.4.0-qwen-surface-writer")

if EPISODE_PATH.exists():
    fail("conversation_episodes.py already exists unexpectedly.")

for marker in (
    "Response Planner v",
    "Qwen Surface Writer v",
    "primary_writer_callable",
    "[AUTO FILE LOGGING]",
):
    if marker not in bot:
        fail(f"Required 3.4 invariant missing: {marker}")

ok("3.4.0 Qwen Surface Writer base detected")

bot = replace_once(
    bot,
    EXPECTED_BOT,
    TARGET_BOT,
    "Bot version -> 3.5.0-conversation-episodes",
)

bot = insert_before_once(
    bot,
    "from conversation_understanding import (\n",
    EPISODE_IMPORT,
    "bot.py imports Conversation Episodes",
)

bot = insert_after_in_function_once(
    bot,
    function_marker="async def on_ready",
    marker="""    apply_time_decay()

""",
    block=STARTUP_BLOCK,
    label="Startup closes stale episodes",
)

bot = replace_once(
    bot,
    """    print(
        "Structured Core Thought: ACTIVE"
    )

""",
    """    print(
        "Structured Core Thought: ACTIVE"
    )

    print(
        f"Conversation Episodes v"
        f"{CONVERSATION_EPISODES_VERSION}: ACTIVE"
    )

    print(
        "Episode Gap Boundary: 20min default"
    )

    print(
        "Episode -> Character Learning: DISABLED"
    )

""",
    "Startup Episode banner",
)

bot = insert_after_once(
    bot,
    """    channel_snapshot = list(
        get_channel_context(
            channel_id
        )
    )

""",
    EPISODE_OBSERVE,
    "Observe persistent conversation episode",
)

bot = replace_once(
    bot,
    """            + b3c_episode_focus_text
        )

        # B3F -> BRAIN
""",
    """            + b3c_episode_focus_text
            + "\\n\\n"
            + persistent_episode_context_text
        )

        # B3F -> BRAIN
""",
    "Brain receives persistent episode context",
)

bot = replace_once(
    bot,
    """            + response_plan_text
        )
""",
    """            + response_plan_text
            + "\\n\\n"
            + persistent_episode_context_text
        )
""",
    "Writer receives persistent episode context",
)

bot = replace_once(
    bot,
    """        for surface_piece in (
            character_directive_text,
            character_state_text,
        ):
""",
    """        for surface_piece in (
            character_directive_text,
            character_state_text,
            persistent_episode_context_text,
        ):
""",
    "Qwen Surface Writer receives episode context",
)

for marker in (
    TARGET_BOT,
    "CONVERSATION_EPISODES_VERSION",
    "persistent_episode_context_text",
    "observe_episode_message(",
    "sync_evilnae_from_snapshot(",
    "Episode -> Character Learning: DISABLED",
):
    if marker not in bot:
        fail(f"Patched bot.py missing invariant: {marker}")

for marker in (
    'CONVERSATION_EPISODES_VERSION = "1.0"',
    "def observe_episode_message(",
    "def close_stale_episodes(",
    "def format_episode_context(",
    "conversation_gap",
    "EPISODE_GAP_SECONDS",
):
    if marker not in EPISODE_SOURCE:
        fail(
            f"conversation_episodes.py missing invariant: {marker}"
        )

syntax_check(EPISODE_SOURCE, "conversation_episodes.py")
syntax_check(bot, "bot.py")

contract_tests = {
    "20 minute default boundary":
        "str(20 * 60)" in EPISODE_SOURCE,
    "persistent JSON store":
        "evilnae_episodes.json" in EPISODE_SOURCE,
    "message id dedupe":
        (
            "message_id" in EPISODE_SOURCE
            and "seen_event_keys" in EPISODE_SOURCE
        ),
    "Brain receives episodes":
        "+ persistent_episode_context_text" in bot,
    "Qwen receives episodes":
        "persistent_episode_context_text," in bot,
    "no new LLM/API call":
        (
            "safe_openai_request" not in EPISODE_SOURCE
            and "ollama" not in EPISODE_SOURCE.lower()
        ),
    "episodes do not learn":
        (
            "character_learning" not in EPISODE_SOURCE
            and "database." not in EPISODE_SOURCE
        ),
}

failed = [
    name
    for name, success
    in contract_tests.items()
    if not success
]

if failed:
    fail(
        "Contract self-test failed: "
        + ", ".join(failed)
    )

ok(
    f"Contract self-test: "
    f"{len(contract_tests)}/{len(contract_tests)} PASS"
)

timestamp = (
    datetime.now()
    .astimezone()
    .strftime("%Y%m%d-%H%M%S")
)

backup_dir = BACKUP_ROOT / timestamp
suffix = 1

while backup_dir.exists():
    backup_dir = (
        BACKUP_ROOT
        / f"{timestamp}_{suffix:02d}"
    )
    suffix += 1

backup_dir.mkdir(
    parents=True,
    exist_ok=False,
)

shutil.copy2(
    BOT_PATH,
    backup_dir / BOT_PATH.name,
)

ok("Backup: bot.py")


def atomic_write(path, text):
    temp = Path(str(path) + ".tmp")
    temp.write_text(text, encoding="utf-8")
    temp.replace(path)


atomic_write(
    EPISODE_PATH,
    EPISODE_SOURCE,
)
ok("Created: conversation_episodes.py")

atomic_write(
    BOT_PATH,
    bot,
)
ok("Updated: bot.py")

result = subprocess.run(
    [
        sys.executable,
        "-m",
        "py_compile",
        str(EPISODE_PATH),
        str(BOT_PATH),
    ],
    cwd=str(PROJECT_ROOT),
    check=False,
)

if result.returncode != 0:
    print(f"Backup: {backup_dir}")
    raise SystemExit(result.returncode)

ok("Post-install py_compile: 2/2")

result = subprocess.run(
    [
        sys.executable,
        str(EPISODE_PATH),
    ],
    cwd=str(PROJECT_ROOT),
    check=False,
)

if result.returncode != 0:
    print(f"Backup: {backup_dir}")
    raise SystemExit(result.returncode)

ok("Self-test: conversation_episodes.py")

print()
print("=" * 78)
print("EVILNAE 3.5.0 CONVERSATION EPISODES INSTALLED")
print("=" * 78)
print()
print("New:")
print("  [✓] persistent active episode per channel")
print("  [✓] 20 minute inactivity boundary")
print("  [✓] 90 minute hard duration boundary")
print("  [✓] 80 event hard boundary")
print("  [✓] participant tracking")
print("  [✓] duplicate message protection")
print("  [✓] previous Evilnae replies synced from channel context")
print("  [✓] closed episode archive + compact digest")
print("  [✓] stale episode recovery after restart")
print("  [✓] episode context -> Brain / Writer / Qwen")
print()
print("IMPORTANT:")
print("  [✓] Episodes are CONTEXT, not automatic memories")
print("  [✓] Episodes DO NOT change Character Learning")
print("  [✓] no new OpenAI/Ollama call")
print()
print("State file: evilnae_episodes.json")
print()
print(f"Backup: {backup_dir}")
print()
print("NO MEMORY RESET REQUIRED.")
print()
print("NEXT:")
print("  python bot.py")
print()
print("Expected startup:")
print("  Bot Version: 3.5.0-conversation-episodes")
print("  Conversation Episodes v1.0: ACTIVE")
print("  [CONVERSATION EPISODES] v=1.0 active=... closed=...")
print()
print("Expected on messages:")
print("  [CONVERSATION EPISODE] v=1.0 id='ep_...' ...")
