from pathlib import Path
from datetime import datetime
import ast
import shutil
import subprocess
import sys

PROJECT_ROOT = Path(__file__).resolve().parent
BOT_PATH = PROJECT_ROOT / 'bot.py'
BRAIN_PATH = PROJECT_ROOT / 'brain.py'
PLANNER_PATH = PROJECT_ROOT / 'response_planner.py'
BACKUP_ROOT = PROJECT_ROOT / 'live_fix_backups'

EXPECTED_BOT = 'BOT_VERSION = "3.2.0-live-naturalness"'
TARGET_BOT = 'BOT_VERSION = "3.3.0-response-planner"'
EXPECTED_BRAIN = 'BRAIN_VERSION = "2.3-curiosity"'
TARGET_BRAIN = 'BRAIN_VERSION = "2.4-response-planner"'
PLANNER_VERSION_MARKER = 'RESPONSE_PLANNER_VERSION = "1.0"'
PLANNER_SOURCE = 'from dataclasses import dataclass, field\nfrom typing import Any\n\nRESPONSE_PLANNER_VERSION = "1.0"\n\nALLOWED_SOCIAL_MOVES = {\n    "answer", "acknowledge", "tease", "roast", "counter",\n    "challenge", "disagree", "support", "correct", "clarify",\n    "curious_tease", "smug_acknowledge", "deflect",\n    "change_topic", "ask", "react", "stay_silent",\n}\n\nALLOWED_STANCES = {\n    "neutral", "dry", "smug", "playful", "competitive",\n    "warm", "serious", "curious", "annoyed", "confused",\n}\n\nALLOWED_REPLY_SHAPES = {\n    "fragment", "one_liner", "short", "compact", "medium",\n}\n\n_GENERIC_CORE_THOUGHTS = {\n    "",\n    "natürlich und direkt auf die aktuelle situation reagieren.",\n    "natuerlich und direkt auf die aktuelle situation reagieren.",\n    "kurzes ziel der antwort.",\n    "fallback-entscheidung.",\n}\n\n\n@dataclass\nclass ResponsePlan:\n    social_move: str = "answer"\n    stance: str = "dry"\n    core_thought: str = ""\n    emotional_angle: str = ""\n    target_focus: str = "current_user"\n    reply_shape: str = "one_liner"\n    banter_intensity: float = 0.30\n    warmth_intensity: float = 0.30\n    allow_question: bool = False\n    question_goal: str = ""\n    must_include: list[str] = field(default_factory=list)\n    must_avoid: list[str] = field(default_factory=list)\n    source: str = "brain+planner"\n\n\ndef _clean_text(value: Any, limit: int = 500) -> str:\n    return str(value or "").strip()[:limit]\n\n\ndef _clean_list(value: Any, *, limit: int = 8) -> list[str]:\n    if not isinstance(value, list):\n        return []\n    result = []\n    for item in value:\n        text = _clean_text(item, 250)\n        if text and text not in result:\n            result.append(text)\n        if len(result) >= limit:\n            break\n    return result\n\n\ndef _clamp01(value: Any, default: float) -> float:\n    try:\n        number = float(value)\n    except (TypeError, ValueError):\n        number = default\n    return max(0.0, min(1.0, number))\n\n\ndef _enum(value: Any, allowed: set[str], default: str) -> str:\n    normalized = _clean_text(value, 80).lower()\n    return normalized if normalized in allowed else default\n\n\ndef _fallback_move(decision) -> str:\n    action = _clean_text(getattr(decision, "action", "reply"), 80).lower()\n    return {\n        "reply": "answer",\n        "short_reply": "answer",\n        "acknowledge": "acknowledge",\n        "tease": "tease",\n        "correct": "correct",\n        "react": "react",\n        "change_topic": "change_topic",\n        "ask_person": "answer",\n        "stay_silent": "stay_silent",\n    }.get(action, "answer")\n\n\ndef _fallback_stance(decision) -> str:\n    tone = _clean_text(getattr(decision, "tone", "relaxed"), 80).lower()\n    return {\n        "relaxed": "dry",\n        "dry": "dry",\n        "amused": "playful",\n        "smug": "smug",\n        "soft": "warm",\n        "annoyed": "annoyed",\n        "serious": "serious",\n        "confused": "confused",\n        "playful": "playful",\n        "gen_z": "dry",\n    }.get(tone, "dry")\n\n\ndef _fallback_shape(decision) -> str:\n    response_length = _clean_text(\n        getattr(decision, "response_length", "short"), 80\n    ).lower()\n    return {\n        "tiny": "fragment",\n        "short": "one_liner",\n        "medium": "compact",\n        "long": "medium",\n    }.get(response_length, "one_liner")\n\n\ndef _choose_core_thought(decision) -> str:\n    for candidate in (\n        getattr(decision, "core_thought", ""),\n        getattr(decision, "response_goal", ""),\n        getattr(decision, "reasoning_summary", ""),\n    ):\n        text = _clean_text(candidate, 500)\n        if text and text.lower() not in _GENERIC_CORE_THOUGHTS:\n            return text\n    return (\n        "Auf den konkreten Moment reagieren und "\n        "eine eigene Evilnae-Haltung zeigen."\n    )\n\n\ndef _merge_unique(*groups, limit=12) -> list[str]:\n    result = []\n    for group in groups:\n        for item in group or []:\n            text = _clean_text(item, 250)\n            if text and text not in result:\n                result.append(text)\n            if len(result) >= limit:\n                return result\n    return result\n\n\ndef build_response_plan(\n    *,\n    decision,\n    conversation_mode: str,\n    social_mode: str = "",\n    expression_style: str = "",\n) -> ResponsePlan:\n    conversation_mode = _clean_text(conversation_mode, 40).lower()\n    social_mode = _clean_text(social_mode, 80).lower()\n\n    move = _enum(\n        getattr(decision, "social_move", ""),\n        ALLOWED_SOCIAL_MOVES,\n        _fallback_move(decision),\n    )\n    stance = _enum(\n        getattr(decision, "stance", ""),\n        ALLOWED_STANCES,\n        _fallback_stance(decision),\n    )\n    reply_shape = _enum(\n        getattr(decision, "reply_shape", ""),\n        ALLOWED_REPLY_SHAPES,\n        _fallback_shape(decision),\n    )\n    core_thought = _choose_core_thought(decision)\n    emotional_angle = _clean_text(\n        getattr(decision, "emotional_angle", ""), 300\n    )\n    target_focus = _clean_text(\n        getattr(decision, "target_focus", ""), 160\n    ) or "current_user"\n\n    banter = _clamp01(\n        getattr(decision, "banter_intensity", 0.30), 0.30\n    )\n    warmth = _clamp01(\n        getattr(decision, "warmth_intensity", 0.30), 0.30\n    )\n\n    must_include = _clean_list(\n        getattr(decision, "plan_must_include", []), limit=8\n    )\n    must_avoid = _merge_unique(\n        _clean_list(\n            getattr(decision, "plan_must_avoid", []), limit=8\n        ),\n        _clean_list(\n            getattr(decision, "avoid_phrases", []), limit=8\n        ),\n        [\n            "User-Nachricht nur paraphrasieren",\n            "automatische freundliche Bestätigung",\n            "generischer positiver Abschluss",\n            "Customer-Service- oder Coach-Sprache",\n        ],\n        limit=12,\n    )\n\n    allow_question = bool(getattr(decision, "ask_question", False))\n    question_goal = (\n        _clean_text(getattr(decision, "question_goal", ""), 300)\n        if allow_question else ""\n    )\n\n    # Existing 3.1.x social policy remains the hard social floor.\n    if social_mode == "serious" or stance == "serious":\n        stance = "serious"\n        banter = 0.0\n        warmth = max(warmth, 0.55)\n        if move in {\n            "roast", "tease", "counter", "challenge", "curious_tease"\n        }:\n            move = "support"\n        must_avoid = _merge_unique(\n            must_avoid, ["Roast", "Skill-Issue-Witz", "fake Aggression"]\n        )\n\n    elif social_mode == "betrayal_rivalry":\n        move = "counter"\n        stance = "competitive"\n        banter = max(banter, 0.78)\n        warmth = min(warmth, 0.40)\n\n    elif social_mode == "comparison_provocation":\n        move = "counter"\n        if stance not in {"competitive", "smug"}:\n            stance = "smug"\n        banter = max(banter, 0.68)\n\n    elif social_mode == "competitive":\n        move = "counter"\n        stance = "competitive"\n        banter = max(banter, 0.72)\n\n    elif social_mode == "playful_roast":\n        if move in {"answer", "acknowledge"}:\n            move = "tease"\n        if stance not in {"smug", "playful", "competitive"}:\n            stance = "playful"\n        banter = max(banter, 0.62)\n\n    elif social_mode == "smug_praise":\n        move = "smug_acknowledge"\n        stance = "smug"\n        banter = max(banter, 0.45)\n\n    elif social_mode == "cheeky_curiosity":\n        move = "curious_tease"\n        if stance not in {"playful", "smug"}:\n            stance = "playful"\n        banter = max(banter, 0.42)\n\n    elif social_mode == "sibling_banter":\n        if move == "answer":\n            move = "tease"\n        if stance == "neutral":\n            stance = "playful"\n        banter = max(banter, 0.52)\n\n    if conversation_mode == "participation":\n        must_avoid = _merge_unique(\n            must_avoid,\n            ["Begrüßung", "erklären warum Evilnae mitredet"],\n        )\n\n    if not allow_question:\n        must_avoid = _merge_unique(must_avoid, ["Gegenfrage"])\n\n    expression_style = _clean_text(expression_style, 60).lower()\n    if (\n        expression_style in {"soft", "warm"}\n        and stance not in {"competitive", "smug", "serious"}\n    ):\n        warmth = max(warmth, 0.50)\n\n    return ResponsePlan(\n        social_move=move,\n        stance=stance,\n        core_thought=core_thought,\n        emotional_angle=emotional_angle,\n        target_focus=target_focus,\n        reply_shape=reply_shape,\n        banter_intensity=banter,\n        warmth_intensity=warmth,\n        allow_question=allow_question,\n        question_goal=question_goal,\n        must_include=must_include,\n        must_avoid=must_avoid,\n    )\n\n\ndef format_response_plan_for_writer(plan: ResponsePlan) -> str:\n    include_text = (\n        "\\n".join(f"- {item}" for item in plan.must_include)\n        if plan.must_include\n        else "- nichts zusätzlich erzwingen"\n    )\n    avoid_text = (\n        "\\n".join(f"- {item}" for item in plan.must_avoid)\n        if plan.must_avoid\n        else "- keine besonderen"\n    )\n    question_text = (\n        plan.question_goal\n        if plan.allow_question and plan.question_goal\n        else (\n            "Frage erlaubt, aber kein konkretes Ziel."\n            if plan.allow_question\n            else "Keine Gegenfrage."\n        )\n    )\n\n    return f"""\n[RESPONSE PLAN v{RESPONSE_PLANNER_VERSION}]\n\nDas ist der SEMANTISCHE und SOZIALE Vertrag\nfür genau diese eine Antwort.\n\nDer Writer formuliert diesen Plan.\nEr erfindet KEINEN zweiten Gedanken.\n\nSocial move:\n{plan.social_move}\n\nStance:\n{plan.stance}\n\nCore thought:\n{plan.core_thought}\n\nEmotional angle:\n{plan.emotional_angle or "kein zusätzlicher Emotionssatz nötig"}\n\nTarget focus:\n{plan.target_focus}\n\nReply shape:\n{plan.reply_shape}\n\nBanter intensity:\n{plan.banter_intensity:.2f}\n\nWarmth intensity:\n{plan.warmth_intensity:.2f}\n\nQuestion:\n{question_text}\n\nMUST include, wenn natürlich formulierbar:\n{include_text}\n\nMUST avoid:\n{avoid_text}\n\nHARD:\n- Core thought NICHT stumpf wortwörtlich kopieren.\n- Nicht noch eine freundliche Bestätigung davor setzen.\n- Nicht noch einen hilfreichen Abschluss danach setzen.\n- Keine neue Tatsache hinzufügen.\n- Keine neue Lore hinzufügen.\n- Keine neue Aktivität erfinden, außer der bestehende Character-State erlaubt sie.\n- Ein starker einzelner Gedanke ist besser als drei vollständige Assistant-Sätze.\n""".strip()\n\n\ndef format_response_plan_debug(plan: ResponsePlan) -> str:\n    return (\n        "[RESPONSE PLAN] "\n        f"v={RESPONSE_PLANNER_VERSION} "\n        f"move={plan.social_move} "\n        f"stance={plan.stance} "\n        f"shape={plan.reply_shape} "\n        f"banter={plan.banter_intensity:.2f} "\n        f"warmth={plan.warmth_intensity:.2f} "\n        f"question={plan.allow_question} "\n        f"target={plan.target_focus!r} "\n        f"thought={plan.core_thought!r}"\n    )\n\n\nclass _FakeDecision:\n    action = "reply"\n    tone = "relaxed"\n    response_length = "short"\n    ask_question = False\n    question_goal = ""\n    response_goal = "auf den Fail reagieren"\n    reasoning_summary = ""\n    avoid_phrases = []\n    social_move = "answer"\n    stance = "dry"\n    core_thought = "der User hat gegen sein eigenes Bett verloren"\n    emotional_angle = "amused"\n    target_focus = "current_user"\n    reply_shape = "one_liner"\n    banter_intensity = 0.30\n    warmth_intensity = 0.30\n    plan_must_include = []\n    plan_must_avoid = []\n\n\ndef _self_test() -> int:\n    tests = []\n\n    fail_plan = build_response_plan(\n        decision=_FakeDecision(),\n        conversation_mode="direct",\n        social_mode="playful_roast",\n        expression_style="playful",\n    )\n    tests.append((\n        "playful roast becomes tease",\n        fail_plan.social_move == "tease"\n        and fail_plan.banter_intensity >= 0.60,\n    ))\n\n    betrayal_plan = build_response_plan(\n        decision=_FakeDecision(),\n        conversation_mode="direct",\n        social_mode="betrayal_rivalry",\n        expression_style="smug",\n    )\n    tests.append((\n        "betrayal keeps Evilnae side",\n        betrayal_plan.social_move == "counter"\n        and betrayal_plan.stance == "competitive",\n    ))\n\n    serious_decision = _FakeDecision()\n    serious_decision.social_move = "roast"\n    serious_decision.stance = "playful"\n    serious_decision.banter_intensity = 0.90\n\n    serious_plan = build_response_plan(\n        decision=serious_decision,\n        conversation_mode="direct",\n        social_mode="serious",\n        expression_style="warm",\n    )\n    tests.append((\n        "serious kills roast pressure",\n        serious_plan.banter_intensity == 0.0\n        and serious_plan.stance == "serious",\n    ))\n\n    praise_plan = build_response_plan(\n        decision=_FakeDecision(),\n        conversation_mode="direct",\n        social_mode="smug_praise",\n        expression_style="smug",\n    )\n    tests.append((\n        "praise becomes smug acknowledge",\n        praise_plan.social_move == "smug_acknowledge"\n        and praise_plan.stance == "smug",\n    ))\n\n    tests.append((\n        "no question contract",\n        not fail_plan.allow_question\n        and "Gegenfrage" in fail_plan.must_avoid,\n    ))\n\n    passed = 0\n    print("")\n    print("=" * 56)\n    print(f"RESPONSE PLANNER v{RESPONSE_PLANNER_VERSION} TEST")\n    print("=" * 56)\n\n    for name, success in tests:\n        print(f"[{\'PASS\' if success else \'FAIL\'}] {name}")\n        if success:\n            passed += 1\n\n    print(f"RESULT: {passed}/{len(tests)} PASS")\n    return 0 if passed == len(tests) else 1\n\n\nif __name__ == "__main__":\n    raise SystemExit(_self_test())\n'
BRAIN_FIELDS = '    # -----------------------------------------------------\n    # RESPONSE PLAN\n    # -----------------------------------------------------\n\n    social_move: str = "answer"\n\n    stance: str = "dry"\n\n    core_thought: str = ""\n\n    emotional_angle: str = ""\n\n    target_focus: str = "current_user"\n\n    reply_shape: str = "one_liner"\n\n    banter_intensity: float = 0.30\n\n    warmth_intensity: float = 0.30\n\n    plan_must_include: list[str] = field(\n        default_factory=list\n    )\n\n    plan_must_avoid: list[str] = field(\n        default_factory=list\n    )\n\n'
BRAIN_ALLOWED = 'ALLOWED_SOCIAL_MOVES = {\n\n    "answer",\n    "acknowledge",\n    "tease",\n    "roast",\n    "counter",\n    "challenge",\n    "disagree",\n    "support",\n    "correct",\n    "clarify",\n    "curious_tease",\n    "smug_acknowledge",\n    "deflect",\n    "change_topic",\n    "ask",\n    "react",\n    "stay_silent",\n}\n\n\nALLOWED_STANCES = {\n\n    "neutral",\n    "dry",\n    "smug",\n    "playful",\n    "competitive",\n    "warm",\n    "serious",\n    "curious",\n    "annoyed",\n    "confused",\n}\n\n\nALLOWED_REPLY_SHAPES = {\n\n    "fragment",\n    "one_liner",\n    "short",\n    "compact",\n    "medium",\n}\n\n\n'
BRAIN_DEFAULT_FIELDS = '        social_move="answer",\n\n        stance="dry",\n\n        core_thought=(\n            "Auf den konkreten Moment reagieren "\n            "und eine eigene Haltung zeigen."\n        ),\n\n        emotional_angle="",\n\n        target_focus="current_user",\n\n        reply_shape="one_liner",\n\n        banter_intensity=0.30,\n\n        warmth_intensity=0.30,\n\n        plan_must_include=[],\n\n        plan_must_avoid=[],\n\n'
BRAIN_PLANNING_PROMPT = '\n==================================================\nRESPONSE PLANNING\n==================================================\n\nDu planst ausdrücklich, WAS Evilnae sagen will.\nDu formulierst weiterhin NICHT die fertige Discord-Nachricht.\n\nsocial_move:\nanswer, acknowledge, tease, roast, counter, challenge,\ndisagree, support, correct, clarify, curious_tease,\nsmug_acknowledge, deflect, change_topic, ask, react, stay_silent\n\nstance:\nneutral, dry, smug, playful, competitive, warm,\nserious, curious, annoyed, confused\n\ncore_thought:\nDer EINE interne Gedanke hinter der Antwort.\nKein fertiger Discord-Satz.\n\nGUTE core_thought Beispiele:\n- "der User hat gerade gegen sein eigenes Bett verloren"\n- "der Hanae-Vergleich ist frecher Verrat und verdient einen Konter"\n- "ich hätte definitiv Lust, Hanaes Stream etwas zu sabotieren"\n- "ich weiß nicht, was Hanae gerade macht"\n- "das Lob nehme ich selbstverständlich an"\n\nSCHLECHT:\n- "natürlich antworten"\n- "freundlich reagieren"\n- "Gespräch fortführen"\n\nemotional_angle:\nKurzer interner Winkel, nur wenn relevant:\namused, fake offended, genuinely concerned, smug,\ncurious, competitive usw.\n\ntarget_focus:\nWorauf reagiert sie konkret?\nz.B. current_user, Hanae comparison, user fail,\ncurrent activity, specific question, running gag.\n\nreply_shape:\nfragment, one_liner, short, compact, medium.\n\nbanter_intensity:\n0.0 bis 1.0.\n\nwarmth_intensity:\n0.0 bis 1.0.\n\nErnst/verletzlich:\nBanter stark runter.\n\nHarmlose Angriffsfläche/Rivalität/Provokation:\nBanter darf hoch.\n\nplan_must_include:\nNur konkrete notwendige Inhalte.\nKeine Fakten erfinden.\n\nplan_must_avoid:\nKonkrete Dinge, die diese Antwort nicht tun darf.\n\nPLAN-PRINZIP:\nNormalerweise EIN social_move + EINE stance + EIN core_thought.\nDer Writer formuliert erst danach die echte Discord-Nachricht.\n\n\n'
BRAIN_PARSE_FIELDS = '        social_move=safe_enum(\n            data.get(\n                "social_move"\n            ),\n            ALLOWED_SOCIAL_MOVES,\n            fallback.social_move\n        ),\n\n        stance=safe_enum(\n            data.get(\n                "stance"\n            ),\n            ALLOWED_STANCES,\n            fallback.stance\n        ),\n\n        core_thought=(\n            str(\n                data.get(\n                    "core_thought",\n                    fallback.core_thought\n                )\n            )[:500]\n        ),\n\n        emotional_angle=(\n            str(\n                data.get(\n                    "emotional_angle",\n                    fallback.emotional_angle\n                )\n            )[:300]\n        ),\n\n        target_focus=(\n            str(\n                data.get(\n                    "target_focus",\n                    fallback.target_focus\n                )\n            )[:200]\n        ),\n\n        reply_shape=safe_enum(\n            data.get(\n                "reply_shape"\n            ),\n            ALLOWED_REPLY_SHAPES,\n            fallback.reply_shape\n        ),\n\n        banter_intensity=(\n            safe_float_01(\n                data.get(\n                    "banter_intensity"\n                ),\n                fallback.banter_intensity\n            )\n        ),\n\n        warmth_intensity=(\n            safe_float_01(\n                data.get(\n                    "warmth_intensity"\n                ),\n                fallback.warmth_intensity\n            )\n        ),\n\n        plan_must_include=safe_list(\n            data.get(\n                "plan_must_include"\n            ),\n            limit=8\n        ),\n\n        plan_must_avoid=safe_list(\n            data.get(\n                "plan_must_avoid"\n            ),\n            limit=8\n        ),\n\n'
BRAIN_FORMAT_FIELDS = 'Social move:\n{decision.social_move}\n\nStance:\n{decision.stance}\n\nCore thought:\n{decision.core_thought}\n\nEmotional angle:\n{decision.emotional_angle}\n\nTarget focus:\n{decision.target_focus}\n\nReply shape:\n{decision.reply_shape}\n\nBanter intensity:\n{decision.banter_intensity:.2f}\n\nWarmth intensity:\n{decision.warmth_intensity:.2f}\n\nPlan must include:\n{", ".join(decision.plan_must_include) if decision.plan_must_include else "Nichts."}\n\nPlan must avoid:\n{", ".join(decision.plan_must_avoid) if decision.plan_must_avoid else "Nichts."}\n\n'
PLANNER_IMPORT = 'from response_planner import (\n    RESPONSE_PLANNER_VERSION,\n    build_response_plan,\n    format_response_plan_for_writer,\n    format_response_plan_debug,\n)\n\n'
PLAN_BUILD_BLOCK = '        # =================================================\n        # 8.5 RESPONSE PLANNER\n        # =================================================\n\n        social_mode_for_plan = (\n            detect_social_stance_mode(\n                user_text,\n                b3c_episode_focus_text,\n                is_hanae=is_hanae,\n            )\n        )\n\n        response_plan = (\n            build_response_plan(\n                decision=decision,\n                conversation_mode=(\n                    brain_conversation_mode\n                ),\n                social_mode=(\n                    social_mode_for_plan\n                ),\n                expression_style=(\n                    expression_plan.style\n                ),\n            )\n        )\n\n        response_plan_text = (\n            format_response_plan_for_writer(\n                response_plan\n            )\n        )\n\n        print(\n            format_response_plan_debug(\n                response_plan\n            )\n        )\n\n'


def ok(text):
    print(f"[OK] {text}")


def fail(text):
    print()
    print(f"[INSTALL ERROR] {text}")
    print("Nothing was overwritten by this installer.")
    raise SystemExit(1)


def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        fail(f"{label}: expected exactly 1 match, found {count}")
    print(f"[OK] {label}")
    return text.replace(old, new, 1)


def insert_before_once(text, marker, block, label):
    count = text.count(marker)
    if count != 1:
        fail(f"{label}: expected exactly 1 marker, found {count}")
    print(f"[OK] {label}")
    return text.replace(marker, block + marker, 1)


def syntax_check(text, filename):
    try:
        ast.parse(text, filename=filename)
    except SyntaxError as error:
        fail(
            f"{filename}: syntax error after patch at "
            f"line {error.lineno}: {error.msg}"
        )
    print(f"[OK] {filename} syntax check")


print("=" * 78)
print("EVILNAE 3.3.0 RESPONSE PLANNER")
print("=" * 78)
print(f"Project: {PROJECT_ROOT}")
print()
print("WICHTIG: bot.py muss vollständig AUS sein.")
print()

if not BOT_PATH.exists() or not BRAIN_PATH.exists():
    fail("bot.py or brain.py missing")

bot = BOT_PATH.read_text(encoding="utf-8")
brain = BRAIN_PATH.read_text(encoding="utf-8")

if (
    TARGET_BOT in bot
    and TARGET_BRAIN in brain
    and PLANNER_PATH.exists()
    and PLANNER_VERSION_MARKER
    in PLANNER_PATH.read_text(encoding="utf-8")
):
    print("3.3.0 Response Planner is already installed.")
    raise SystemExit(0)

if EXPECTED_BOT not in bot:
    fail("Expected Bot 3.2.0-live-naturalness")

if EXPECTED_BRAIN not in brain:
    fail("Expected Brain 2.3-curiosity")

if PLANNER_PATH.exists():
    fail(
        "response_planner.py already exists unexpectedly. "
        "Refusing to overwrite it."
    )

for marker in (
    "[AUTO FILE LOGGING]",
    "RELIABILITY DIRECT STATEMENT RESCUE SUCCESS",
    "SOCIAL STANCE / EVILNAE EGO v1",
):
    if marker not in bot:
        fail(f"Required 3.2 invariant missing in bot.py: {marker}")

ok("3.2.0 live-naturalness base detected")

# Versions.
bot = replace_once(
    bot, EXPECTED_BOT, TARGET_BOT,
    "Bot version -> 3.3.0-response-planner"
)
brain = replace_once(
    brain, EXPECTED_BRAIN, TARGET_BRAIN,
    "Brain version -> 2.4-response-planner"
)

# Brain dataclass.
brain = insert_before_once(
    brain,
    '    # -----------------------------------------------------\n'
    '    # WRITER GUIDANCE\n'
    '    # -----------------------------------------------------\n',
    BRAIN_FIELDS,
    "BrainDecision response-plan fields",
)

# Allowed values.
brain = insert_before_once(
    brain,
    'ALLOWED_QUESTION_TYPES = {\n',
    BRAIN_ALLOWED,
    "Brain planner allowed values",
)

# Defaults.
brain = insert_before_once(
    brain,
    '        avoid_phrases=[],\n',
    BRAIN_DEFAULT_FIELDS,
    "Brain default response plan",
)

# Prompt.
brain = insert_before_once(
    brain,
    '==================================================\n'
    'AUSGABE\n'
    '==================================================\n',
    BRAIN_PLANNING_PROMPT,
    "Brain response-planning prompt",
)

# JSON schema.
brain = replace_once(
    brain,
    '  "target_user_name": null,\n'
    '  "avoid_phrases": [],\n',
    '  "target_user_name": null,\n'
    '  "social_move": "answer",\n'
    '  "stance": "dry",\n'
    '  "core_thought": "Der eine interne Gedanke hinter der Antwort.",\n'
    '  "emotional_angle": "",\n'
    '  "target_focus": "current_user",\n'
    '  "reply_shape": "one_liner",\n'
    '  "banter_intensity": 0.3,\n'
    '  "warmth_intensity": 0.3,\n'
    '  "plan_must_include": [],\n'
    '  "plan_must_avoid": [],\n'
    '  "avoid_phrases": [],\n',
    "Brain JSON schema response-plan fields",
)

# Parser.
brain = insert_before_once(
    brain,
    '        avoid_phrases=safe_list(\n',
    BRAIN_PARSE_FIELDS,
    "Brain parses response-plan fields",
)

# Writer formatting.
brain = insert_before_once(
    brain,
    'Avoid phrases:\n'
    '{avoid_text}\n',
    BRAIN_FORMAT_FIELDS,
    "Brain writer format includes response plan",
)

# Debug.
brain = replace_once(
    brain,
    '        f"tone={decision.tone} "\n'
    '        f"question={decision.ask_question} "\n',
    '        f"tone={decision.tone} "\n'
    '        f"move={decision.social_move} "\n'
    '        f"stance={decision.stance} "\n'
    '        f"shape={decision.reply_shape} "\n'
    '        f"banter={decision.banter_intensity:.2f} "\n'
    '        f"question={decision.ask_question} "\n',
    "Brain debug response-plan summary",
)

# Slightly larger JSON budget, same API call.
brain = replace_once(
    brain,
    '                max_output_tokens=500,\n',
    '                max_output_tokens=650,\n',
    "Brain JSON output budget -> 650",
)

# Bot import.
bot = insert_before_once(
    bot,
    'from social_actions import (\n',
    PLANNER_IMPORT,
    "bot.py imports Response Planner",
)

# Startup.
bot = replace_once(
    bot,
    '    print(\n'
    '        f"Brain v{BRAIN_VERSION}: ACTIVE"\n'
    '    )\n\n',
    '    print(\n'
    '        f"Brain v{BRAIN_VERSION}: ACTIVE"\n'
    '    )\n\n'
    '    print(\n'
    '        f"Response Planner v"\n'
    '        f"{RESPONSE_PLANNER_VERSION}: ACTIVE"\n'
    '    )\n\n'
    '    print(\n'
    '        "Structured Core Thought: ACTIVE"\n'
    '    )\n\n'
    '    print(\n'
    '        "Social Move / Stance Contract: ACTIVE"\n'
    '    )\n\n',
    "Startup Response Planner banner",
)

# Build plan before writer.
bot = insert_before_once(
    bot,
    '        # =================================================\n'
    '        # 9. WRITER CONTEXT\n'
    '        # =================================================\n',
    PLAN_BUILD_BLOCK,
    "Build Response Plan before Writer",
)

# Append plan to writer context after social stance.
bot = replace_once(
    bot,
    '            + "\\n\\n"\n'
    '            + social_stance_text\n'
    '        )\n',
    '            + "\\n\\n"\n'
    '            + social_stance_text\n'
    '            + "\\n\\n"\n'
    '            + response_plan_text\n'
    '        )\n',
    "Writer receives Response Plan",
)

# Primary writer instruction.
bot = replace_once(
    bot,
    '                            input=(\n'
    '                                "Formuliere jetzt "\n'
    '                                "Evilnaes tatsächliche "\n'
    '                                "Discord-Nachricht. "\n'
    '                                "Die Antwort muss echten Text "\n'
    '                                "mit mindestens einem Wort enthalten. "\n'
    '                                "Schreibe selbst keine Unicode-Emojis "\n'
    '                                "oder Discord-Custom-Emotes; "\n'
    '                                "der Emote-Layer kommt danach."\n'
    '                            ),\n',
    '                            input=(\n'
    '                                "Setze jetzt den RESPONSE PLAN um "\n'
    '                                "und formuliere Evilnaes tatsächliche "\n'
    '                                "Discord-Nachricht. "\n'
    '                                "Transportiere den Core Thought, "\n'
    '                                "aber kopiere ihn nicht stumpf. "\n'
    '                                "Füge keinen zweiten Gedanken und "\n'
    '                                "keinen freundlichen Assistant-Abschluss hinzu. "\n'
    '                                "Die Antwort muss echten Text "\n'
    '                                "mit mindestens einem Wort enthalten. "\n'
    '                                "Schreibe selbst keine Unicode-Emojis "\n'
    '                                "oder Discord-Custom-Emotes; "\n'
    '                                "der Emote-Layer kommt danach."\n'
    '                            ),\n',
    "Primary Writer executes Response Plan",
)

# Invariants.
for marker in (
    TARGET_BRAIN,
    "social_move: str",
    "core_thought: str",
    "RESPONSE PLANNING",
    "ALLOWED_SOCIAL_MOVES",
    "plan_must_include=safe_list",
):
    if marker not in brain:
        fail(f"Patched brain.py missing invariant: {marker}")

for marker in (
    TARGET_BOT,
    "RESPONSE_PLANNER_VERSION",
    "8.5 RESPONSE PLANNER",
    "response_plan_text",
    "Setze jetzt den RESPONSE PLAN um",
):
    if marker not in bot:
        fail(f"Patched bot.py missing invariant: {marker}")

for marker in (
    PLANNER_VERSION_MARKER,
    "class ResponsePlan",
    "def build_response_plan(",
    "def format_response_plan_for_writer(",
):
    if marker not in PLANNER_SOURCE:
        fail(f"Planner source missing invariant: {marker}")

syntax_check(brain, "brain.py")
syntax_check(PLANNER_SOURCE, "response_planner.py")
syntax_check(bot, "bot.py")

tests = {
    "one core thought field":
        brain.count("core_thought: str") == 1,
    "writer gets plan once":
        bot.count("+ response_plan_text") == 1,
    "planner adds no API call":
        "safe_openai_request" not in PLANNER_SOURCE
        and "AsyncOpenAI" not in PLANNER_SOURCE,
    "serious override exists":
        'social_mode == "serious"' in PLANNER_SOURCE,
    "rivalry override exists":
        '"betrayal_rivalry"' in PLANNER_SOURCE,
}

failed = [name for name, passed in tests.items() if not passed]
if failed:
    fail("Contract self-test failed: " + ", ".join(failed))

ok(f"Contract self-test: {len(tests)}/{len(tests)} PASS")

# Backup.
timestamp = datetime.now().astimezone().strftime("%Y%m%d-%H%M%S")
backup_dir = BACKUP_ROOT / timestamp
suffix = 1
while backup_dir.exists():
    backup_dir = BACKUP_ROOT / f"{timestamp}_{suffix:02d}"
    suffix += 1

backup_dir.mkdir(parents=True, exist_ok=False)

for path in (BOT_PATH, BRAIN_PATH):
    shutil.copy2(path, backup_dir / path.name)
    ok(f"Backup: {path.name}")

# Write.
def atomic_write(path, text):
    temp = Path(str(path) + ".tmp")
    temp.write_text(text, encoding="utf-8")
    temp.replace(path)

atomic_write(BRAIN_PATH, brain)
ok("Updated: brain.py")

atomic_write(PLANNER_PATH, PLANNER_SOURCE)
ok("Created: response_planner.py")

atomic_write(BOT_PATH, bot)
ok("Updated: bot.py")

# Compile.
result = subprocess.run(
    [
        sys.executable, "-m", "py_compile",
        str(BRAIN_PATH),
        str(PLANNER_PATH),
        str(BOT_PATH),
    ],
    cwd=str(PROJECT_ROOT),
    check=False,
)
if result.returncode != 0:
    print(f"Backup: {backup_dir}")
    raise SystemExit(result.returncode)

ok("Post-install py_compile: 3/3")

# Planner self-test.
result = subprocess.run(
    [sys.executable, str(PLANNER_PATH)],
    cwd=str(PROJECT_ROOT),
    check=False,
)
if result.returncode != 0:
    print(f"Backup: {backup_dir}")
    raise SystemExit(result.returncode)

ok("Self-test: response_planner.py")

print()
print("=" * 78)
print("EVILNAE 3.3.0 RESPONSE PLANNER INSTALLED")
print("=" * 78)
print()
print("Installed:")
print("  [✓] Brain 2.4 structured response planning")
print("  [✓] one Core Thought per response")
print("  [✓] Social Move + Stance")
print("  [✓] Target Focus + Reply Shape")
print("  [✓] Banter / Warmth intensity")
print("  [✓] MUST include / MUST avoid contract")
print("  [✓] existing Social Ego policy hardens the plan")
print("  [✓] Writer receives semantic Response Plan")
print("  [✓] NO additional OpenAI request")
print()
print("Unchanged:")
print("  [✓] Foundation / Excel")
print("  [✓] Character State / Learning / Memories / DB")
print("  [✓] Routing / Knowledge Guard")
print("  [✓] Local Voice / Qwen behavior")
print("  [✓] Emote Layer")
print()
print(f"Backup: {backup_dir}")
print()
print("NO MEMORY RESET REQUIRED.")
print()
print("NEXT:")
print("  python bot.py")
print()
print("Expected startup:")
print("  Bot Version: 3.3.0-response-planner")
print("  Brain v2.4-response-planner: ACTIVE")
print("  Response Planner v1.0: ACTIVE")
print()
print("Expected per reply:")
print("  [RESPONSE PLAN] v=1.0 move=... stance=... thought='...'")
